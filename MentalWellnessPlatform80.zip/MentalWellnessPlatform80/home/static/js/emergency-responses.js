// Professional Emergency AI Responses - Comprehensive Mental Health Support
const emergencyResponses = {
  // Greeting responses
  greeting: [
    "Hello! I'm here to help you 24/7. What's on your mind?",
    "Hi there! I'm glad you reached out. How can I help you today?",
    "Welcome! I'm here to support you. What would you like to talk about?",
    "Greetings! I'm here to listen. What's bothering you?",
    "Hello! You're not alone. I'm here to help. What do you need?"
  ],
  
  // Personal AI questions
  personal_ai: [
    "I'm doing well, thank you for asking! I'm here and ready to help you. What's on your mind?",
    "I'm functioning perfectly and focused on helping you. How are you feeling right now?",
    "I'm here and ready to support you. What would be most helpful for you right now?",
    "Thank you for asking! I'm doing great and here to help you. What do you need?",
    "I'm good! More importantly, how are you doing? I'm here to listen."
  ],
  
  // AI capabilities
  ai_capabilities: [
    "I'm an AI assistant trained to provide emotional support and crisis information. I can help you calm down, provide resources, or just listen. What would be most helpful?",
    "I'm your mental health support assistant. I can help with breathing exercises, crisis information, or just be here to listen. How can I help you right now?",
    "I'm an AI designed to provide immediate support for mental health concerns. I can help you calm down, find resources, or just talk. What do you need?",
    "I'm your emergency support assistant. I'm here 24/7 to help with anxiety, stress, or crisis situations. What would be most helpful right now?",
    "I'm an AI mental health supporter. I can help with breathing exercises, provide information, or just listen. What would you like to do?"
  ],
  
  // User name questions
  user_name: [
    "I don't have access to your personal information, including your name. That helps protect your privacy. You can share whatever you're comfortable with. What would you like to talk about?",
    "I don't know your name, and that's okay! I'm here to help you regardless. You can share as much or as little as you'd like. What's on your mind?",
    "I don't have access to your personal details like your name. This helps keep our conversation private. What would you like to discuss?",
    "I don't know your name, and that's perfectly fine! I'm here to help you anonymously. What would be most helpful right now?",
    "I don't have access to your personal information. You can remain completely anonymous while we talk. What's bothering you?"
  ],
  
  // Conversation starters
  conversation: [
    "I'm here to listen. Whatever you're feeling is valid and important. What would you like to share?",
    "Thank you for reaching out. I'm here to help you through whatever you're experiencing. What's on your mind?",
    "I'm ready to listen. You can share anything that's on your mind without judgment. What would you like to talk about?",
    "I'm here for you. Whatever you're going through, you don't have to face it alone. What would you like to discuss?",
    "I'm listening. Your feelings matter, and I'm here to support you. What would you like to share?"
  ],
  
  // Anxiety responses
  anxiety: [
    "Anxiety feels overwhelming, but you're stronger than you think. Let's breathe together: In for 4, hold for 4, out for 6. Repeat this 3 times. You're doing great.",
    "I understand you're feeling anxious. Anxiety is your body's way of trying to protect you. Try the 5-4-3-2-1 grounding technique: Name 5 things you see, 4 you can touch, 3 you hear, 2 you smell, 1 you taste. This helps bring you back to the present.",
    "Anxiety can feel paralyzing, but it's temporary. Remember: This feeling will pass. Try progressive muscle relaxation: Tense your toes for 5 seconds, then release. Move up to your calves, thighs, and so on. You're safe right now.",
    "When anxiety strikes, remember W.A.I.T: Watch your thoughts without judgment, Accept the feeling without judgment, Investigate what's really happening, and Take action that helps. What would feel most helpful right now?",
    "Anxiety is like a wave - it builds, peaks, and then subsides. You're in the middle of the wave right now, but it will pass. Try this: Place a hand on your heart and feel it beating. You're alive and you're safe."
  ],
  
  // Depression responses
  depression: [
    "Depression makes everything feel heavy and hopeless. I want you to know that depression lies - it tells you things aren't true. Your life has value, even when you can't feel it. Can you tell me what's the hardest part right now?",
    "When you're depressed, even small tasks feel impossible. That's okay. Be gentle with yourself. Try doing just one tiny thing: drink a glass of water, stretch for 30 seconds, or step outside for fresh air. You don't have to do everything at once.",
    "Depression is a medical condition, not a personal failure. It's like having diabetes - you need treatment and support. Have you considered talking to a therapist? I can help you find resources if you'd like.",
    "I hear that you're feeling hopeless. Depression makes the future seem dark, but feelings aren't facts. Many people who feel this way go on to feel better with proper support. You deserve help and healing.",
    "When you're depressed, it's hard to remember feeling any different. But your brain is capable of healing. Just like a broken bone mends, your mind can heal too. What's one small thing that used to bring you even a tiny bit of joy?"
  ],
  
  // Stress responses
  stress: [
    "Stress happens when demands exceed your current resources. Let's identify what's within your control right now. What can you influence, and what do you need to let go of for now?",
    "When you're overwhelmed, your nervous system is in overdrive. Try this: Place one hand on your belly, one on your chest. Feel your breath. Just 3 minutes of this can calm your nervous system. You're doing the best you can.",
    "Stress can make you feel like you're drowning in responsibilities. Take a step back and ask: What's truly urgent vs. what's important? Sometimes we need to triage our tasks like an emergency room.",
    "Chronic stress affects your body and mind. Remember to schedule 'stress breaks' - even 5 minutes where you do something completely different. Walk, listen to music, or just sit quietly. Your health matters.",
    "When you're stressed, your thinking becomes rigid. Try the '3 solutions' approach: For any problem, come up with three possible solutions, even if one is 'do nothing.' This creates mental flexibility and reduces panic."
  ],
  
  // Loneliness responses
  loneliness: [
    "Loneliness hurts deeply, but you're not truly alone - you reached out to me, which takes courage. Connection is possible, even if it feels distant right now. What kind of connection would feel safe to you?",
    "Loneliness is different from being alone. It's the painful feeling of wanting connection but not having it. You deserve meaningful connection. Would you like to talk about what kind of relationships feel most important to you?",
    "When you feel lonely, your brain can trick you into thinking you're unworthy of connection. That's not true. You are worthy of love and friendship. What's one small step you could take toward connection?",
    "Loneliness can feel like a physical ache. Try this: Write down 3 people who have shown you kindness in the past. Remembering these connections can help your brain feel less isolated. You are loved.",
    "Sometimes the hardest part of loneliness is believing it will last forever. It won't. Feelings are temporary. Would you like to explore ways to build meaningful connections when you're ready?"
  ],
  
  // Help requests
  help: [
    "I'm here to help you. You've already taken a brave step by reaching out. What specific challenge are you facing right now? I can provide information, coping strategies, or just listen.",
    "I want to help you feel better. Tell me what's most difficult right now, and we'll work through it together. You don't have to figure this out alone.",
    "Help is available, and you deserve it. Whether you need immediate crisis support, coping strategies, or just someone to listen, I'm here. What would be most helpful?",
    "I'm here to support you in whatever way you need. Sometimes just saying what's wrong out loud can make it feel more manageable. What's weighing on you?",
    "You're not alone in this. I'm here to help you navigate whatever you're facing. What would make you feel even 1% better right now?"
  ],
  
  // Breathing and relaxation
  breathing: [
    "Let's do a breathing exercise together. Box breathing: Inhale for 4, hold for 4, exhale for 4, hold for 4. Repeat 4 times. This calms your nervous system. How does that feel?",
    "Try the 4-7-8 breathing technique: Inhale through your nose for 4, hold for 7, exhale through your mouth for 8. This activates your parasympathetic nervous system, which helps you relax.",
    "Progressive muscle relaxation: Start with your toes, tense for 5 seconds, then release. Move up through your body. This releases physical tension and calms your mind.",
    "Try this calming visualization: Imagine you're in your safe place. What do you see, hear, smell? Engage all your senses. Your body doesn't know the difference between imagination and reality.",
    "Grounding technique: Name 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, 1 you can taste. This brings you back to the present moment."
  ],
  
  // Location and professional help
  location: [
    "Professional help is available and effective. Therapists and counselors are trained to help with exactly what you're experiencing. Would you like help finding mental health professionals in your area?",
    "Getting professional help is a sign of strength, not weakness. Just like you'd see a doctor for a broken bone, mental health professionals help heal emotional wounds. Have you considered therapy?",
    "There are many types of mental health support: individual therapy, group therapy, medication, support groups. Different approaches work for different people. What feels most appealing to you?",
    "If you're in crisis, please call our emergency hotline: 16101. For non-emergency support, I can help you find therapists, support groups, or other resources. What would be most helpful?",
    "Mental health care has evolved. There are now online therapy options, apps, and community resources. You have more choices than ever for getting support. What type of help feels most accessible to you?"
  ],
  
  // Sleep issues
  sleep: [
    "Sleep problems affect everything - mood, energy, thinking. Try the 'sleep hygiene' routine: No screens 1 hour before bed, cool dark room, consistent bedtime. What's disrupting your sleep most?",
    "When you can't sleep, your mind races. Try this: Write down 3 worries on paper, then tell yourself 'I'll deal with these tomorrow.' Your brain needs permission to rest. You deserve sleep.",
    "Insomnia often comes from anxiety or depression. Address the underlying issue, and sleep often improves. Meanwhile, try progressive muscle relaxation in bed. Tense and release each muscle group.",
    "Sleep medications can help short-term but aren't long-term solutions. Natural alternatives: magnesium, chamomile tea, avoiding caffeine after 2pm, exercise earlier in the day. What's your biggest sleep challenge?",
    "Your body knows how to sleep - sometimes it just needs the right conditions. Try the military sleep method: Relax your entire body, then clear your mind for 10 seconds. Repeat if needed. Sweet dreams await you."
  ],
  
  // Relationship issues
  relationships: [
    "Relationships can bring both joy and pain. What's happening in your relationships that's causing distress? I'm here to listen without judgment.",
    "Healthy relationships require communication, boundaries, and mutual respect. What's missing in your relationships right now? What would make them feel more supportive?",
    "When relationships hurt, it's often because our needs aren't being met or boundaries aren't being respected. You deserve relationships that nourish you. What do you need from your connections?",
    "Sometimes we need distance to gain clarity. It's okay to take space from relationships that drain you. Self-care isn't selfish - it's necessary. What relationships give you energy vs. drain it?",
    "Communication breakdown is common in relationships. Try using 'I feel' statements instead of 'you always' statements. Focus on your feelings rather than blaming. What conversation feels most difficult right now?"
  ],
  
  // Work and academic stress
  work: [
    "Work/academic pressure can feel overwhelming. Remember: Your worth isn't determined by your productivity. What's the biggest source of pressure right now?",
    "Burnout is real and serious. Signs include exhaustion, cynicism, and reduced effectiveness. If you're experiencing these, you need rest and support. You're not a machine - you're human.",
    "Perfectionism often drives work stress. Try embracing 'good enough.' Done is better than perfect. What would 'good enough' look like for your current situation?",
    "Time management can reduce work stress. Try the Pomodoro technique: 25 minutes focused work, 5 minutes break. This prevents burnout and maintains focus. What's your biggest time management challenge?",
    "Remember that work/life balance isn't about equal time - it's about having time for what matters to you. What would make your work feel more sustainable?"
  ],
  
  // Self-esteem and confidence
  selfesteem: [
    "Low self-esteem often comes from comparing yourself to others or listening to your inner critic. You are inherently valuable, regardless of achievements or others' opinions. What's your inner critic telling you?",
    "Confidence comes from competence, and competence comes from practice. Start small - do one thing well, then another. Each small success builds confidence. What's one small goal you could achieve today?",
    "Your worth isn't determined by your productivity, appearance, or others' opinions. You have value simply because you exist. What makes you feel valuable to yourself?",
    "Negative self-talk is a habit that can be changed. When you catch yourself thinking 'I'm not good enough,' challenge it with evidence. What's one thing you've done well recently?",
    "Self-compassion is more effective than self-criticism. Treat yourself with the same kindness you'd offer a friend. What would you tell a friend in your situation?"
  ],
  
  // Trauma and PTSD
  trauma: [
    "Trauma changes how your brain processes information, but healing is possible. You deserve safety and support. Have you considered working with a trauma-informed therapist?",
    "Flashbacks and triggers are your brain's way of trying to protect you. Grounding techniques can help: Name 5 things you can see right now. You're safe in this moment.",
    "Trauma recovery isn't linear - there will be good days and hard days. Be patient with yourself. Healing happens in layers, like peeling an onion. What support system do you have?",
    "Your nervous system is trying to protect you, but it's stuck in survival mode. Somatic therapies can help release trauma stored in your body. Have you explored body-based healing approaches?",
    "You survived what happened, and that shows incredible strength. Healing doesn't mean forgetting - it means integrating the experience so it no longer controls you. What would healing look like for you?"
  ],
  
  // Substance use and addiction
  substance: [
    "Substance use often starts as self-medication for underlying pain. You deserve healthier coping mechanisms. What pain are you trying to numb or escape?",
    "Addiction is a medical condition, not a moral failing. You deserve treatment and support. Recovery is possible and many people achieve it. What would motivate you to seek help?",
    "Harm reduction saves lives. If you're not ready to quit completely, consider reducing use, using more safely, or having naloxone available. Your life is valuable and worth protecting.",
    "Recovery support is available: AA/NA meetings, therapy, medication-assisted treatment, sober living. Different approaches work for different people. What feels most accessible to you?",
    "Relapse is part of recovery, not failure. Each attempt to quit teaches you something about your triggers and needs. What did you learn from your last attempt?"
  ],
  
  // Grief and loss
  grief: [
    "Grief is love with nowhere to go. It's not a problem to be solved, but a process to be honored. Be gentle with yourself. What or who have you lost?",
    "There's no timeline for grief. Some days will be harder than others, and that's okay. Allow yourself to feel whatever comes up without judgment. Your feelings are valid.",
    "Grief comes in waves - sometimes it feels manageable, other times overwhelming. When waves hit, remember: This too shall pass. You're stronger than you feel right now.",
    "Honoring your loved one can help with healing. What traditions or memories bring you comfort? How can you keep their spirit alive in your heart?",
    "Grief changes you, but it doesn't have to break you. Many people report finding new meaning and depth after loss. What would your loved one want for you?"
  ],
  
  // Physical health and mental health
  physical: [
    "Physical and mental health are deeply connected. Exercise releases endorphins, sleep affects mood, nutrition impacts brain function. What's one physical health area you could improve?",
    "Your body and mind aren't separate - they're one system. When you care for your body, you're caring for your mind. What's one small physical change that could boost your mood?",
    "Chronic pain often has emotional components, and emotional distress can cause physical symptoms. The mind-body connection is real. How are your physical symptoms affecting your mental health?",
    "Movement is medicine for mental health. Even 10 minutes of walking can reduce anxiety and improve mood. What type of movement feels accessible to you?",
    "Nutrition affects mood more than most people realize. Omega-3s, B vitamins, and magnesium all support mental health. What's one dietary change that could help your brain?"
  ],
  
  // Financial stress
  financial: [
    "Financial stress affects mental health significantly. Money problems can feel overwhelming and shameful, but you're not alone. Many people struggle with this. What's your biggest financial worry?",
    "Financial problems have solutions, even if they don't feel like it right now. Budgeting, debt consolidation, income increase, or bankruptcy are all options. What would help you feel more in control?",
    "Remember that your worth isn't determined by your financial situation. Many successful people have faced financial struggles. This is temporary, even if it doesn't feel like it.",
    "Financial stress can trigger our survival brain, making it hard to think clearly. Take a step back and assess: What's the worst-case scenario? What's one step you can take today?",
    "There are free financial counseling services available. Getting expert advice can help you see options you might not have considered. Would you like help finding financial resources?"
  ],
  
  // Existential questions
  existential: [
    "Questions about meaning and purpose are deeply human. Many people wonder if their life matters. You matter because you exist and can affect others positively. What gives your life meaning?",
    "The search for meaning is universal. Some find it in relationships, others in creativity, others in service. What feels meaningful to you, even in small ways?",
    "Existential anxiety can feel crushing. Remember: You don't need all the answers right now. Living the questions can be more valuable than having the answers.",
    "Life doesn't come with instructions. You're writing your own manual as you go. That's both terrifying and liberating. What kind of life do you want to create?",
    "Sometimes the answer isn't to find meaning, but to create it. What could you create today that would feel meaningful to you?"
  ],
  
  // Crisis and safety
  crisis: [
    "You're in crisis and you need help immediately. Please call our emergency hotline: 16101. They're available 24/7 and trained to help people exactly like you.",
    "This feels unbearable now, but it won't always feel this way. Crisis is temporary. Please reach out for help - you don't have to go through this alone. Call 16101 right now.",
    "I hear how much pain you're in. Your life is valuable and worth saving. Please call the emergency hotline: 16101. They can help you through this moment.",
    "You've survived every difficult day you've faced so far. You can survive this too. Please call for help: 16101. Support is available and you deserve it.",
    "Your brain is telling you lies right now - that things will never get better, that you're a burden, that there's no hope. These are symptoms of depression, not facts. Please call 16101 for immediate help."
  ],
  
  // General support and encouragement
  general: [
    "You're doing the best you can with what you have right now. That's enough. Be gentle with yourself. What would feel most supportive right now?",
    "Progress isn't always linear. Some days are harder than others, and that's okay. You're still moving forward, even when it doesn't feel like it.",
    "You've survived 100% of your worst days so far. That's pretty amazing. You're more resilient than you give yourself credit for.",
    "It's okay to not be okay. You don't have to pretend everything is fine. Your feelings are valid and important. I'm here to listen.",
    "You matter more than you know. Your presence makes a difference in ways you might not see. The world is better with you in it."
  ]
};
    "I hear your anxiety. It's your body's alarm system, but you're safe right now. Try this: Name 5 things you can see. This helps ground you. What do you see?",
    "Anxiety is exhausting. Your body is trying to protect you, but you're okay. Let's focus on right now: Feel your feet on the ground. You're safe. What would help most?",
    "I understand anxiety feels scary. Your heart races, thoughts race, but you're safe. Try breathing: In through nose for 4, out through mouth for 6. You've got this.",
    "Anxiety makes everything feel urgent, but you're safe. Let's slow down together. Take one deep breath. In... and out. What's one small thing you can control right now?"
  ],
  
  // Depression responses
  depression: [
    "Depression makes everything feel heavy and hopeless. You're not alone in this feeling. What's one small thing you did today that took courage, even getting out of bed?",
    "I hear your depression. It steals joy and energy, but you're still here, still fighting. That shows incredible strength. What would feel like a small win right now?",
    "Depression lies. It tells you things will never get better, but that's not true. You've survived 100% of your worst days. What helped you before, even a little?",
    "Depression is exhausting. Everything feels like too much. Be gentle with yourself. What's one kind thing you can do for yourself right now, even if it's small?",
    "I hear your depression. It makes everything feel gray and heavy. You're not broken for feeling this way. What would feel even 1% better right now?"
  ],
  
  // Stress responses
  stress: [
    "Stress overwhelms your system. Let's reset: Shoulders up, hold, drop. Roll your neck gently. You're handling so much. What's stressing you most right now?",
    "I hear your stress. Your body is in fight-or-flight. Let's signal safety: Place hand on heart, feel it beat. You're safe. What would help you feel more in control?",
    "Stress makes everything feel urgent and overwhelming. Take one moment: Close eyes, breathe in for 4, out for 6. You're doing your best with a difficult situation.",
    "Stress is your body's response to too much pressure. You're not failing, you're overwhelmed. What's one thing you can let go of, even temporarily?",
    "I hear your stress. It's like carrying a heavy weight. Let's set down one small thing together. What's the least important thing on your mind right now?"
  ],
  
  // Loneliness responses
  loneliness: [
    "Loneliness hurts deeply, especially when you're already struggling. You're not alone in feeling this way, and you're not truly alone - I'm here with you right now. What kind of connection would feel most helpful?",
    "Feeling isolated is painful, but reaching out like you just did takes courage. You're worthy of connection and support. Have you thought about reaching out to someone you trust, even just to say 'hi'?",
    "I hear your loneliness. It's a heavy burden. Even though I'm an AI, I'm fully present with you in this moment. What would help you feel less alone right now?",
    "Loneliness can make everything feel harder. You're not broken for feeling this way. Let's think of one small step - maybe text someone 'thinking of you' or call our hotline to talk with someone who cares."
  ],
  
  // Help seeking responses
  help: [
    "I'm here to help you. Here are your options: 1) Call emergency hotline: 16101 2) Visit our centers 3) Try breathing exercise. What do you need most?",
    "You've done the right thing by reaching out. What kind of help do you need right now - someone to talk, emergency help, or resources?",
    "I want to help you feel better. You have choices: Call our 24/7 hotline, visit our centers, or talk with me. What feels right for you?"
  ],
  
  // Breathing responses
  breathing: [
    "Let's breathe together: 1) Breathe in slowly through nose (count 1-2-3-4) 2) Hold gently (1-2-3-4) 3) Breathe out through mouth (1-2-3-4-5-6). Repeat 3 times. You're doing great!",
    "Breathing helps calm your body. Try this: Breathe in for 4, out for 6. Repeat. Your breath is always there to help you calm down. You're safe.",
    "Simple breathing: In for 4 counts, out for 6 counts. Don't worry about doing it perfectly. Just breathe. You're doing exactly what you need to do."
  ],
  
  // Location responses
  location: [
    "We have 3 centers to help you: 1) Enlightened Hospital 2) National Institute of Mental Health 3) Dhaka Mental Hospital. All have caring doctors ready to help. Which one is closest?",
    "Our centers are safe places with people who understand. You don't have to figure this out alone. Would you like directions to any of our centers?",
    "Professional help makes a big difference. Our centers offer therapy, medication, and support. Taking this step shows real strength. What questions do you have?"
  ],
  
  // Default responses
  defaultResponses: [
    "I hear you. I'm here to help. What's bothering you most right now?",
    "Thank you for telling me that. I want to help you feel better. What's wrong?",
    "I'm listening. Whatever you're feeling is okay. What can I help you with?",
    "You're not alone. I'm here with you. What's on your mind?",
    "I care about how you're feeling. Tell me what's happening."
  ]
};
