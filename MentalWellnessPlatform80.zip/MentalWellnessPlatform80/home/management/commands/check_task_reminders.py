from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import date, time, datetime, timedelta
from home.models import DailyTask, TaskCompletion, Notification


class Command(BaseCommand):
    help = 'Check and send task reminders to patients'
    
    def handle(self, *args, **options):
        self.stdout.write('Starting task reminder check...')
        
        today = date.today()
        now = timezone.now()
        current_time = now.time()
        
        # Check for tasks that need reminders
        incomplete_tasks = self.get_incomplete_tasks(today)
        
        sent_count = 0
        for task_completion in incomplete_tasks:
            if self.should_send_reminder(task_completion, current_time):
                self.send_task_reminder(task_completion)
                sent_count += 1
        
        # Check for end-of-day incomplete tasks
        if current_time.hour >= 20:  # After 8 PM
            self.check_end_of_day_incomplete_tasks(today)
        
        self.stdout.write(f'Sent {sent_count} task reminders')
    
    def get_incomplete_tasks(self, today):
        """Get incomplete tasks for today"""
        return TaskCompletion.objects.filter(
            completion_date=today,
            is_completed=False
        ).select_related('daily_task', 'daily_task__patient')
    
    def should_send_reminder(self, task_completion, current_time):
        """Check if reminder should be sent for this task"""
        daily_task = task_completion.daily_task
        reminder_times = daily_task.reminder_times or ['09:00', '14:00', '20:00']
        
        for reminder_time_str in reminder_times:
            try:
                reminder_time = datetime.strptime(reminder_time_str, '%H:%M').time()
                
                # Check if current time matches reminder time (within 5 minutes)
                time_diff = abs(
                    (current_time.hour * 60 + current_time.minute) - 
                    (reminder_time.hour * 60 + reminder_time.minute)
                )
                
                if time_diff <= 5:
                    # Check if reminder was already sent for this time
                    reminder_key = f"{reminder_time_str}_{task_completion.completion_date}"
                    if reminder_key not in daily_task.reminders_sent:
                        daily_task.reminders_sent[reminder_key] = timezone.now().isoformat()
                        daily_task.save()
                        return True
            except ValueError:
                continue
        
        return False
    
    def send_task_reminder(self, task_completion):
        """Send reminder notification to patient"""
        daily_task = task_completion.daily_task
        patient = daily_task.patient
        
        # Create notification
        Notification.objects.create(
            user=patient,
            title="Task Reminder",
            message=f"Don't forget to complete: {daily_task.title}",
            notification_type="task_reminder",
            is_actionable=True,
            action_url="/patient/dashboard/"
        )
        
        self.stdout.write(f'Sent reminder to {patient.username} for task: {daily_task.title}')
    
    def check_end_of_day_incomplete_tasks(self, today):
        """Send final reminder for incomplete tasks at end of day"""
        incomplete_tasks = TaskCompletion.objects.filter(
            completion_date=today,
            is_completed=False
        ).select_related('daily_task', 'daily_task__patient')
        
        # Group by patient to avoid multiple notifications
        patients_with_incomplete = {}
        for task_completion in incomplete_tasks:
            patient = task_completion.daily_task.patient
            if patient.id not in patients_with_incomplete:
                patients_with_incomplete[patient.id] = {
                    'patient': patient,
                    'tasks': []
                }
            patients_with_incomplete[patient.id]['tasks'].append(task_completion.daily_task.title)
        
        for patient_data in patients_with_incomplete.values():
            patient = patient_data['patient']
            task_titles = ', '.join(patient_data['tasks'])
            
            Notification.objects.create(
                user=patient,
                title="Incomplete Tasks Alert",
                message=f"You have {len(patient_data['tasks'])} incomplete task(s) today: {task_titles}",
                notification_type="task_incomplete",
                is_actionable=True,
                action_url="/patient/dashboard/"
            )
            
            self.stdout.write(f'Sent end-of-day alert to {patient.username}')
