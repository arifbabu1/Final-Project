"""
WebSocket signaling server for video consultations
"""
import json
import asyncio
import logging
from datetime import datetime
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import User
from home.models import Consultation

logger = logging.getLogger(__name__)

class SignalingConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f"consultation_{self.room_name}"
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        # Accept connection
        await self.accept()
        
        logger.info(f"User {self.scope['user'].id} joined consultation room {self.room_name}")
    
    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
        
        # Notify other participants
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_left',
                'user_id': self.scope['user'].id,
                'username': self.scope['user'].get_full_name() or self.scope['user'].username
            }
        )
        
        logger.info(f"User {self.scope['user'].id} left consultation room {self.room_name}")
    
    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            message_type = data.get('type')
            
            if message_type == 'offer':
                await self.handle_offer(data)
            elif message_type == 'answer':
                await self.handle_answer(data)
            elif message_type == 'ice_candidate':
                await self.handle_ice_candidate(data)
            elif message_type == 'chat_message':
                await self.handle_chat_message(data)
            else:
                logger.warning(f"Unknown message type: {message_type}")
                
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON received: {text_data}")
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def handle_offer(self, data):
        # Forward offer to other participants
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'offer',
                'offer': data['offer'],
                'sender_id': self.scope['user'].id,
                'sender_name': self.scope['user'].get_full_name() or self.scope['user'].username
            }
        )
    
    async def handle_answer(self, data):
        # Forward answer to other participants
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'answer',
                'answer': data['answer'],
                'sender_id': self.scope['user'].id,
                'sender_name': self.scope['user'].get_full_name() or self.scope['user'].username
            }
        )
    
    async def handle_ice_candidate(self, data):
        # Forward ICE candidate to other participants
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'ice_candidate',
                'candidate': data['candidate'],
                'sender_id': self.scope['user'].id,
                'sender_name': self.scope['user'].get_full_name() or self.scope['user'].username
            }
        )
    
    async def handle_chat_message(self, data):
        # Save chat message to database and broadcast
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': data['message'],
                'sender_id': self.scope['user'].id,
                'sender_name': self.scope['user'].get_full_name() or self.scope['user'].username,
                'timestamp': datetime.now().isoformat()
            }
        )
