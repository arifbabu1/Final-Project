# Mental Wellness Platform - Complete Deployment Guide

## 🏥 Project Overview

**Mental Wellness Platform** is a comprehensive Django-based web application for mental health support, featuring:
- User authentication and role-based access (Patient, Doctor, Admin)
- Doctor appointment booking and scheduling system
- Patient mental health assessments
- Video consultation rooms
- Prescription and task management
- Blog system for doctors
- Real-time notifications
- Responsive design with modern UI

**Tech Stack:**
- **Backend**: Django 6.0.2, Python 3.9+
- **Database**: SQLite (development), PostgreSQL (production)
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap
- **Authentication**: Django's built-in auth system
- **Real-time**: WebSockets for consultations

---

## 🚀 Option 1: PythonAnywhere (Recommended for Beginners)

### Step 1: Create Account
1. Go to [pythonanywhere.com](https://www.pythonanywhere.com)
2. Sign up for free account (Hobby tier is sufficient)
3. Verify your email address

### Step 2: Upload Your Project
1. Go to Files tab in PythonAnywhere dashboard
2. Upload your entire `MentalWellnessPlatform56` folder
3. Or use Git: `git clone https://github.com/yourusername/MentalWellnessPlatform56.git`

### Step 3: Setup Virtual Environment
```bash
# In PythonAnywhere console
cd ~/MentalWellnessPlatform56
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Step 4: Configure Settings for Production
```python
# In wellness_platform/settings.py
import os
from pathlib import Path

# Security settings
DEBUG = False
ALLOWED_HOSTS = ['yourusername.pythonanywhere.com']
SECRET_KEY = 'your-long-secret-key-here'  # Generate new key for production

# Static files
STATIC_ROOT = '/var/www/yourusername.pythonanywhere.com/staticfiles/'
STATIC_URL = '/static/'

# Database (use PostgreSQL for production)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'yourusername$mentalwellness',
        'USER': 'yourusername',
        'PASSWORD': 'your-db-password',
        'HOST': 'yourusername.postgres.pythonanywhere-services.com',
        'PORT': '5432',
    }
}
```

### Step 5: Setup Database and Static Files
```bash
python manage.py migrate
python manage.py collectstatic --noinput
python manage.py createsuperuser
```

### Step 6: Configure Web App
1. Go to Web tab in PythonAnywhere
2. Add new web app
3. Select Django framework
4. Set Python version to 3.9+
5. Set path to: `/var/www/yourusername.pythonanywhere.com/MentalWellnessPlatform56`
6. Set virtualenv path: `/var/www/yourusername.pythonanywhere.com/venv`
7. Reload web app
7. Reload web app

---

## Option 2: Heroku

### Step 1: Install Heroku CLI
```bash
# Download from devcenter.heroku.com
heroku login
```

### Step 2: Create Heroku App
```bash
heroku create your-app-name
```

### Step 3: Add Procfile
Create `Procfile` in project root:
```
web: gunicorn yourproject.wsgi:application
```

### Step 4: Update Settings
```python
# In settings.py
import django_heroku
django_heroku.settings()
```

### Step 5: Deploy
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
heroku run python manage.py migrate
```

---

## Option 3: Vercel + Railway

### Step 1: Frontend on Vercel
1. Create `vercel.json`:
```json
{
  "version": 2,
  "builds": [
    {"src": "static/**/*", "use": "@vercel/static"}
  ],
  "routes": [
    {"src": "/static/(.*)", "dest": "/static/$1"}
  ]
}
```

### Step 2: Backend on Railway
1. Create `railway.toml`:
```toml
[build]
builder = "NIXPACKS"

[deploy]
startCommand = "gunicorn yourproject.wsgi:application"
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 10
```

### Step 3: Deploy
```bash
# Frontend
vercel --prod

# Backend
railway login
railway link
railway up
```

---

## Option 4: Render

### Step 1: Create `render.yaml`
```yaml
services:
  - type: web
    name: mental-wellness-platform
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: gunicorn yourproject.wsgi:application
    envVars:
      - key: DEBUG
        value: false
      - key: DATABASE_URL
        fromDatabase:
          name: mental-wellness-db
          property: connectionString
```

### Step 2: Deploy
1. Connect GitHub repository to Render
2. Render will auto-deploy on push

---

## Required Files for Deployment

### 1. `.gitignore`
```
*.pyc
__pycache__/
venv/
env/
db.sqlite3
.DS_Store
*.log
```

### 2. `runtime.txt` (for Heroku)
```
python-3.9.16
```

### 3. Update `settings.py`
```python
import os
from pathlib import Path

# Security
DEBUG = os.getenv('DEBUG', 'False') == 'True'
ALLOWED_HOSTS = ['localhost', 'yourdomain.com', 'yourapp.herokuapp.com']

# Database
DATABASES = {
    'default': dj_database_url.parse(os.getenv('DATABASE_URL'))
}

# Static files
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATIC_URL = '/static/'

# Security settings
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
```

---

## Free Tier Limitations

| Platform | Free Tier Limits | Best For |
|----------|------------------|----------|
| PythonAnywhere | 1 app, 512MB RAM | Beginners |
| Heroku | Sleeps after 30min | Testing |
| Vercel | Serverless functions | Frontend |
| Netlify | Static sites | JAMstack |
| Railway | $5 credit/month | Small projects |
| Render | Sleeps after 15min | Production |

---

## Recommended Choice: PythonAnywhere

**Why PythonAnywhere?**
- Designed specifically for Python/Django
- No credit card required
- Easy setup process
- Built-in database support
- Good for learning deployment

**Quick Steps:**
1. Upload project to PythonAnywhere
2. Install requirements
3. Configure settings
4. Run migrations
5. Setup web app
6. Go live!

Your site will be available at: `https://yourusername.pythonanywhere.com`
