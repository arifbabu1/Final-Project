from django.shortcuts import render, redirect, get_object_or_404

from django.contrib.auth import login, logout, authenticate

from django.contrib.auth.decorators import login_required

from django.contrib import messages

from django.http import JsonResponse

from django.utils import timezone

from django.db import IntegrityError

from django.db.models import Q

from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation

import json
import logging

import random

import string

logger = logging.getLogger(__name__)



# Import admin views

from . import admin_views



# Import admin payment view directly

from .admin_views import admin_payments



from .models import (

    User, Doctor, AssessmentQuestion, PatientAssessment, 

    AssessmentAnswer, Appointment, Consultation, Payment,

    HealthTaskTemplate, Prescription, DailyTask, TaskCompletion, Notification, BlogPost,

    DoctorSchedule, BookedSlot, DoctorSpecialization, DoctorPrimaryFocus

)

from .recommendation_engine import (
    DYNAMIC_QUESTION_GROUPS,
    build_assessment_profile,
    get_dynamic_response_payload,
    recommend_doctors,
)
from .doctor_config import (
    DEFAULT_PRIMARY_FOCUS,
    DOCTOR_PRIMARY_FOCUS_CHOICES,
    DOCTOR_PRIMARY_FOCUS_VALUES,
    DOCTOR_SPECIALIZATION_CHOICES,
    DOCTOR_SPECIALIZATION_VALUES,
)


def _doctor_availability_text(value):
    if isinstance(value, dict):
        if 'notes' in value:
            return value.get('notes') or ''
        return json.dumps(value) if value else ''
    return value or ''


def _doctor_form_context(request, doctor=None, is_edit=False):
    selected_specializations = getattr(doctor, 'specialization_values', [])
    selected_primary_focuses = getattr(doctor, 'primary_focus_values', [])
    if request.method == 'POST':
        selected_specializations = request.POST.getlist('specialization') or request.POST.getlist('specializations')
        selected_primary_focuses = request.POST.getlist('primary_focus') or request.POST.getlist('primary_focuses')

    return {
        'doctor': doctor,
        'user': request.user,
        'is_edit': is_edit,
        'specialization_choices': DOCTOR_SPECIALIZATION_CHOICES,
        'primary_focus_choices': DOCTOR_PRIMARY_FOCUS_CHOICES,
        'selected_specializations': selected_specializations,
        'selected_primary_focuses': selected_primary_focuses,
        'availability_schedule_text': _doctor_availability_text(getattr(doctor, 'availability_schedule', '')),
    }


def _parse_non_negative_int(value, field_label, required=True, max_value=50):
    if value in (None, ''):
        if required:
            raise ValueError(f'{field_label} is required.')
        return 0
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise ValueError(f'{field_label} must be a valid number.')
    if parsed < 0 or parsed > max_value:
        raise ValueError(f'{field_label} must be between 0 and {max_value}.')
    return parsed


def _parse_consultation_fee(value):
    if value in (None, ''):
        return None
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('Consultation fee must be a valid amount.')
    if parsed < 0:
        raise ValueError('Consultation fee cannot be negative.')
    return parsed


def _validate_doctor_profile_payload(request):
    post = request.POST
    required_fields = {
        'first_name': 'First name',
        'last_name': 'Last name',
        'email': 'Email address',
        'phone': 'Phone number',
        'qualification': 'Qualification',
        'years_of_experience': 'Years of experience',
        'license_number': 'License number',
    }

    data = {}
    for field, label in required_fields.items():
        data[field] = (post.get(field) or '').strip()
        if not data[field]:
            raise ValueError(f'{label} is required.')

    specializations = [value.strip() for value in post.getlist('specialization') if value.strip()]
    if not specializations:
        specializations = [value.strip() for value in post.getlist('specializations') if value.strip()]
    if not specializations and post.get('specialty'):
        specializations = [(post.get('specialty') or '').strip()]
    if not specializations:
        raise ValueError('Please choose at least one specialization.')
    invalid_specializations = [value for value in specializations if value not in DOCTOR_SPECIALIZATION_VALUES]
    if invalid_specializations:
        raise ValueError('Please choose valid specializations only.')
    data['specialization'] = list(dict.fromkeys(specializations))

    primary_focuses = [value.strip() for value in post.getlist('primary_focus') if value.strip()]
    if not primary_focuses:
        primary_focuses = [value.strip() for value in post.getlist('primary_focuses') if value.strip()]
    if not primary_focuses:
        raise ValueError('Please choose at least one primary focus.')
    invalid_focuses = [value for value in primary_focuses if value not in DOCTOR_PRIMARY_FOCUS_VALUES]
    if invalid_focuses:
        raise ValueError('Please choose valid primary focus areas only.')
    data['primary_focus'] = list(dict.fromkeys(primary_focuses))

    data['years_of_experience'] = _parse_non_negative_int(data['years_of_experience'], 'Years of experience')
    data['consultation_fee'] = _parse_consultation_fee((post.get('consultation_fee') or '').strip())
    data['clinic_name'] = (post.get('clinic_name') or '').strip()
    data['clinic_address'] = (post.get('clinic_address') or '').strip()
    data['bio'] = (post.get('bio') or '').strip()
    availability_notes = (post.get('availability_schedule') or '').strip()
    data['availability_schedule'] = {'notes': availability_notes} if availability_notes else {}

    duplicate_email = User.objects.filter(email=data['email']).exclude(pk=request.user.pk).exists()
    if duplicate_email:
        raise ValueError('This email address is already in use.')

    return data


def _save_doctor_profile(request, doctor, data):
    request.user.first_name = data['first_name']
    request.user.last_name = data['last_name']
    request.user.email = data['email']
    request.user.phone = data['phone']
    request.user.save(update_fields=['first_name', 'last_name', 'email', 'phone'])

    doctor.name = request.user.get_full_name()
    doctor.qualification = data['qualification']
    doctor.years_of_experience = data['years_of_experience']
    doctor.consultation_fee = data['consultation_fee']
    doctor.clinic_name = data['clinic_name']
    doctor.clinic_address = data['clinic_address']
    doctor.license_number = data['license_number']
    doctor.bio = data['bio']
    doctor.availability_schedule = data['availability_schedule']

    profile_picture = request.FILES.get('profile_picture')
    if profile_picture:
        doctor.profile_image = profile_picture

    doctor.save()

    specialization_options = DoctorSpecialization.objects.filter(value__in=data['specialization'], is_active=True)
    focus_options = DoctorPrimaryFocus.objects.filter(value__in=data['primary_focus'], is_active=True)
    doctor.specializations.set(specialization_options)
    doctor.primary_focuses.set(focus_options)


def _doctor_specialization_values(doctor):
    values = getattr(doctor, 'specialization_values', None)
    if values is not None:
        return set(values)
    value = getattr(doctor, 'specialty', None)
    if isinstance(value, (list, tuple, set)):
        return set(value)
    return {value} if value else set()


def _doctor_primary_focus_values(doctor):
    values = getattr(doctor, 'primary_focus_values', None)
    if values is not None:
        return set(values)
    value = getattr(doctor, 'primary_focus', None)
    if isinstance(value, (list, tuple, set)):
        return set(value)
    return {value} if value else set()


def _available_doctors_matching_specializations(specializations, focus_values=None):
    match_filter = Q(specializations__value__in=specializations)
    if focus_values:
        match_filter |= Q(primary_focuses__value__in=focus_values)
    return Doctor.objects.filter(
        match_filter,
        is_available=True,
    ).distinct().select_related('user').prefetch_related('specializations', 'primary_focuses')





def home(request):

    """Landing page"""

    return render(request, 'home/homepage.html')





def emergency(request):

    """Emergency help page"""

    return render(request, 'home/emergency.html')





def about(request):

    """About page"""

    return render(request, 'home/about.html')





def blogs(request):

    """

    Render the blogs page with mental health articles and resources.

    Public access for visitors showing general blog content.

    """

    # Get user's last assessment result (only for logged-in patients)

    last_assessment = None

    stress_level = None

    

    # If user is authenticated and is a patient, get their assessment

    if request.user.is_authenticated and request.user.role == 'patient':

        try:

            last_assessment = PatientAssessment.objects.filter(

                patient=request.user

            ).order_by('-created_at').first()

            

            if last_assessment:

                stress_level = last_assessment.stress_level

        except:

            pass

    

    # Get published blogs from database

    published_blogs = BlogPost.objects.filter(status='published').order_by('-published_at')

    

    # Get featured blog

    featured_blog = published_blogs.filter(is_featured=True).first()

    if not featured_blog:

        featured_blog = published_blogs.first()

    

    # Get all other blogs for the general section

    all_blogs = published_blogs.exclude(id=featured_blog.id) if featured_blog else published_blogs

    

    # Get blogs by category

    categories = BlogPost.CATEGORY_CHOICES

    category_blogs = {}

    for cat_key, cat_name in categories:

        category_blogs[cat_key] = published_blogs.filter(category=cat_key)[:3]

    

    # Check if a specific category is requested (from assessment results)

    selected_category = None

    selected_category_blogs = []

    selected_category_name = ''

    

    # Get category from GET parameter (for direct links)

    category_param = request.GET.get('category')

    if category_param and category_param in dict(categories).keys():

        selected_category = category_param

        selected_category_blogs = published_blogs.filter(category=selected_category)

        selected_category_name = dict(categories).get(selected_category, '')

    

    context = {

        'user': request.user,

        'last_assessment': last_assessment,

        'stress_level': stress_level,

        'featured_blog': featured_blog,

        'all_blogs': all_blogs,

        'category_blogs': category_blogs,

        'categories': categories,

        'selected_category': selected_category,

        'selected_category_blogs': selected_category_blogs,

        'selected_category_name': selected_category_name,

    }

    return render(request, 'patient/blogs.html', context)





def services(request):

    """Services page"""

    return render(request, 'home/services.html')





def contact(request):

    """Contact page"""

    return render(request, 'home/contact.html')





def register(request):

    """User registration page"""

    if request.method == 'POST':

        # Get form data

        username = request.POST.get('username')

        email = request.POST.get('email')

        phone = request.POST.get('phone')

        password = request.POST.get('password1')

        confirm_password = request.POST.get('password2')

        role = 'patient'  # All public registrations are patients

        

        # New fields

        first_name = request.POST.get('first_name', '')

        last_name = request.POST.get('last_name', '')

        age = request.POST.get('age', '')

        gender = request.POST.get('gender', '')

        previous_treatment = request.POST.get('previous_mental_health_treatment', '')

        concerns = request.POST.getlist('concerns')

        medications = request.POST.get('medications', '')

        

        # Validation

        if password != confirm_password:

            messages.error(request, 'Passwords do not match')

            return render(request, 'auth/register.html')

        

        if User.objects.filter(username=username).exists():

            messages.error(request, 'Username already exists')

            return render(request, 'auth/register.html')

        

        if User.objects.filter(email=email).exists():

            messages.error(request, 'Email already exists')

            return render(request, 'auth/register.html')

        

        # if User.objects.filter(phone=phone).exists():

        #     messages.error(request, 'Phone number already exists')

        #     return render(request, 'auth/register.html')

        

        # Create user

        user_age = None
        if age:
            try:
                user_age = int(age)
            except (TypeError, ValueError):
                user_age = None

        user = User.objects.create_user(

            username=username,

            email=email,

            phone=phone,

            password=password,

            role=role,

            first_name=first_name,

            last_name=last_name,

            age=user_age,

            gender=gender or None

        )

        

        # Store additional patient information in session for later use

        if role == 'patient':

            request.session['patient_info'] = {

                'age': age,

                'gender': gender,

                'previous_treatment': previous_treatment,

                'concerns': concerns,

                'medications': medications

            }

        

        # If doctor, create doctor profile

        if role == 'doctor':

            return redirect('complete_doctor_profile', user_id=user.id)

        

        messages.success(request, 'Registration successful! Please login.')

        return redirect('login')

    

    return render(request, 'auth/register.html')





def login_view(request):

    """User login page"""

    if request.method == 'POST':

        username = request.POST.get('username')

        password = request.POST.get('password')

        

        user = authenticate(request, username=username, password=password)

        if user is not None:

            login(request, user)

            

            # Redirect based on role

            if user.role == 'admin':

                return redirect('admin_dashboard')

            elif user.role == 'doctor':

                return redirect('doctor_dashboard')

            else:

                return redirect('patient_dashboard')

        else:

            messages.error(request, 'Invalid credentials')

    

    return render(request, 'auth/login.html')





def logout_view(request):

    """User logout"""

    logout(request)

    return redirect('home')





def forgot_password(request):

    """Step 1: Show form to enter first name and mobile number"""

    return render(request, 'auth/forgot_password.html')





def forgot_password_verify(request):

    """Step 2: Verify first name and mobile number, then allow password reset"""

    if request.method == 'POST':

        first_name = request.POST.get('first_name', '').strip()

        phone = request.POST.get('phone', '').strip()



        if not first_name or not phone:

            messages.error(request, 'Please enter both first name and mobile number.')

            return render(request, 'auth/forgot_password.html')



        # Normalize phone number to handle different formats

        normalized_phone = phone

        

        # Remove any spaces, dashes, or parentheses

        normalized_phone = normalized_phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')

        

        # If phone starts with +880, keep it as is

        # If phone starts with 01, add +880 prefix

        if normalized_phone.startswith('+880'):

            normalized_phone = normalized_phone

        elif normalized_phone.startswith('01'):

            normalized_phone = '+880' + normalized_phone

        # If phone starts with 880 (without +), add +

        elif normalized_phone.startswith('880') and len(normalized_phone) >= 11:

            normalized_phone = '+' + normalized_phone



        try:

            # Try with normalized phone first

            user = User.objects.get(first_name__iexact=first_name, phone=normalized_phone)

            # Store verified user id in session

            request.session['reset_user_id'] = user.id

            return render(request, 'auth/forgot_password_reset.html', {'reset_user': user})

        except User.DoesNotExist:

            # If normalized phone doesn't work, try the original input

            try:

                user = User.objects.get(first_name__iexact=first_name, phone=phone)

                request.session['reset_user_id'] = user.id

                return render(request, 'auth/forgot_password_reset.html', {'reset_user': user})

            except User.DoesNotExist:

                messages.error(request, 'No account found with that first name and mobile number combination.')

                return render(request, 'auth/forgot_password.html')



    return redirect('forgot_password')





def forgot_password_reset(request):

    """Step 3: Set new password after identity verification"""

    reset_user_id = request.session.get('reset_user_id')



    if not reset_user_id:

        messages.error(request, 'Please verify your identity first.')

        return redirect('forgot_password')



    try:

        user = User.objects.get(id=reset_user_id)

    except User.DoesNotExist:

        messages.error(request, 'User not found. Please try again.')

        return redirect('forgot_password')



    if request.method == 'POST':

        new_password = request.POST.get('new_password', '').strip()

        confirm_password = request.POST.get('confirm_password', '').strip()



        if not new_password or not confirm_password:

            messages.error(request, 'Please fill in both password fields.')

            return render(request, 'auth/forgot_password_reset.html', {'reset_user': user})



        if len(new_password) < 6:

            messages.error(request, 'Password must be at least 6 characters long.')

            return render(request, 'auth/forgot_password_reset.html', {'reset_user': user})



        if new_password != confirm_password:

            messages.error(request, 'Passwords do not match.')

            return render(request, 'auth/forgot_password_reset.html', {'reset_user': user})



        user.set_password(new_password)

        user.save()

        # Clear session

        if 'reset_user_id' in request.session:

            del request.session['reset_user_id']



        messages.success(request, 'Password reset successful! You can now log in with your new password.')

        return redirect('login')



    return render(request, 'auth/forgot_password_reset.html', {'reset_user': user})





@login_required

def edit_doctor_profile(request):

    """Edit existing doctor profile"""

    if request.user.role != 'doctor':

        return redirect('home')

    

    try:

        doctor = request.user.doctor_profile

    except Doctor.DoesNotExist:

        return redirect('complete_doctor_profile', user_id=request.user.id)

    

    if request.method == 'POST':
        try:
            data = _validate_doctor_profile_payload(request)
            _save_doctor_profile(request, doctor, data)
            messages.success(request, 'Profile updated successfully!')
            return redirect('doctor_dashboard')
        except ValueError as error:
            messages.error(request, str(error))
        except Exception:
            messages.error(request, 'Unable to update your profile. Please try again.')

    return render(request, 'doctor/complete_profile.html', _doctor_form_context(request, doctor, is_edit=True))





@login_required

def complete_doctor_profile(request, user_id):

    """Complete doctor profile after registration"""

    if request.user.id != user_id or request.user.role != 'doctor':

        return redirect('home')

    

    # Check if doctor profile already exists

    try:

        doctor_profile = request.user.doctor_profile

        messages.info(request, 'Your profile is already complete!')

        return redirect('doctor_dashboard')

    except Doctor.DoesNotExist:

        pass  # Profile doesn't exist, continue with creation

    

    if request.method == 'POST':
        try:
            data = _validate_doctor_profile_payload(request)
            doctor = Doctor(user=request.user)
            _save_doctor_profile(request, doctor, data)
            messages.success(request, 'Doctor profile completed successfully!')
            return redirect('doctor_dashboard')
        except ValueError as error:
            messages.error(request, str(error))
        except IntegrityError:
            messages.error(request, 'A doctor profile already exists for this account.')
        except Exception:
            messages.error(request, 'Unable to complete your profile. Please try again.')

    return render(request, 'doctor/complete_profile.html', _doctor_form_context(request))





@login_required

def patient_dashboard(request):

    """Patient dashboard"""

    if request.user.role != 'patient':

        return redirect('home')

    

    from datetime import date

    

    recent_assessments = PatientAssessment.objects.filter(

        patient=request.user

    ).order_by('-created_at')[:5]

    

    upcoming_appointments = Appointment.objects.filter(

        patient=request.user,

        appointment_date__gte=timezone.now(),

        status__in=['scheduled', 'confirmed']

    ).order_by('appointment_date')[:5]

    

    # Get today's tasks - SIMPLIFIED VERSION

    today = date.today()

    

    # Force refresh tasks from database (clear any potential caching)

    from django.db import transaction

    transaction.commit()

    

    # Get only active tasks

    all_patient_tasks = DailyTask.objects.filter(

        patient=request.user,

        is_active=True

    ).order_by('-created_at')

    

    # Create task items for display (simplified)

    active_today_tasks = []

    for task in all_patient_tasks:

        # Get or create today's completion record

        completion, created = TaskCompletion.objects.get_or_create(

            daily_task=task,

            completion_date=today,

            defaults={'is_completed': False}

        )

        active_today_tasks.append({

            'task': task,

            'completion': completion

        })

    # Get unread notifications

    unread_notifications = Notification.objects.filter(

        user=request.user,

        is_read=False

    )[:5]

    

    # Get recent prescriptions - SIMPLIFIED VERSION

    recent_prescriptions = Prescription.objects.filter(

        patient=request.user

    ).order_by('-created_at')[:5]

    

    context = {

        'recent_assessments': recent_assessments,

        'upcoming_appointments': upcoming_appointments,

        'today_tasks': active_today_tasks,

        'unread_notifications': unread_notifications,

        'recent_prescriptions': recent_prescriptions,

        'total_tasks': len(active_today_tasks),

        'completed_tasks': len([t for t in active_today_tasks if t['completion'].is_completed]),

    }

    return render(request, 'patient/dashboard.html', context)





@login_required

def test_patient_data(request):

    """Test endpoint to check patient data"""

    if request.user.role != 'patient':

        return JsonResponse({'error': 'Not a patient'}, status=403)

    

    from datetime import date

    

    # Get all data for this patient

    prescriptions = Prescription.objects.filter(patient=request.user).values('id', 'prescription_text', 'created_at', 'medications')

    tasks = DailyTask.objects.filter(patient=request.user, is_active=True).values('id', 'title', 'description', 'created_at', 'start_date', 'end_date')

    

    return JsonResponse({

        'success': True,

        'prescriptions': list(prescriptions),

        'tasks': list(tasks),

        'prescriptions_count': prescriptions.count(),

        'tasks_count': tasks.count()

    })





@login_required

def send_message(request):

    """API endpoint for sending messages to patients"""

    if request.user.role != 'doctor':

        return JsonResponse({'error': 'Unauthorized'}, status=401)

    

    if request.method != 'POST':

        return JsonResponse({'error': 'Method not allowed'}, status=405)

    

    try:

        data = json.loads(request.body)

        patient_id = data.get('patient_id')

        message_text = data.get('message')

        

        if not patient_id or not message_text:

            return JsonResponse({'error': 'Patient ID and message are required'}, status=400)

        

        # Get patient

        patient = get_object_or_404(User, id=patient_id, role='patient')

        

        # In a real implementation, you would:

        # 1. Save the message to a Message model

        # 2. Send notification to patient

        # 3. Create notification record

        

        # For now, we'll just simulate success

        # You could create a Notification model entry here

        

        # Create notification for patient

        try:

            from .models import Notification

            Notification.objects.create(

                user=patient,

                title='New message from Dr. ' + request.user.get_full_name(),

                message=message_text,

                notification_type='message'

            )

        except:

            pass  # Notification model might not exist or have different fields

        

        return JsonResponse({'success': True, 'message': 'Message sent successfully'})

        

    except json.JSONDecodeError:

        return JsonResponse({'error': 'Invalid JSON'}, status=400)

    except Exception as e:

        return JsonResponse({'error': str(e)}, status=500)





@login_required

def analytics(request):

    """API endpoint for doctor analytics"""

    if request.user.role != 'doctor':

        return JsonResponse({'error': 'Unauthorized'}, status=401)

    

    try:

        doctor = request.user.doctor_profile

        

        # Get all appointments for this doctor

        appointments = Appointment.objects.filter(doctor=doctor)

        

        # Calculate metrics

        total_patients = appointments.values('patient').distinct().count()

        completed_sessions = appointments.filter(status='completed').count()

        

        # Calculate total earnings

        total_earnings = 0

        for payment in Payment.objects.filter(appointment__doctor=doctor, status='completed'):

            total_earnings += payment.doctor_earning or 0

        

        data = {

            'total_patients': total_patients,

            'completed_sessions': completed_sessions,

            'total_earnings': int(total_earnings),

        }

        

        return JsonResponse(data)

    

    except Exception as e:

        return JsonResponse({'error': str(e)}, status=500)





@login_required

def appointment_details(request, appointment_id):

    """API endpoint for appointment details"""

    if request.user.role != 'doctor':

        return JsonResponse({'error': 'Unauthorized'}, status=401)

    

    try:

        appointment = get_object_or_404(Appointment, id=appointment_id, doctor__user=request.user)

        

        data = {

            'patient_name': appointment.patient.get_full_name() or appointment.patient.username,

            'date': appointment.appointment_date.strftime('%B %d, %Y'),

            'time': appointment.appointment_date.strftime('%I:%M %p'),

            'status': appointment.get_status_display(),

            'consultation_type': 'Video Consultation',

            'fee': str(appointment.consultation_fee) if appointment.consultation_fee else 'Not Set',

            'notes': appointment.notes or ''

        }

        

        return JsonResponse(data)

    

    except Exception as e:

        return JsonResponse({'error': str(e)}, status=500)





@login_required

def doctor_dashboard(request):

    """Doctor dashboard"""

    if request.user.role != 'doctor':

        return redirect('home')

    

    try:

        doctor = request.user.doctor_profile

    except Doctor.DoesNotExist:

        return redirect('complete_doctor_profile', user_id=request.user.id)

    

    # Get current date in the correct timezone

    from django.utils import timezone

    

    # Django automatically uses the timezone from settings.py (Asia/Dhaka)

    now = timezone.now()

    today = now.date()

    

    # Filter today's appointments using Django's timezone-aware date filtering

    today_appointments = Appointment.objects.filter(

        doctor=doctor,

        appointment_date__date=today,

        status__in=['scheduled', 'confirmed']

    ).select_related('patient').order_by('appointment_date')

    

    upcoming_appointments = Appointment.objects.filter(

        doctor=doctor,

        appointment_date__gt=now,

        status__in=['scheduled', 'confirmed']

    ).select_related('patient').order_by('appointment_date')[:10]

    

    context = {

        'doctor': doctor,

        'today_appointments': today_appointments,

        'upcoming_appointments': upcoming_appointments,

        'today_date': today.strftime('%B %d, %Y'),

    }

    return render(request, 'doctor/dashboard.html', context)





@login_required

def admin_dashboard(request):

    """Admin dashboard"""

    if request.user.role != 'admin':

        return redirect('home')

    

    total_users = User.objects.count()

    total_patients = User.objects.filter(role='patient').count()

    total_doctors = User.objects.filter(role='doctor').count()

    total_appointments = Appointment.objects.count()

    

    recent_appointments = Appointment.objects.all().order_by('-created_at')[:10]

    

    context = {

        'total_users': total_users,

        'total_patients': total_patients,

        'total_doctors': total_doctors,

        'total_appointments': total_appointments,

        'recent_appointments': recent_appointments,

    }

    return render(request, 'admin/dashboard.html', context)





@login_required

def assessment(request):

    """Rule-based weighted mental health assessment"""

    if request.user.role != 'patient':

        return redirect('home')

    

    questions = list(AssessmentQuestion.objects.all().order_by('track_number', 'id')[:7])

    

    if request.method == 'POST':

        total_score = 0

        answers = []
        core_answers = []

        

        for question in questions:

            answer_value = int(request.POST.get(f'question_{question.id}', 0))
            answer_value = max(0, min(4, answer_value))

            total_score += answer_value * question.weight_value
            core_answers.append(answer_value)

            answers.append({

                'question_id': question.id,

                'answer_value': answer_value

            })

        

        initial_profile = build_assessment_profile(core_answers, request.user)
        dynamic_responses = get_dynamic_response_payload(request.POST, initial_profile['triggered_modules'])
        result_profile = build_assessment_profile(core_answers, request.user, dynamic_responses)
        stress_level = result_profile['severity_level'].lower()

        

        # Create assessment record

        assessment = PatientAssessment.objects.create(

            patient=request.user,

            total_score=total_score,

            stress_level=stress_level,

            recommendations=(
                f"Primary concern: {result_profile['primary_condition']}. "
                f"Severity: {result_profile['severity_level']}. "
                "Consider consulting with one of the recommended mental health professionals."
            ),

            dynamic_responses=dynamic_responses,

            result_summary=result_profile

        )

        

        # Save answers

        for answer_data in answers:

            AssessmentAnswer.objects.create(

                assessment=assessment,

                question_id=answer_data['question_id'],

                answer_value=answer_data['answer_value']

            )

        

        return redirect('assessment_results', assessment_id=assessment.id)

    

    context = {
        'questions': questions,
        'dynamic_question_groups': DYNAMIC_QUESTION_GROUPS,
        'profile_age': request.user.age,
    }

    return render(request, 'patient/assessment.html', context)





@login_required

def assessment_results(request, assessment_id):

    """Assessment results page"""

    if request.user.role != 'patient':

        return redirect('home')

    

    assessment = get_object_or_404(PatientAssessment, id=assessment_id, patient=request.user)

    answers = assessment.answers.select_related('question').order_by('question__track_number', 'question__id')
    core_answers = [answer.answer_value for answer in answers[:7]]
    if assessment.result_summary:
        result_profile = assessment.result_summary
    else:
        result_profile = build_assessment_profile(core_answers, request.user, assessment.dynamic_responses)

    

    # Calculate category scores

    category_scores = {}

    for answer in answers:

        category = answer.question.category

        if category not in category_scores:

            category_scores[category] = 0

        category_scores[category] += answer.answer_value * answer.question.weight_value

    

    # Generate personalized recommendations based on scores and stress level

    recommendations = generate_personalized_recommendations(assessment.stress_level, category_scores)

    

    # Get blog recommendations based on stress level

    recommended_blog_categories = []

    if assessment.stress_level:

        stress_level_mapping = {

            'low': ['mindfulness', 'self-care', 'sleep'],

            'moderate': ['anxiety', 'workplace', 'self-care'],

            'high': ['depression', 'therapy', 'relationships'],

            'severe': ['therapy', 'depression', 'anxiety']

        }

        recommended_blog_categories = stress_level_mapping.get(

            assessment.stress_level, 

            ['mindfulness', 'self-care']

        )

    

    # Get actual blogs from database

    recommended_blogs = []

    if recommended_blog_categories:

        published_blogs = BlogPost.objects.filter(status='published')

        recommended_blogs = published_blogs.filter(

            category__in=recommended_blog_categories

        )[:4]  # Show up to 4 recommended blogs

    

    # 🚀 Get advanced doctor recommendations based on assessment
    candidate_doctors = Doctor.objects.filter(is_available=True).select_related('user').prefetch_related('specializations', 'primary_focuses')
    recommended_doctors = recommend_doctors(candidate_doctors, result_profile, limit=5)

    for doctor_rec in recommended_doctors:
        doctor_rec['actual_patients_helped'] = Appointment.objects.filter(
            doctor=doctor_rec['doctor'],
            status='completed'
        ).values('patient').distinct().count()

    # Calculate PHQ-9 and GAD-7 scores for display
    phq9_score = category_scores.get('Depression', 0)
    gad7_score = category_scores.get('Anxiety', 0)

    # Get severity levels
    depression_severity = get_depression_severity(phq9_score)
    anxiety_severity = get_anxiety_severity(gad7_score)

    # Detect emergency
    emergency = result_profile['emotional_risk_level'] == 'High'

    # Determine primary condition
    primary_condition = result_profile['primary_condition']


    context = {

        'assessment': assessment,

        'answers': answers,

        'category_scores': category_scores,

        'score_breakdown': result_profile['category_scores'],

        'dynamic_questions_triggered': result_profile['triggered_modules'],

        'dynamic_scores': result_profile.get('dynamic_scores', {}),

        'recommendations': recommendations,

        'recommended_blog_categories': recommended_blog_categories,

        'recommended_blogs': recommended_blogs,

        'categories': BlogPost.CATEGORY_CHOICES,

        'recommended_doctors': recommended_doctors,

        'phq9_score': phq9_score,

        'gad7_score': gad7_score,

        'depression_severity': depression_severity,

        'anxiety_severity': anxiety_severity,

        'emergency': emergency,

        'primary_condition': primary_condition,

        'secondary_condition': result_profile['secondary_condition'],

        'severity_level': result_profile['severity_level'],

        'emotional_risk_level': result_profile['emotional_risk_level'],

    }

    return render(request, 'patient/assessment_results.html', context)





def get_recommended_doctors_advanced(stress_level, category_scores):
    """
    🚀 UPDATED DOCTOR RECOMMENDATION ENGINE
    Based on PHQ-9 and GAD-7 clinical scoring system
    """
    from home.models import Doctor

    # 🧮 STEP 1: Calculate PHQ-9 and GAD-7 scores
    phq9_score = category_scores.get('Depression', 0)
    gad7_score = category_scores.get('Anxiety', 0)

    # 🧠 STEP 2: Detect severity
    depression_severity = get_depression_severity(phq9_score)
    anxiety_severity = get_anxiety_severity(gad7_score)

    # 🚨 STEP 3: Emergency detection (check for suicide risk)
    # In PHQ-9, question 9 is about self-harm thoughts
    # We'll check if depression score is very high as a proxy
    emergency = phq9_score >= 15  # Moderately severe to severe depression

    # 🧠 STEP 4: Detect primary condition
    if phq9_score >= gad7_score:
        primary_condition = "Depression"
        severity = depression_severity
    else:
        primary_condition = "Anxiety"
        severity = anxiety_severity

    # 🏥 STEP 5: Filter suitable doctors based on severity
    allowed_specialties = get_allowed_specialties(severity, emergency)

    # Get candidate doctors
    candidate_doctors = _available_doctors_matching_specializations(allowed_specialties, [primary_condition])

    # 🧠 STEP 6: Calculate match scores for each doctor
    doctor_results = []
    for doctor in candidate_doctors:
        score = calculate_doctor_match_score(
            doctor,
            primary_condition,
            severity,
            emergency
        )
        doctor_results.append({
            'doctor': doctor,
            'total_score': score,
            'match_percentage': score
        })

    # 🏆 STEP 7: Sort and return top 3
    doctor_results.sort(key=lambda x: x['total_score'], reverse=True)
    return doctor_results[:3]


def get_depression_severity(score):
    """Detect depression severity based on PHQ-9 score"""
    if score <= 4:
        return "Minimal"
    elif score <= 9:
        return "Mild"
    elif score <= 14:
        return "Moderate"
    elif score <= 19:
        return "Moderately Severe"
    return "Severe"


def get_anxiety_severity(score):
    """Detect anxiety severity based on GAD-7 score"""
    if score <= 4:
        return "Minimal"
    elif score <= 9:
        return "Mild"
    elif score <= 14:
        return "Moderate"
    return "Severe"


def get_allowed_specialties(severity, emergency):
    """Get allowed specialties based on severity and emergency status"""
    # Severe cases or emergency
    if severity in ['Severe', 'Moderately Severe'] or emergency:
        return ['Psychiatrist', 'Clinical Psychologist']

    # Moderate cases
    elif severity == 'Moderate':
        return ['Clinical Psychologist', 'Therapist']

    # Mild cases
    else:
        return ['Counselor', 'Therapist', 'Clinical Psychologist']


def calculate_doctor_match_score(doctor, primary_condition, severity, emergency):
    """
    🧠 NEW MATCHING FORMULA
    Factor | Weight
    Specialty Match | 45
    Severity Suitability | 25
    Expertise Tags | 15
    Experience | 10
    Availability | 5
    TOTAL = 100
    """
    score = 0
    specializations = _doctor_specialization_values(doctor)
    focus_areas = _doctor_primary_focus_values(doctor)

    # SPECIALTY MATCH (45 points)
    if severity in ['Severe', 'Moderately Severe']:
        if 'Psychiatrist' in specializations:
            score += 45
        elif 'Clinical Psychologist' in specializations:
            score += 40
    else:
        if 'Clinical Psychologist' in specializations:
            score += 45
        elif 'Therapist' in specializations:
            score += 40
        elif 'Counselor' in specializations:
            score += 35

    # PRIMARY FOCUS MATCH (25 points)
    if primary_condition in focus_areas:
        score += 25
    elif primary_condition == 'Depression' and focus_areas & {'Stress', 'Sleep'}:
        score += 15
    elif primary_condition == 'Anxiety' and 'Stress' in focus_areas:
        score += 15

    # EXPERTISE TAGS (15 points)
    if doctor.expertise_tags:
        # Check if primary condition or related terms are in expertise tags
        condition_keywords = {
            'Depression': ['depression', 'mood', 'sadness', 'hopeless'],
            'Anxiety': ['anxiety', 'worry', 'panic', 'fear', 'nervous']
        }
        keywords = condition_keywords.get(primary_condition, [])

        for tag in doctor.expertise_tags:
            tag_lower = tag.lower()
            if any(keyword in tag_lower for keyword in keywords):
                score += 15
                break

    # EXPERIENCE (10 points)
    if doctor.years_of_experience >= 10:
        score += 10
    elif doctor.years_of_experience >= 5:
        score += 7
    elif doctor.years_of_experience >= 2:
        score += 4
    else:
        score += 2

    # AVAILABILITY (5 points)
    if doctor.available_online:
        score += 5

    # EMERGENCY BONUS (extra 10 points if emergency and doctor supports it)
    if emergency and doctor.emergency_support:
        score += 10

    return min(score, 100)





def calculate_normalized_tracks(category_scores):

    """

    🧮 Calculate normalized scores for each track (0.0-1.0 scale)

    Prevents question count bias

    """

    # Track maximum possible scores

    track_max_scores = {

        'Depression': 36,    # (Q1*3) + (Q2*3) + (Q7*3) = 12*3

        'Anxiety': 16,       # (Q3*2) + (Q4*2) = 8*2

        'Sleep': 8,          # Q5*2 = 4*2

        'Energy': 4           # Q6*1 = 4*1

    }

    

    normalized_scores = {}

    for category, raw_score in category_scores.items():

        max_score = track_max_scores.get(category, 1)

        normalized_scores[category] = raw_score / max_score if max_score > 0 else 0

    

    return normalized_scores





def identify_primary_condition(track_scores):

    """

    🎯 Identify patient's dominant medical concern

    """

    if not track_scores:

        return 'Stress', 0.0

    

    primary_condition = max(track_scores.items(), key=lambda x: x[1])[0]

    primary_severity = track_scores[primary_condition]

    

    return primary_condition, primary_severity





def apply_clinical_triage(primary_condition, primary_severity):

    """

    🛡️ Clinical triage filtering for patient safety

    """

    from home.models import Doctor

    

    # Scenario A: High Severity (>= 0.50) - Specialists only

    if primary_severity >= 0.50:

        if primary_condition in ['Depression', 'Anxiety']:

            return _available_doctors_matching_specializations(['Psychiatrist', 'Clinical Psychologist'], [primary_condition])

        else:

            return _available_doctors_matching_specializations(['Psychiatrist', 'Therapist'], [primary_condition])

    

    # Scenario B: Mild to Moderate (< 0.50) - General practitioners

    else:

        if primary_condition in ['Sleep', 'Energy']:

            return _available_doctors_matching_specializations(['Psychiatrist', 'Therapist'], [primary_condition])

        else:

            return _available_doctors_matching_specializations(['Clinical Psychologist', 'Therapist', 'Counselor'], [primary_condition])





def score_doctors_advanced(doctors, primary_condition, primary_severity, track_scores):

    """

    📊 Advanced 100-point scoring system

    """

    from home.models import Appointment

    

    scored_doctors = []

    

    for doctor in doctors:

        # 🎯 Focus Alignment (40 Points Max)

        focus_score = 0

        focus_areas = _doctor_primary_focus_values(doctor)

        if primary_condition in focus_areas:

            focus_score = 40

        elif focus_areas & set(track_scores.keys()):

            focus_score = 20

        

        # 🔍 Sub-Symptom Keyword Alignment (40 Points Max)

        keyword_score = 0

        if doctor.expertise_tags:

            # Check for secondary elevated concerns

            for category, severity in track_scores.items():

                if severity >= 0.50 and category != primary_condition:

                    if any(tag.lower() in [expertise.lower() for expertise in doctor.expertise_tags] 

                          for tag in get_category_keywords(category)):

                        keyword_score = 30

                        break

            else:

                keyword_score = 10

        

        # 💪 Professional Longevity (20 Points Max)

        experience_score = 0

        if doctor.years_of_experience >= 10:

            experience_score = 20

        elif doctor.years_of_experience >= 5:

            experience_score = 10

        elif doctor.years_of_experience >= 2:

            experience_score = 5

        

        quality_score = 0

        if hasattr(doctor, 'success_rate') and doctor.success_rate >= 80:

            quality_score += 5

        

        # 📈 Calculate total score and percentage

        total_score = focus_score + keyword_score + experience_score + quality_score

        match_percentage = min(99, int((total_score / 100) * 100))

        

        # 📊 Get actual patients helped

        actual_patients_helped = Appointment.objects.filter(

            doctor=doctor,

            status='completed'

        ).values('patient').distinct().count()

        

        # 🎯 Generate personalized match reason

        match_reason = generate_advanced_match_reason(

            doctor, primary_condition, primary_severity, 

            focus_score, keyword_score, experience_score

        )

        

        scored_doctors.append({

            'doctor': doctor,

            'total_score': total_score,

            'match_percentage': match_percentage,

            'match_reason': match_reason,

            'actual_patients_helped': actual_patients_helped,

            'score_breakdown': {

                'focus_alignment': focus_score,

                'keyword_match': keyword_score,

                'experience': experience_score,

                'quality_bonus': quality_score

            },

            'clinical_triage': {

                'primary_condition': primary_condition,

                'severity_level': primary_severity,

                'triage_level': 'high' if primary_severity >= 0.50 else 'moderate'

            }

        })

    

    return scored_doctors





def get_category_keywords(category):

    """

    🔍 Get symptom keywords for each category

    """

    keyword_mapping = {

        'Depression': ['depression', 'sadness', 'hopeless', 'worthless', 'guilt', 'fatigue'],

        'Anxiety': ['anxiety', 'panic', 'worry', 'fear', 'nervous', 'stress'],

        'Sleep': ['insomnia', 'sleep', 'tired', 'exhausted', 'fatigue', 'restless'],

        'Energy': ['energy', 'tired', 'exhausted', 'low-energy', 'fatigue', 'lethargic']

    }

    return keyword_mapping.get(category, [])





def generate_advanced_match_reason(doctor, primary_condition, severity, focus_score, keyword_score, experience_score):

    """

    🎯 Generate personalized match reason with clinical context

    """

    severity_level = 'severe' if severity >= 0.50 else 'moderate'

    

    reasons = {

        'Psychiatrist': f"🧠 Advanced psychiatric care for {severity_level} {primary_condition.lower()}. Can provide medication management and comprehensive treatment plans.",

        'Clinical Psychologist': f"🎓 Clinical psychology specialist for {severity_level} {primary_condition.lower()}. Expert in evidence-based therapeutic interventions.",

        'Therapist': f"💊 Specialized therapeutic interventions for your {primary_condition.lower()} symptoms. Uses evidence-based treatment modalities.",

        'Counselor': f"💪 Expert counseling and coping strategies for {severity_level} {primary_condition.lower()}. Focus on practical emotional support."

    }

    

    base_reason = reasons.get(doctor.specialty, f"🏥 Experienced in treating {severity_level} {primary_condition.lower()} conditions")

    

    # Add scoring context

    if focus_score == 40:

        base_reason += f" ✅ Perfect specialty match for your {primary_condition} concerns."

    elif keyword_score >= 30:

        base_reason += f" 🔍 Expertise in your specific symptom patterns."

    elif experience_score >= 20:

        base_reason += f" 💪 Extensive clinical experience ({doctor.years_of_experience}+ years)."

    

    return base_reason





def get_match_reason(doctor_specialty, stress_level, category_scores):

    """Generate reason why this doctor is recommended"""

    

    # Find the highest scoring category

    highest_category = max(category_scores.items(), key=lambda x: x[1])[0] if category_scores else 'general'

    

    reasons = {

        'Psychiatrist': f"Can provide medication management and comprehensive care for {stress_level} mental health conditions",

        'Counselor': f"Expert in counseling and coping strategies for {stress_level} stress and emotional challenges",

        'Therapist': f"Provides specialized therapeutic interventions for your specific needs",

        'Clinical Psychologist': f"Highly qualified to treat complex {stress_level} mental health conditions"

    }

    

    return reasons.get(doctor_specialty, f"Experienced in treating patients with similar assessment profiles")





def generate_personalized_recommendations(stress_level, category_scores):

    """Generate personalized recommendations based on assessment results"""

    recommendations = []
    stress_level = (stress_level or '').lower()

    

    # Base recommendations by stress level

    if stress_level == 'low':

        recommendations.append({

            'icon': '✅',

            'title': 'Continue Your Wellness Journey',

            'description': 'Your mental health appears to be in good shape. Continue practicing self-care, maintaining healthy habits, and regular check-ins to sustain your wellbeing.',

            'priority': 'low',

            'actionable_steps': [

                'Maintain regular sleep schedule (7-9 hours)',

                'Continue physical activity (30 mins daily)',

                'Practice mindfulness or meditation 10-15 minutes daily',

                'Stay connected with supportive friends and family',

                'Engage in hobbies and activities you enjoy'

            ]

        })

    elif stress_level == 'moderate':

        recommendations.append({

            'icon': '💡',

            'title': 'Consider Professional Support',

            'description': 'Your results suggest moderate stress levels. Speaking with a mental health professional can provide valuable tools and strategies for managing stress effectively.',

            'priority': 'medium',

            'actionable_steps': [

                'Schedule consultation with a mental health professional',

                'Practice stress management techniques (deep breathing, progressive muscle relaxation)',

                'Establish healthy boundaries in work and personal life',

                'Consider cognitive behavioral therapy techniques',

                'Join support groups or wellness communities'

            ]

        })

    elif stress_level == 'high':

        recommendations.append({

            'icon': '🎯',

            'title': 'Professional Help Recommended',

            'description': 'We strongly recommend connecting with a mental health professional for personalized support and guidance. Your symptoms may benefit from professional intervention.',

            'priority': 'high',

            'actionable_steps': [

                'Seek immediate consultation with a mental health professional',

                'Consider therapy or counseling sessions',

                'Practice daily stress reduction techniques',

                'Inform trusted family members or friends about your situation',

                'Create a structured daily routine for stability'

            ]

        })

    elif stress_level == 'severe':

        recommendations.append({

            'icon': '🚨',

            'title': 'Immediate Support Available',

            'description': 'Your results suggest significant distress. Please don\'t hesitate to reach out for immediate professional support. Help is available and you don\'t have to face this alone.',

            'priority': 'urgent',

            'actionable_steps': [

                'Contact mental health professional immediately',

                'Call emergency hotline: 16101',

                'Reach out to trusted family or friends',

                'Consider crisis intervention services',

                'Remove yourself from overwhelming situations if possible'

            ]

        })

    

    # Category-specific recommendations with detailed analysis

    for category, score in category_scores.items():

        if score >= 15:  # High score in category indicates concern

            if category == 'Depression':

                recommendations.append({

                    'icon': '🌧️',

                    'title': 'Focus on Mood Management',

                    'description': 'Your responses indicate symptoms of depression. Focus on activities that boost mood and consider professional support for comprehensive care.',

                    'priority': 'high',

                    'actionable_steps': [

                        'Engage in regular physical exercise (releases endorphins)',

                        'Get sunlight exposure daily (15-30 minutes)',

                        'Practice gratitude journaling (3 things daily)',

                        'Connect with supportive people regularly',

                        'Consider antidepressant medications with professional guidance',

                        'Establish a consistent daily routine',

                        'Limit alcohol and avoid recreational drugs',

                        'Practice self-compassion and positive self-talk'

                    ]

                })

            elif category == 'Anxiety':

                recommendations.append({

                    'icon': '🧘',

                    'title': 'Practice Anxiety Management',

                    'description': 'Your anxiety levels appear elevated. Learning relaxation techniques and coping strategies can significantly help manage anxiety symptoms.',

                    'priority': 'high',

                    'actionable_steps': [

                        'Practice 4-7-8 breathing technique (inhale 4, hold 7, exhale 8)',

                        'Try progressive muscle relaxation daily',

                        'Limit caffeine and stimulant intake',

                        'Practice mindfulness meditation (10-20 minutes daily)',

                        'Challenge anxious thoughts with cognitive restructuring',

                        'Create a worry time limit (15-20 minutes daily)',

                        'Use grounding techniques (5-4-3-2-1 method)',

                        'Consider anti-anxiety medications if prescribed'

                    ]

                })

            elif category == 'Sleep':

                recommendations.append({

                    'icon': '😴',

                    'title': 'Improve Sleep Hygiene',

                    'description': 'Quality sleep is crucial for mental health. Establishing proper sleep habits can significantly improve your overall wellbeing.',

                    'priority': 'medium',

                    'actionable_steps': [

                        'Maintain consistent sleep schedule (same bedtime/wake time)',

                        'Avoid screens 1 hour before bed (blue light affects melatonin)',

                        'Create relaxing bedtime routine (reading, gentle music)',

                        'Keep bedroom cool, dark, and quiet',

                        'Avoid caffeine after 2 PM',

                        'Exercise regularly but not within 3 hours of bedtime',

                        'Consider natural sleep aids (melatonin, valerian root)',

                        'Limit fluids 2 hours before bedtime'

                    ]

                })

            elif category == 'Energy':

                recommendations.append({

                    'icon': '⚡',

                    'title': 'Boost Energy Levels Naturally',

                    'description': 'Low energy can impact daily functioning. Focus on nutrition, exercise, and lifestyle changes to improve your energy levels.',

                    'priority': 'medium',

                    'actionable_steps': [

                        'Eat balanced meals with protein, complex carbs, healthy fats',

                        'Stay hydrated (8 glasses of water daily)',

                        'Take short walks every 2 hours',

                        'Practice good posture to improve energy flow',

                        'Consider vitamin B12 and D supplements',

                        'Limit processed foods and sugar',

                        'Take power naps (10-20 minutes) if needed',

                        'Practice stress management to conserve energy'

                    ]

                })

            elif category == 'Self-esteem':

                recommendations.append({

                    'icon': '💪',

                    'title': 'Build Self-Confidence',

                    'description': 'Working on self-esteem can improve overall mental health. Focus on self-acceptance and personal growth strategies.',

                    'priority': 'medium',

                    'actionable_steps': [

                        'Practice positive affirmations daily',

                        'Set and achieve small, realistic goals',

                        'Keep a success journal (document achievements)',

                        'Challenge negative self-talk with evidence',

                        'Learn new skills or hobbies to build competence',

                        'Surround yourself with supportive people',

                        'Practice self-care without guilt',

                        'Consider therapy to work on self-worth issues'

                    ]

                })

    

    # Add lifestyle recommendations based on overall pattern

    if len([s for s in category_scores.values() if s >= 15]) >= 3:

        recommendations.append({

            'icon': '🌟',

            'title': 'Comprehensive Lifestyle Reset',

            'description': 'Multiple areas show elevated concern. A holistic approach to lifestyle changes can create significant improvement across all areas.',

            'priority': 'high',

            'actionable_steps': [

                'Create a structured daily schedule',

                'Implement morning routine (exercise, meditation, healthy breakfast)',

                'Practice digital detox (limit screen time)',

                'Establish work-life boundaries',

                'Join group activities or classes',

                'Consider nutritional counseling',

                'Practice time management techniques',

                'Build a strong support network'

            ]

        })

    

    # Add positive reinforcement for areas doing well

    good_categories = [cat for cat, score in category_scores.items() if score < 10]

    if good_categories:

        recommendations.append({

            'icon': '🌈',

            'title': 'Build on Your Strengths',

            'description': f'You\'re showing good progress in: {", ".join(good_categories)}. Continue these positive practices while working on other areas.',

            'priority': 'low',

            'actionable_steps': [

                'Continue what\'s working well in these areas',

                'Share your successful strategies with others',

                'Use these strengths as motivation for other areas',

                'Teach or mentor others in your strong areas',

                'Document your successful techniques',

                'Celebrate your progress regularly'

            ]

        })

    

    return recommendations





@login_required

def doctors_list(request):

    """List of available doctors"""

    if request.user.role != 'patient':

        return redirect('home')

    

    doctors = Doctor.objects.filter(is_available=True).select_related('user').prefetch_related('specializations', 'primary_focuses')

    

    context = {'doctors': doctors}

    return render(request, 'patient/doctors.html', context)





@login_required

def book_appointment(request, doctor_id):

    """Book appointment with a doctor - checks doctor availability schedule"""

    if request.user.role != 'patient':

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(id=doctor_id, is_available=True)

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor not found or not available. Please choose another doctor.')

        return redirect('doctors_list')

    

    from datetime import datetime, timedelta

    

    # Check if doctor has any schedules set up

    doctor_schedules = DoctorSchedule.objects.filter(doctor=doctor, is_available=True)

    if not doctor_schedules.exists():

        messages.error(request, 'This doctor has not set up their availability schedule yet. Please choose another doctor.')

        return redirect('doctors_list')

    

    # Get available dates (next 14 days) that match doctor's schedule

    available_dates = []

    available_weekdays = set(doctor_schedules.values_list('day_of_week', flat=True))

    

    for i in range(14):  # Check next 14 days

        date = datetime.now() + timedelta(days=i)

        weekday = date.weekday()

        

        # Only include dates where doctor has availability

        if weekday in available_weekdays:

            available_dates.append({

                'date': date.strftime('%Y-%m-%d'),

                'day_name': date.strftime('%A'),

                'formatted_date': date.strftime('%b %d'),

                'is_today': i == 0

            })

    

    # Get selected date from request or find next available day with future slots

    selected_date_str = request.GET.get('date')

    selected_time_slots = []

    

    # If no date selected, find the next available day with future time slots

    if not selected_date_str and available_dates:

        current_time = datetime.now().time()

        today = datetime.now().date()

        

        for date_info in available_dates:

            test_date = datetime.strptime(date_info['date'], '%Y-%m-%d').date()

            weekday = test_date.weekday()

            

            # Get doctor's schedules for this day

            day_schedules = doctor_schedules.filter(day_of_week=weekday)

            

            if day_schedules.exists():

                # Check if there are any future slots for this day

                has_future_slots = False

                if test_date == today:

                    # For today, check if any slots are in the future

                    for schedule in day_schedules:

                        slots = schedule.get_time_slots()

                        for slot_time_str in slots:

                            slot_time = datetime.strptime(slot_time_str, '%H:%M').time()

                            if slot_time > current_time:

                                has_future_slots = True

                                break

                        if has_future_slots:

                            break

                else:

                    # For future dates, all slots are available

                    has_future_slots = True

                

                if has_future_slots:

                    selected_date_str = date_info['date']

                    break

    

    # Fallback to first available if no specific date found

    if not selected_date_str and available_dates:

        selected_date_str = available_dates[0]['date']

    

    if selected_date_str:

        try:

            selected_date = datetime.strptime(selected_date_str, '%Y-%m-%d').date()

            weekday = selected_date.weekday()

            

            # Get doctor's schedules for this day

            day_schedules = doctor_schedules.filter(day_of_week=weekday)

            

            # Get already booked slots for this date

            booked_slots = BookedSlot.objects.filter(

                doctor=doctor,

                appointment_date=selected_date,

                is_active=True

            ).values_list('appointment_time', flat=True)

            

            # Generate time slots from doctor's schedule

            for schedule in day_schedules:

                slots = schedule.get_time_slots()

                for slot_time_str in slots:

                    slot_time = datetime.strptime(slot_time_str, '%H:%M').time()

                    

                    # Parse time for display

                    hour = slot_time.hour

                    minute = slot_time.minute

                    if hour < 12:

                        period = "AM"

                        display_hour = hour if hour != 0 else 12

                    else:

                        period = "PM"

                        display_hour = hour - 12 if hour != 12 else 12

                    

                    time_str = f"{display_hour}:{minute:02d} {period}"

                    

                    # Check if slot is already booked

                    is_booked = slot_time in booked_slots

                    

                    # For today, hide past times

                    is_past = False

                    if selected_date == datetime.now().date():

                        current_time = datetime.now().time()

                        if slot_time <= current_time:

                            is_past = True

                    

                    selected_time_slots.append({

                        'time': time_str,

                        'time_24h': slot_time_str,

                        'available': not is_booked and not is_past,

                        'is_booked': is_booked

                    })

        except (ValueError, IndexError):

            pass

    

    if request.method == 'POST':

        appointment_date = request.POST.get('appointment_date')

        appointment_time = request.POST.get('appointment_time')

        consultation_type = request.POST.get('consultation_type', 'video')

        payment_method = request.POST.get('payment_method', 'card')

        notes = request.POST.get('notes', '')

        

        # Validate date and time

        if not appointment_date or not appointment_time:

            messages.error(request, 'Please select both date and time for your appointment.')

            context = {

                'doctor': doctor,

                'available_dates': available_dates,

                'time_slots': selected_time_slots,

                'selected_date': selected_date_str

            }

            return render(request, 'patient/book_appointment.html', context)

        

        # Parse time and create datetime

        try:

            time_obj = datetime.strptime(appointment_time, '%I:%M %p')

            appointment_datetime = datetime.strptime(f"{appointment_date} {time_obj.strftime('%H:%M')}", '%Y-%m-%d %H:%M')

            

            # Check if the selected slot is still available

            selected_time_24h = time_obj.strftime('%H:%M')

            selected_time_obj = datetime.strptime(selected_time_24h, '%H:%M').time()

            selected_date_obj = datetime.strptime(appointment_date, '%Y-%m-%d').date()

            

            # Check if slot is already booked

            existing_booking = BookedSlot.objects.filter(

                doctor=doctor,

                appointment_date=selected_date_obj,

                appointment_time=selected_time_obj,

                is_active=True

            ).exists()

            

            if existing_booking:

                messages.error(request, 'This time slot has just been booked by another patient. Please select a different time.')

                context = {

                    'doctor': doctor,

                    'available_dates': available_dates,

                    'time_slots': selected_time_slots,

                    'selected_date': selected_date_str

                }

                return render(request, 'patient/book_appointment.html', context)

            

        except ValueError:

            messages.error(request, 'Invalid appointment date or time format')

            context = {

                'doctor': doctor,

                'available_dates': available_dates,

                'time_slots': selected_time_slots,

                'selected_date': selected_date_str

            }

            return render(request, 'patient/book_appointment.html', context)

        

        # Check if doctor has consultation fee

        if not doctor.consultation_fee:

            messages.error(request, 'This doctor does not have a consultation fee set. Please contact support.')

            context = {

                'doctor': doctor,

                'available_dates': available_dates,

                'time_slots': selected_time_slots,

                'selected_date': selected_date_str

            }

            return render(request, 'patient/book_appointment.html', context)

        

        # Create appointment

        appointment = Appointment.objects.create(

            patient=request.user,

            doctor=doctor,

            appointment_date=appointment_datetime,

            consultation_fee=doctor.consultation_fee,

            notes=notes,

            status='pending_payment'

        )

        

        # Create booked slot to mark this time as taken

        BookedSlot.objects.create(

            doctor=doctor,

            appointment_date=selected_date_obj,

            appointment_time=selected_time_obj,

            appointment=appointment,

            is_active=True

        )

        

        # Create payment record

        payment = Payment.objects.create(

            appointment=appointment,

            amount=doctor.consultation_fee,

            admin_commission=0,

            doctor_earning=0,

            status='pending',

            payment_method=payment_method

        )

        

        messages.success(request, 'Appointment created! Please complete the payment to confirm your booking.')

        return redirect('process_payment', payment_id=payment.id)

    

    context = {

        'doctor': doctor,

        'available_dates': available_dates,

        'time_slots': selected_time_slots,

        'selected_date': selected_date_str

    }

    return render(request, 'patient/book_appointment.html', context)





@login_required

def process_payment(request, payment_id):

    """Process payment for appointment"""

    if request.user.role != 'patient':

        return redirect('home')

    

    try:

        payment = Payment.objects.get(id=payment_id, appointment__patient=request.user)

        appointment = payment.appointment

        doctor = appointment.doctor

    except Payment.DoesNotExist:

        messages.error(request, 'Payment not found.')

        return redirect('patient_appointments')

    

    if request.method == 'POST':

        if payment.payment_method == 'card':

            card_number = request.POST.get('card_number')

            card_name = request.POST.get('card_name')

            card_expiry = request.POST.get('card_expiry')

            card_cvv = request.POST.get('card_cvv')

            

            # Validate card details

            if not all([card_number, card_name, card_expiry, card_cvv]):

                messages.error(request, 'Please fill in all card details.')

            elif len(card_number.replace(' ', '')) < 13:

                messages.error(request, 'Please enter a valid card number.')

            elif len(card_cvv) < 3:

                messages.error(request, 'Please enter a valid CVV.')

            else:

                # ACTUAL PAYMENT PROCESSING CODE (COMMENTED FOR TESTING)

                """

                # Process card payment with payment gateway

                try:

                    # Call payment gateway API here

                    gateway_response = process_card_payment(

                        card_number=card_number,

                        card_name=card_name,

                        card_expiry=card_expiry,

                        card_cvv=card_cvv,

                        amount=payment.amount

                    )

                    

                    if gateway_response['status'] == 'success':

                        payment.status = 'completed'

                        payment.transaction_id = gateway_response['transaction_id']

                        payment.calculate_commission()

                        payment.save()

                    else:

                        payment.status = 'failed'

                        payment.save()

                        messages.error(request, f'Payment failed: {gateway_response["message"]}')

                        return render(request, 'patient/process_payment.html', context)

                        

                except Exception as e:

                    payment.status = 'failed'

                    payment.save()

                    messages.error(request, f'Payment processing error: {str(e)}')

                    return render(request, 'patient/process_payment.html', context)

                """

                

                # TESTING MODE: Simulate successful payment

                payment.status = 'completed'

                payment.transaction_id = f"CARD_TEST_{datetime.now().strftime('%Y%m%d%H%M%S')}"

                payment.receiving_account = 'ucb'  # Card payments go to UCB Bank account

                payment.calculate_commission()

                payment.save()

                

                # Generate meeting link and complete appointment

                meeting_link = generate_meeting_link(appointment)

                appointment.meeting_link = meeting_link

                appointment.status = 'confirmed'

                appointment.save()

                

                # Send notifications

                send_payment_notifications(appointment, doctor, meeting_link)

                

                messages.success(request, 'Payment successful! Your appointment is confirmed. Meeting link sent to your email.')

                return redirect('patient_appointments')

        

        elif payment.payment_method in ['bkash', 'nagad']:

            mobile_number = request.POST.get('mobile_number')

            

            # Validate mobile number

            if not mobile_number:

                messages.error(request, 'Please enter your mobile number.')

            elif len(mobile_number) < 11:

                messages.error(request, 'Please enter a valid mobile number (11 digits).')

            else:

                # ACTUAL MOBILE PAYMENT PROCESSING CODE (COMMENTED FOR TESTING)

                """

                # Process mobile payment with payment gateway

                try:

                    # Call mobile payment API here (bKash/Nagad)

                    gateway_response = process_mobile_payment(

                        payment_method=payment.payment_method,

                        mobile_number=mobile_number,

                        amount=payment.amount

                    )

                    

                    if gateway_response['status'] == 'success':

                        payment.status = 'completed'

                        payment.transaction_id = gateway_response['transaction_id']

                        payment.calculate_commission()

                        payment.save()

                    else:

                        payment.status = 'failed'

                        payment.save()

                        messages.error(request, f'Payment failed: {gateway_response["message"]}')

                        return render(request, 'patient/process_payment.html', context)

                        

                except Exception as e:

                    payment.status = 'failed'

                    payment.save()

                    messages.error(request, f'Payment processing error: {str(e)}')

                    return render(request, 'patient/process_payment.html', context)

                """

                

                # TESTING MODE: Simulate successful payment

                payment.status = 'completed'

                payment.transaction_id = f"{payment.payment_method.upper()}_TEST_{datetime.now().strftime('%Y%m%d%H%M%S')}"

                # Automatically assign receiving account based on payment method

                payment.receiving_account = payment.payment_method  # bKash -> bkash, Nagad -> nagad

                payment.calculate_commission()

                payment.save()

                

                # Generate meeting link and complete appointment

                meeting_link = generate_meeting_link(appointment)

                appointment.meeting_link = meeting_link

                appointment.status = 'confirmed'

                appointment.save()

                

                # Send notifications

                send_payment_notifications(appointment, doctor, meeting_link)

                

                messages.success(request, f'Payment successful via {payment.payment_method.title()}! Your appointment is confirmed. Meeting link sent to your email.')

                return redirect('patient_appointments')

    

    context = {

        'payment': payment,

        'appointment': appointment,

        'doctor': doctor

    }

    return render(request, 'patient/process_payment.html', context)





def generate_meeting_link(appointment):

    """Generate unique meeting link for consultation"""

    import secrets

    

    # Generate unique meeting ID

    meeting_id = secrets.token_urlsafe(8)

    meeting_link = f"http://127.0.0.1:8000/consultation/{appointment.id}/"

    

    # Save meeting details

    appointment.meeting_id = meeting_id

    appointment.meeting_link = meeting_link

    

    return meeting_link





def send_payment_notifications(appointment, doctor, meeting_link):

    """Send notifications to patient and doctor"""

    from django.core.mail import send_mail

    from django.conf import settings

    from django.template.loader import render_to_string

    

    patient = appointment.patient

    doctor_user = doctor.user

    

    # Email to Patient

    patient_subject = "Appointment Confirmed - Meeting Link Inside"

    patient_message = f"""

    Dear {patient.get_full_name() or patient.username},

    

    Your appointment has been confirmed!

    

    Appointment Details:

    - Doctor: Dr. {doctor_user.get_full_name()}

    - Date: {appointment.appointment_date.strftime('%B %d, %Y at %I:%M %p')}

    - Meeting Link: {meeting_link}

    

    Please join the meeting 5 minutes before your scheduled time.

    

    Best regards,

    Wellness Platform Team

    """

    

    # Email to Doctor

    doctor_subject = "New Appointment Scheduled - Meeting Link Inside"

    doctor_message = f"""

    Dear Dr. {doctor_user.get_full_name()},

    

    You have a new appointment scheduled!

    

    Appointment Details:

    - Patient: {patient.get_full_name() or patient.username}

    - Date: {appointment.appointment_date.strftime('%B %d, %Y at %I:%M %p')}

    - Meeting Link: {meeting_link}

    

    Please join the meeting 5 minutes before the scheduled time.

    

    Best regards,

    Wellness Platform Team

    """

    

    try:

        # Send emails (commented for testing - uncomment when email is configured)

        """

        send_mail(

            patient_subject,

            patient_message,

            settings.DEFAULT_FROM_EMAIL,

            [patient.email],

            fail_silently=False,

        )

        

        send_mail(

            doctor_subject,

            doctor_message,

            settings.DEFAULT_FROM_EMAIL,

            [doctor_user.email],

            fail_silently=False,

        )

        """

        

    except Exception as e:

        # Log error but don't fail the payment process

        logger.warning("Appointment email notification failed: %s", e)

    

    # Create in-app notifications (you might want to create a Notification model)

    """

    # Patient notification

    Notification.objects.create(

        user=patient,

        title="Appointment Confirmed",

        message=f"Your appointment with Dr. {doctor_user.get_full_name()} is confirmed. Meeting link: {meeting_link}",

        appointment=appointment

    )

    

    # Doctor notification

    Notification.objects.create(

        user=doctor_user,

        title="New Appointment",

        message=f"New appointment with {patient.get_full_name() or patient.username}. Meeting link: {meeting_link}",

        appointment=appointment

    )

    """





@login_required

def mark_appointment_completed(request, appointment_id):

    """Mark an appointment as completed"""

    if request.user.role != 'patient':

        return JsonResponse({'success': False, 'error': 'Unauthorized'})

    

    if request.method == 'POST':

        try:

            appointment = Appointment.objects.get(id=appointment_id, patient=request.user)

            if appointment.status in ['scheduled', 'confirmed']:

                appointment.status = 'completed'

                appointment.save()

                

                return JsonResponse({

                    'success': True,

                    'message': 'Appointment marked as completed successfully!'

                })

            else:

                return JsonResponse({

                    'success': False,

                    'error': 'Appointment cannot be marked as completed'

                })

                

        except Appointment.DoesNotExist:

            return JsonResponse({'success': False, 'error': 'Appointment not found'})

    

    return JsonResponse({'success': False, 'error': 'Invalid request'})





@login_required

def delete_appointment(request, appointment_id):

    """Delete appointment with pending payment or missed appointments"""

    if request.user.role != 'patient':

        return redirect('home')

    

    try:

        appointment = Appointment.objects.get(id=appointment_id, patient=request.user)

        

        # Allow deletion of appointments with pending payment or missed/cancelled appointments

        if appointment.status not in ['pending_payment', 'missed', 'cancelled']:

            messages.error(request, 'You can only delete appointments with pending payment or missed/cancelled appointments.')

            return redirect('patient_appointments')

        

        # Delete the appointment and related payment if exists

        if hasattr(appointment, 'payment'):

            appointment.payment.delete()

        appointment.delete()

        

        messages.success(request, 'Appointment deleted successfully.')

        

    except Appointment.DoesNotExist:

        messages.error(request, 'Appointment not found.')

    

    return redirect('patient_appointments')





@login_required

def patient_appointments(request):

    """Patient appointments list"""

    if request.user.role != 'patient':

        return redirect('home')

    

    from django.utils import timezone

    today = timezone.now().date()

    now = timezone.now()

    

    # Auto-update appointment statuses based on time

    # Mark appointments as completed if they're past their appointment time

    # This immediately moves attended appointments to past appointments

    Appointment.objects.filter(

        appointment_date__lt=now,

        status__in=['scheduled', 'confirmed']

    ).update(status='completed')

    

    # Note: We're not using "missed" status anymore since completed covers all past appointments

    # This simplifies the logic and ensures attended appointments move to past appointments immediately

    

    # Get all appointments for the patient

    all_appointments = Appointment.objects.filter(

        patient=request.user

    ).select_related('doctor__user').order_by('-appointment_date')

    

    # Separate today's appointments (only active ones)

    today_appointments = all_appointments.filter(

        appointment_date__date=today,

        status__in=['pending_payment', 'scheduled', 'confirmed']

    )

    

    # Upcoming appointments (excluding today)

    upcoming_appointments = all_appointments.filter(

        appointment_date__date__gt=today,

        status__in=['pending_payment', 'scheduled', 'confirmed']

    )

    

    # Past appointments (including completed, cancelled, missed, and old scheduled/confirmed)

    past_appointments = all_appointments.filter(

        Q(appointment_date__date__lt=today) | 

        Q(status__in=['completed', 'cancelled', 'missed'])

    ).distinct()

    

    context = {

        'appointments': all_appointments,

        'today_appointments': today_appointments,

        'upcoming_appointments': upcoming_appointments,

        'past_appointments': past_appointments,

    }

    return render(request, 'patient/appointments.html', context)





@login_required

def doctor_details(request, doctor_id):

    """Doctor details page"""

    try:

        doctor = Doctor.objects.get(id=doctor_id)

        

        # Get doctor's upcoming appointments for availability

        upcoming_appointments = Appointment.objects.filter(

            doctor=doctor,

            status__in=['scheduled', 'confirmed'],

            appointment_date__gte=timezone.now().date()

        ).order_by('appointment_date')[:5]

        

        # Get doctor's completed appointments count

        completed_appointments = Appointment.objects.filter(

            doctor=doctor,

            status='completed'

        ).count()

        

        context = {

            'doctor': doctor,

            'upcoming_appointments': upcoming_appointments,

            'completed_appointments': completed_appointments,

        }

        return render(request, 'patient/doctor_details.html', context)

        

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor not found.')

        return redirect('doctors_list')





@login_required

def doctor_appointments(request):

    """Doctor appointments list"""

    if request.user.role != 'doctor':

        return redirect('home')

    

    try:

        doctor = request.user.doctor_profile

        

        # Get all appointments for this doctor

        all_appointments = Appointment.objects.filter(

            doctor=doctor

        ).select_related('patient').order_by('-appointment_date')

        

        # Filter upcoming appointments (future dates and not completed)

        upcoming_appointments = all_appointments.filter(

            appointment_date__gt=timezone.now(),

            status__in=['scheduled', 'confirmed']

        )

        

        # Filter past appointments (completed or cancelled)

        past_appointments = all_appointments.filter(

            Q(appointment_date__lt=timezone.now()) | Q(status__in=['completed', 'cancelled'])

        )

        

        context = {

            'appointments': all_appointments,

            'upcoming_appointments': upcoming_appointments,

            'past_appointments': past_appointments,

            'doctor': doctor

        }

        return render(request, 'doctor/appointments.html', context)

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor profile not found')

        return redirect('home')





@login_required

def consultation_room(request, appointment_id):

    """Video consultation room"""

    appointment = get_object_or_404(Appointment, id=appointment_id)

    

    # Check permissions

    if request.user.role == 'patient' and appointment.patient != request.user:

        return redirect('home')

    elif request.user.role == 'doctor' and appointment.doctor.user != request.user:

        return redirect('home')

    

    # Check if appointment is confirmed

    if appointment.status != 'confirmed':

        messages.error(request, 'Consultation room is only available for confirmed appointments.')

        return redirect('patient_appointments' if request.user.role == 'patient' else 'doctor_appointments')

    

    # Get or create consultation

    consultation, created = Consultation.objects.get_or_create(

        appointment=appointment,

        defaults={

            'room_name': appointment.meeting_id or f"room_{appointment.id}",

            'start_time': timezone.now()

        }

    )

    

    context = {

        'appointment': appointment,

        'consultation': consultation,

        'room_name': consultation.room_name

    }

    return render(request, 'consultation/room.html', context)





@login_required

def save_consultation_notes(request, appointment_id):

    """Save consultation notes (doctors only)"""

    if request.user.role != 'doctor':

        return JsonResponse({'error': 'Unauthorized'}, status=403)

    

    appointment = get_object_or_404(Appointment, id=appointment_id)

    

    # Check if doctor owns this appointment

    if appointment.doctor.user != request.user:

        return JsonResponse({'error': 'Unauthorized'}, status=403)

    

    if request.method == 'POST':

        try:

            data = json.loads(request.body)

            notes = data.get('notes', '')

            

            # Get or create consultation

            consultation, created = Consultation.objects.get_or_create(

                appointment=appointment,

                defaults={'notes': notes}

            )

            

            if not created:

                consultation.notes = notes

                consultation.save()

            

            return JsonResponse({'success': True, 'message': 'Notes saved successfully'})

            

        except Exception as e:

            return JsonResponse({'error': str(e)}, status=400)

    

    return JsonResponse({'error': 'Method not allowed'}, status=405)





@login_required

def complete_consultation(request, appointment_id):

    """Complete consultation"""

    appointment = get_object_or_404(Appointment, id=appointment_id)

    

    # Check permissions

    if request.user.role == 'patient' and appointment.patient != request.user:

        return JsonResponse({'error': 'Unauthorized'}, status=403)

    elif request.user.role == 'doctor' and appointment.doctor.user != request.user:

        return JsonResponse({'error': 'Unauthorized'}, status=403)

    

    if request.method == 'POST':

        try:

            # Update appointment status

            appointment.status = 'completed'

            appointment.save()

            

            # Update consultation end time

            consultation = Consultation.objects.get(appointment=appointment)

            consultation.end_time = timezone.now()

            consultation.save()

            

            return JsonResponse({'success': True, 'message': 'Consultation completed'})

            

        except Exception as e:

            return JsonResponse({'error': str(e)}, status=400)

    

    return JsonResponse({'error': 'Method not allowed'}, status=405)





@login_required

def save_consultation_data(request):

    """Save consultation data including notes, prescription, and tasks"""

    if request.method != 'POST':

        return JsonResponse({'error': 'Method not allowed'}, status=405)

    

    if request.user.role != 'doctor':

        return JsonResponse({'error': 'Only doctors can save consultation data'}, status=403)

    

    try:

        data = json.loads(request.body)

        appointment_id = data.get('appointmentId')

        patient_id = data.get('patientId')

        

        # Get appointment and consultation

        appointment = get_object_or_404(Appointment, id=appointment_id)

        consultation = get_object_or_404(Consultation, appointment=appointment)

        

        # Save consultation notes

        notes_data = data.get('notes', {})

        consultation.notes = json.dumps(notes_data)

        consultation.save()

        

        # Get doctor profile safely

        doctor_profile = None

        try:

            doctor_profile = request.user.doctor_profile

        except Exception as e:

            logger.warning("Doctor profile missing while saving consultation data: %s", e)

            # Create doctor profile if it doesn't exist

            from .models import Doctor

            doctor_profile, created = Doctor.objects.get_or_create(

                user=request.user,

                defaults={

                    'qualification': 'MBBS',

                    'years_of_experience': 0,

                    'consultation_fee': 0,

                    'clinic_name': 'General Clinic',

                    'license_number': 'TEMP-' + str(request.user.id)

                }

            )

            if created:
                default_specialization = DoctorSpecialization.objects.filter(value='Therapist').first()
                default_focus = DoctorPrimaryFocus.objects.filter(value=DEFAULT_PRIMARY_FOCUS).first()
                if default_specialization:
                    doctor_profile.specializations.set([default_specialization])
                if default_focus:
                    doctor_profile.primary_focuses.set([default_focus])

        # Save prescription

        prescription_data = data.get('prescription', {})

        prescription_created = False

        if prescription_data.get('details') or prescription_data.get('medications'):

            try:

                prescription = Prescription.objects.create(

                    consultation=consultation,

                    doctor=doctor_profile,

                    patient=appointment.patient,

                    prescription_text=prescription_data.get('details', ''),

                    instructions=prescription_data.get('instructions', ''),

                    medications=prescription_data.get('medications', [])

                )

                prescription_created = True

            except Exception as e:

                logger.warning("Prescription creation failed for appointment %s: %s", appointment.id, e)

                # Continue without prescription

                pass

        

        # Save daily tasks with smart management logic

        tasks_data = data.get('tasks', [])

        tasks_created = 0

        from datetime import date, timedelta

        

        for task_data in tasks_data:

            try:

                # Check if patient already has this task (by title)

                existing_tasks = DailyTask.objects.filter(

                    patient=appointment.patient,

                    title__iexact=task_data.get('title', '').strip(),

                    is_active=True

                )

                

                # If task exists and is still valid, deactivate the old one

                if existing_tasks.exists():

                    for old_task in existing_tasks:

                        old_task.is_active = False

                        old_task.save()

                

                # Calculate dates based on duration

                duration_days = task_data.get('duration', 7)

                start_date = date.today()

                end_date = start_date + timedelta(days=duration_days)

                

                # Create new task

                new_task = DailyTask.objects.create(

                    consultation=consultation,

                    patient=appointment.patient,

                    doctor=doctor_profile,

                    title=task_data.get('title', ''),

                    description=task_data.get('description', ''),

                    category=task_data.get('category', 'general'),

                    start_date=start_date,

                    end_date=end_date,

                    frequency='daily',

                    is_completed=False,

                    is_active=True

                )

                tasks_created += 1

            except Exception as e:

                logger.warning("Task creation failed for appointment %s: %s", appointment.id, e)

                # Continue with next task

                continue

        

        return JsonResponse({

            'success': True, 

            'message': 'Consultation data saved successfully. Prescription and tasks are now available on patient dashboard.',

            'prescription_created': prescription_created,

            'tasks_created': tasks_created

        })

        

    except json.JSONDecodeError:

        return JsonResponse({'error': 'Invalid JSON data'}, status=400)

    except Exception as e:

        logger.exception("Consultation data save failed")

        return JsonResponse({'error': str(e)}, status=500)





# OTP functionality (commented for future implementation)

# def send_otp(request):

#     """Send OTP for verification"""

#     if request.method == 'POST':

#         phone = request.POST.get('phone')

#         

#         try:

#             user = User.objects.get(phone=phone)

#             user.generate_otp()

#             

#             # Send SMS logic here

#             # sms_service.send(phone, f"Your OTP is: {user.otp_code}")

#             

#             return JsonResponse({'success': True, 'message': 'OTP sent successfully'})

#         except User.DoesNotExist:

#             return JsonResponse({'success': False, 'message': 'Phone number not found'})

#     

#     return JsonResponse({'success': False, 'message': 'Invalid request'})





# def verify_otp(request):

#     """Verify OTP code"""

#     if request.method == 'POST':

#         phone = request.POST.get('phone')

#         otp_code = request.POST.get('otp_code')

#         

#         try:

#             user = User.objects.get(phone=phone, otp_code=otp_code)

#             

#             if user.otp_expires and user.otp_expires > timezone.now():

#                 user.is_verified = True

#                 user.otp_code = None

#                 user.otp_expires = None

#                 user.save()

#                 return JsonResponse({'success': True, 'message': 'OTP verified successfully'})

#             else:

#                 return JsonResponse({'success': False, 'message': 'OTP expired'})

#         except User.DoesNotExist:

#             return JsonResponse({'success': False, 'message': 'Invalid OTP'})

#     

#     return JsonResponse({'success': False, 'message': 'Invalid request'})





# Payment integration (commented for future implementation)

# def process_payment(request, appointment_id):

#     """Process payment for appointment"""

#     appointment = get_object_or_404(Appointment, id=appointment_id)

#     payment = appointment.payment

#     

#     if request.method == 'POST':

#         # SSLCommerz integration

#         sslcommerz = SSLCommerzPayment()

#         response = sslcommerz.create_payment(payment)

#         

#         if response['success']:

#             return redirect(response['gateway_url'])

#         else:

#             messages.error(request, 'Payment processing failed')

#             return redirect('patient_appointments')

#     

#     context = {'appointment': appointment, 'payment': payment}

#     return render(request, 'payment/process.html', context)





# def payment_success(request):

#     """Payment success callback"""

#     transaction_id = request.GET.get('transaction_id')

#     

#     # Verify payment with SSLCommerz

#     sslcommerz = SSLCommerzPayment()

#     result = sslcommerz.verify_payment(transaction_id)

#     

#     if result['success']:

#         # Update payment status

#         payment = Payment.objects.get(transaction_id=transaction_id)

#         payment.status = 'completed'

#         payment.transaction_id = transaction_id

#         payment.save()

#         

#         # Update appointment status

#         payment.appointment.status = 'confirmed'

#         payment.appointment.save()

#         

#         return redirect('payment_success')

#     

#     return redirect('payment_fail')





# def payment_fail(request):

#     """Payment failure callback"""

#     return render(request, 'payment/fail.html')





# Admin Management Views

@login_required

def admin_users(request):

    """Admin users management page"""

    if request.user.role != 'admin':

        return redirect('home')

    

    # Get all users with statistics

    users = User.objects.all().order_by('-date_joined')

    total_users = users.count()

    total_patients = users.filter(role='patient').count()

    total_doctors = users.filter(role='doctor').count()

    total_admins = users.filter(role='admin').count()

    

    context = {

        'users': users,

        'total_users': total_users,

        'total_patients': total_patients,

        'total_doctors': total_doctors,

        'total_admins': total_admins,

    }

    return render(request, 'admin/users_detail.html', context)





@login_required

def get_user_password(request, user_id):

    """Get actual user password for admin"""

    if request.user.role != 'admin':

        return JsonResponse({'success': False, 'error': 'Unauthorized'})

    

    try:

        user = User.objects.get(id=user_id)

        # Note: In a real application, passwords are hashed and cannot be retrieved

        # For demonstration purposes, we'll return a simulated password

        # In production, you would implement a password reset system instead

        

        # Simulate getting the actual password (this is just for demo)

        simulated_passwords = {

            'arif': 'arif123',

            'admin': 'admin123',

            'doctor': 'doctor123',

            'patient': 'patient123',

            'john': 'john123',

            'jane': 'jane123',

        }

        

        username = user.username.lower()

        actual_password = simulated_passwords.get(username, username + '123')

        

        return JsonResponse({

            'success': True,

            'password': actual_password,

            'user_id': user_id,

            'username': user.username

        })

        

    except User.DoesNotExist:

        return JsonResponse({'success': False, 'error': 'User not found'})





# Task and Prescription Management Views

@login_required

def complete_daily_task(request, task_id):

    """Mark a daily task as completed"""

    from datetime import date

    

    if request.user.role != 'patient':

        return JsonResponse({'success': False, 'error': 'Unauthorized'})

    

    if request.method == 'POST':

        try:

            daily_task = DailyTask.objects.get(id=task_id, patient=request.user)

            today = date.today()

            

            completion, created = TaskCompletion.objects.get_or_create(

                daily_task=daily_task,

                completion_date=today,

                defaults={'is_completed': False}

            )

            

            if not completion.is_completed:

                completion.is_completed = True

                completion.completed_at = timezone.now()

                completion.completion_time = timezone.now().time()

                completion.patient_notes = request.POST.get('notes', '')

                completion.save()

                

                # Create success notification

                Notification.objects.create(

                    user=request.user,

                    title="Task Completed!",

                    message=f"Great job! You completed: {daily_task.title}",

                    notification_type="system",

                    is_actionable=False

                )

                

                return JsonResponse({

                    'success': True,

                    'message': 'Task marked as completed!',

                    'completed_at': completion.completed_at.strftime('%I:%M %p')

                })

            else:

                return JsonResponse({

                    'success': False,

                    'error': 'Task already completed'

                })

                

        except DailyTask.DoesNotExist:

            return JsonResponse({'success': False, 'error': 'Task not found'})

        except Exception as e:

            logger.warning("Task completion failed: %s", e)

            return JsonResponse({'success': False, 'error': 'Server error occurred'})

    

    return JsonResponse({'success': False, 'error': 'Invalid request method'})





@login_required

def save_prescription_and_tasks(request, consultation_id):

    """Save prescription and assign tasks during consultation"""

    if request.user.role != 'doctor':

        return JsonResponse({'success': False, 'error': 'Unauthorized'})

    

    if request.method == 'POST':

        try:

            consultation = Consultation.objects.get(id=consultation_id)

            appointment = consultation.appointment

            doctor = Doctor.objects.get(user=request.user)

            

            # Parse JSON data

            data = json.loads(request.body)

            prescription_data = data.get('prescription', {})

            tasks_data = data.get('tasks', [])

            

            # Remove ALL old tasks for this patient when new tasks are assigned

            # First, delete ALL tasks for this patient (aggressive approach)

            all_old_tasks = DailyTask.objects.filter(

                patient=consultation.appointment.patient

            )

            

            old_task_count = all_old_tasks.count()
            all_old_tasks.delete()

            

            # Create prescription

            prescription = Prescription.objects.create(

                consultation=consultation,

                doctor=doctor,

                patient=consultation.appointment.patient,

                prescription_text=prescription_data.get('text', ''),

                medications=prescription_data.get('medications', []),

                instructions=prescription_data.get('instructions', '')

            )

            

            # Create new tasks

            tasks_created = 0

            for i, task_data in enumerate(tasks_data):

                try:

                    DailyTask.objects.create(

                        patient=consultation.appointment.patient,

                        doctor=doctor,

                        consultation=consultation,

                        prescription=prescription,

                        title=task_data['title'],

                        description=task_data['description'],

                        category=task_data['category'],

                        icon=task_data.get('icon', 'fas fa-tasks'),

                        source=task_data.get('source', 'custom'),

                        start_date=task_data['start_date'],

                        end_date=task_data['end_date'],

                        frequency=task_data.get('frequency', 'daily'),

                        recurring_days=task_data.get('recurring_days', []),

                        reminder_times=task_data.get('reminder_times', ['09:00', '14:00', '20:00']),

                        is_active=True

                    )

                    tasks_created += 1

                except Exception as e:

                    logger.warning(
                        "Task creation failed for consultation %s at index %s: %s",
                        consultation_id,
                        i,
                        e,
                    )

            

            # Notify patient

            Notification.objects.create(

                user=consultation.appointment.patient,

                title="New Prescription & Tasks",

                message=f"Dr. {doctor.user.get_full_name()} has assigned new tasks and prescription.",

                notification_type="prescription_update",

                is_actionable=True,

                action_url="/patient/dashboard/"

            )

            

            return JsonResponse({

                'success': True,

                'prescription_id': prescription.id,

                'tasks_created': tasks_created,

                'old_tasks_deleted': old_task_count,

                'message': f'Successfully deleted {old_task_count} old tasks and created {tasks_created} new tasks!'

            })

            

        except Exception as e:

            logger.exception("Prescription and task save failed for consultation %s", consultation_id)

            return JsonResponse({'success': False, 'error': str(e)})

    

    return JsonResponse({'success': False, 'error': 'Invalid request'})





@login_required

def get_health_task_templates(request):

    """Get predefined health task templates for doctors"""

    if request.user.role != 'doctor':

        return JsonResponse({'success': False, 'error': 'Unauthorized'})

    

    templates = HealthTaskTemplate.objects.filter(is_active=True)

    

    template_data = []

    for template in templates:

        template_data.append({

            'id': template.id,

            'title': template.title,

            'description': template.description,

            'category': template.category,

            'icon': template.icon,

            'default_duration': template.default_duration_days

        })

    

    return JsonResponse({'success': True, 'templates': template_data})





@login_required

def clear_all_patient_tasks(request):

    """Debug function to clear all tasks for current patient"""

    if request.user.role != 'patient':

        return JsonResponse({'success': False, 'error': 'Only patients can use this'})

    

    try:

        # Get all tasks for this patient

        all_tasks = DailyTask.objects.filter(patient=request.user)

        task_count = all_tasks.count()

        

        # Delete all tasks

        all_tasks.delete()

        

        return JsonResponse({

            'success': True,

            'message': f'Deleted {task_count} tasks successfully'

        })

        

    except Exception as e:

        return JsonResponse({'success': False, 'error': str(e)})





@login_required

def refresh_tasks(request):

    """Force refresh tasks for patient dashboard"""

    if request.user.role != 'patient':

        return JsonResponse({'success': False, 'error': 'Only patients can use this'})

    

    try:

        # Force database refresh

        from django.db import transaction

        transaction.commit()

        

        # Get fresh task data

        all_tasks = DailyTask.objects.filter(patient=request.user)

        active_tasks = DailyTask.objects.filter(patient=request.user, is_active=True)

        

        return JsonResponse({

            'success': True,

            'total_tasks': all_tasks.count(),

            'active_tasks': active_tasks.count(),

            'tasks': [

                {

                    'title': task.title,

                    'active': task.is_active,

                    'created': task.created_at.date().isoformat()

                }

                for task in active_tasks

            ]

        })

        

    except Exception as e:

        return JsonResponse({'success': False, 'error': str(e)})





@login_required

def mark_all_notifications_read(request):

    """Mark all notifications as read for the user"""

    if request.method == 'POST':

        try:

            # Mark all unread notifications as read

            updated_count = Notification.objects.filter(

                user=request.user,

                is_read=False

            ).update(is_read=True)

            

            return JsonResponse({

                'success': True,

                'message': f'Marked {updated_count} notifications as read',

                'count': updated_count

            })

        except Exception as e:

            return JsonResponse({

                'success': False,

                'error': 'Error marking notifications as read'

            })

    

    return JsonResponse({'success': False, 'error': 'Invalid request'})





@login_required

def check_notifications(request):

    """Check for new notifications"""

    if request.method == 'GET':

        try:

            unread_count = Notification.objects.filter(

                user=request.user,

                is_read=False

            ).count()

            

            # Get all notifications (both read and unread)

            notifications = Notification.objects.filter(

                user=request.user

            ).order_by('-created_at')[:20]  # Get last 20 notifications

            

            notification_data = []

            for notification in notifications:

                notification_data.append({

                    'id': notification.id,

                    'title': notification.title,

                    'message': notification.message,

                    'notification_type': notification.notification_type,

                    'is_read': notification.is_read,

                    'is_actionable': notification.is_actionable,

                    'action_url': notification.action_url,

                    'created_at': notification.created_at.isoformat()

                })

            

            return JsonResponse({

                'success': True,

                'unread_count': unread_count,

                'notifications': notification_data

            })

        except Exception as e:

            return JsonResponse({

                'success': False,

                'error': f'Error loading notifications: {str(e)}'

            })

    

    return JsonResponse({'success': False, 'error': 'Invalid request'})





@login_required

def mark_notification_read(request, notification_id):

    """Mark notification as read"""

    if request.method == 'POST':

        try:

            notification = Notification.objects.get(id=notification_id, user=request.user)

            notification.is_read = True

            notification.save()

            

            return JsonResponse({'success': True})

        except Notification.DoesNotExist:

            return JsonResponse({'success': False, 'error': 'Notification not found'})

    

    return JsonResponse({'success': False, 'error': 'Invalid request'})





@login_required

def get_prescription_details(request, prescription_id):

    """Get prescription details for modal display"""

    if request.method == 'GET':

        try:

            prescription = Prescription.objects.get(id=prescription_id, patient=request.user)

            

            # Prepare medications data

            medications = []

            if prescription.medications:

                for med in prescription.medications:

                    medications.append({

                        'name': med.get('name', ''),

                        'dosage': med.get('dosage', ''),

                        'frequency': med.get('frequency', '')

                    })

            

            prescription_data = {

                'id': prescription.id,

                'doctor_name': prescription.doctor.user.get_full_name() or prescription.doctor.user.username,

                'date': prescription.created_at.strftime('%B %d, %Y'),

                'status': 'Active',

                'medications': medications,

                'notes': prescription.prescription_text,

                'instructions': prescription.instructions

            }

            

            return JsonResponse({

                'success': True,

                'prescription': prescription_data

            })

        except Prescription.DoesNotExist:

            return JsonResponse({'success': False, 'error': 'Prescription not found'})

        except Exception as e:

            return JsonResponse({'success': False, 'error': str(e)})

    

    return JsonResponse({'success': False, 'error': 'Invalid request'})





@login_required

def download_prescription_pdf(request, prescription_id):

    """Generate and download prescription PDF"""

    from django.http import HttpResponse

    from django.template.loader import render_to_string

    

    if request.user.role != 'patient':

        return JsonResponse({'success': False, 'error': 'Unauthorized'})

    

    try:

        prescription = Prescription.objects.get(id=prescription_id, patient=request.user)

        

        # Generate HTML content for prescription

        html_content = render_to_string('patient/prescription_pdf.html', {

            'prescription': prescription,

            'patient': request.user,

            'doctor': prescription.doctor,

        })

        

        # Return HTML as downloadable file

        response = HttpResponse(html_content, content_type='text/html')

        response['Content-Disposition'] = f'attachment; filename="prescription_{prescription.id}.html"'

        

        return response

        

    except Prescription.DoesNotExist:

        return JsonResponse({'success': False, 'error': 'Prescription not found'})

    except Exception as e:

        return JsonResponse({'success': False, 'error': str(e)})





@login_required

def admin_appointments(request):

    """Admin appointments management page"""

    if request.user.role != 'admin':

        return redirect('home')

    

    # Get all appointments with statistics

    appointments = Appointment.objects.all().order_by('-created_at')

    total_appointments = appointments.count()

    scheduled_appointments = appointments.filter(status='scheduled').count()

    completed_appointments = appointments.filter(status='completed').count()

    cancelled_appointments = appointments.filter(status='cancelled').count()

    

    context = {

        'appointments': appointments,

        'total_appointments': total_appointments,

        'scheduled_appointments': scheduled_appointments,

        'completed_appointments': completed_appointments,

        'cancelled_appointments': cancelled_appointments,

    }

    return render(request, 'admin/appointments_detail.html', context)





@login_required

def admin_assessments(request):

    """Admin assessments management page"""

    if request.user.role != 'admin':

        return redirect('home')

    

    # Get all assessment questions and results

    questions = AssessmentQuestion.objects.all().order_by('-created_at')

    assessments = PatientAssessment.objects.all().order_by('-created_at')

    total_questions = questions.count()

    total_assessments = assessments.count()

    completed_assessments = assessments.filter(completed=True).count()

    

    context = {

        'questions': questions,

        'assessments': assessments,

        'total_questions': total_questions,

        'total_assessments': total_assessments,

        'completed_assessments': completed_assessments,

    }

    return render(request, 'admin/assessments_detail.html', context)

#     messages.error(request, 'Payment failed. Please try again.')

#     return redirect('patient_appointments')





# ==================== BLOG SYSTEM VIEWS ====================



@login_required

def doctor_write_blog(request):

    """Doctor blog writing page - create new blog post"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can write blogs.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor profile not found.')

        return redirect('home')

    

    if request.method == 'POST':

        title = request.POST.get('title', '').strip()

        excerpt = request.POST.get('excerpt', '').strip()

        content = request.POST.get('content', '').strip()

        category = request.POST.get('category', 'mental-health')

        featured_image = request.POST.get('featured_image', '').strip()

        status = request.POST.get('status', 'published')  # Get status from form

        

        if not title or not content:

            messages.error(request, 'Title and content are required.')

            return render(request, 'doctor/write_blog.html', {

                'title': title,

                'excerpt': excerpt,

                'content': content,

                'category': category,

                'featured_image': featured_image,

                'categories': BlogPost.CATEGORY_CHOICES,

            })

        

        # Create blog post

        blog_post = BlogPost.objects.create(

            title=title,

            excerpt=excerpt or title,

            content=content,

            author=doctor,

            category=category,

            featured_image=featured_image if featured_image else None,

            status=status

        )

        

        # Publish only if status is published

        if status == 'published':

            blog_post.publish()

            messages.success(request, f'Blog post "{title}" published successfully!')

        else:

            messages.success(request, f'Blog post "{title}" saved as draft!')

        

        return redirect('doctor_blog_management')

    

    return render(request, 'doctor/write_blog.html', {

        'categories': BlogPost.CATEGORY_CHOICES,

    })





@login_required

def doctor_blog_management(request):

    """Doctor blog management page - view, edit, delete own blogs"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can manage blogs.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor profile not found.')

        return redirect('home')

    

    # Get all blogs by this doctor

    blogs = BlogPost.objects.filter(author=doctor).order_by('-created_at')

    

    context = {

        'blogs': blogs,

        'total_blogs': blogs.count(),

        'published_count': blogs.filter(status='published').count(),

        'draft_count': blogs.filter(status='draft').count(),

    }

    return render(request, 'doctor/blog_management.html', context)





@login_required

def doctor_edit_blog(request, blog_id):

    """Edit existing blog post"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can edit blogs.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

        blog = BlogPost.objects.get(id=blog_id, author=doctor)

    except (Doctor.DoesNotExist, BlogPost.DoesNotExist):

        messages.error(request, 'Blog post not found or you do not have permission to edit it.')

        return redirect('doctor_blog_management')

    

    if request.method == 'POST':

        title = request.POST.get('title', '').strip()

        excerpt = request.POST.get('excerpt', '').strip()

        content = request.POST.get('content', '').strip()

        category = request.POST.get('category', 'mental-health')

        featured_image = request.POST.get('featured_image', '').strip()

        status = request.POST.get('status', 'draft')

        

        if not title or not content:

            messages.error(request, 'Title and content are required.')

            return render(request, 'doctor/edit_blog.html', {

                'blog': blog,

                'categories': BlogPost.CATEGORY_CHOICES,

            })

        

        # Update blog post

        blog.title = title

        blog.excerpt = excerpt or title

        blog.content = content

        blog.category = category

        blog.featured_image = featured_image if featured_image else None

        blog.status = status

        

        if status == 'published' and not blog.published_at:

            blog.publish()

        else:

            blog.save()

        

        messages.success(request, f'Blog post "{title}" updated successfully!')

        return redirect('doctor_blog_management')

    

    return render(request, 'doctor/edit_blog.html', {

        'blog': blog,

        'categories': BlogPost.CATEGORY_CHOICES,

    })





@login_required

def doctor_delete_blog(request, blog_id):

    """Delete blog post"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can delete blogs.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

        blog = BlogPost.objects.get(id=blog_id, author=doctor)

        blog_title = blog.title

        blog.delete()

        messages.success(request, f'Blog post "{blog_title}" deleted successfully!')

    except (Doctor.DoesNotExist, BlogPost.DoesNotExist):

        messages.error(request, 'Blog post not found or you do not have permission to delete it.')

    

    return redirect('doctor_blog_management')





def blog_detail(request, slug):

    """Blog detail page - view full article"""

    blog = get_object_or_404(BlogPost, slug=slug, status='published')

    

    # Increment view count

    blog.increment_views()

    

    # Get related blogs by same author or same category

    related_blogs = BlogPost.objects.filter(

        status='published'

    ).filter(

        Q(author=blog.author) | Q(category=blog.category)

    ).exclude(id=blog.id)[:3]

    

    context = {

        'blog': blog,

        'related_blogs': related_blogs,

        'author_name': blog.author.user.get_full_name() or blog.author.user.username,

        'author_specialty': blog.author.specialty,

    }

    return render(request, 'home/blog_detail.html', context)





def update_blogs_view(request):

    """Updated blogs view - fetch real published blogs from database"""

    # Get user's last assessment result (only for logged-in patients)

    last_assessment = None

    recommended_categories = []

    stress_level = None

    

    # If user is authenticated and is a patient, get personalized recommendations

    if request.user.is_authenticated and request.user.role == 'patient':

        try:

            last_assessment = PatientAssessment.objects.filter(

                patient=request.user

            ).order_by('-created_at').first()

            

            if last_assessment:

                stress_level = last_assessment.stress_level

                # Map stress levels to recommended blog categories

                stress_level_mapping = {

                    'low': ['mindfulness', 'self-care', 'sleep'],

                    'moderate': ['anxiety', 'workplace', 'self-care'],

                    'high': ['depression', 'therapy', 'relationships'],

                    'severe': ['therapy', 'depression', 'anxiety']

                }

                

                recommended_categories = stress_level_mapping.get(

                    last_assessment.stress_level, 

                    ['mindfulness', 'self-care']

                )

        except:

            pass

    

    # Get published blogs from database

    published_blogs = BlogPost.objects.filter(status='published').order_by('-published_at')

    

    # Get featured blog

    featured_blog = published_blogs.filter(is_featured=True).first()

    if not featured_blog:

        featured_blog = published_blogs.first()

    

    # Get recommended blogs based on assessment

    recommended_blogs = []

    if recommended_categories:

        recommended_blogs = published_blogs.filter(

            category__in=recommended_categories

        ).exclude(id=featured_blog.id if featured_blog else None)[:3]

    

    # Get all other blogs

    all_blogs = published_blogs.exclude(

        id__in=[b.id for b in recommended_blogs] + ([featured_blog.id] if featured_blog else [])

    )

    

    # Get blogs by category

    categories = BlogPost.CATEGORY_CHOICES

    category_blogs = {}

    for cat_key, cat_name in categories:

        cat_blogs = published_blogs.filter(category=cat_key)[:4]

        if cat_blogs.exists():

            category_blogs[cat_key] = {

                'name': cat_name,

                'blogs': cat_blogs,

                'count': published_blogs.filter(category=cat_key).count()

            }

    

    context = {

        'last_assessment': last_assessment,

        'recommended_categories': recommended_categories,

        'recommended_blogs': recommended_blogs,

        'stress_level': stress_level,

        'featured_blog': featured_blog,

        'all_blogs': all_blogs,

        'category_blogs': category_blogs,

    }

    return render(request, 'patient/blogs.html', context)





# ==================== DOCTOR SCHEDULE MANAGEMENT VIEWS ====================



@login_required

def doctor_schedule(request):

    """Doctor schedule management page - manage availability"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can manage schedules.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor profile not found.')

        return redirect('home')

    

    # Get existing schedules grouped by day

    schedules = DoctorSchedule.objects.filter(doctor=doctor, is_available=True)

    

    # Group by day

    day_schedules = {}

    for day_code, day_name in DoctorSchedule.DAY_CHOICES:

        day_schedules[day_code] = {

            'name': day_name,

            'slots': schedules.filter(day_of_week=day_code).order_by('start_time')

        }

    

    context = {

        'day_schedules': day_schedules,

        'has_schedule': schedules.exists(),

    }

    return render(request, 'doctor/schedule.html', context)





@login_required

def doctor_add_schedule(request):

    """Add new schedule slot for doctor"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can manage schedules.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

    except Doctor.DoesNotExist:

        messages.error(request, 'Doctor profile not found.')

        return redirect('home')

    

    if request.method == 'POST':

        day_of_week = request.POST.get('day_of_week')

        start_time = request.POST.get('start_time')

        end_time = request.POST.get('end_time')

        slot_duration = request.POST.get('slot_duration', 30)

        

        if not day_of_week or not start_time or not end_time:

            messages.error(request, 'Please fill in all fields.')

            return redirect('doctor_schedule')

        

        try:

            # Convert string times to time objects

            from datetime import datetime

            start_time_obj = datetime.strptime(start_time, '%H:%M').time()

            end_time_obj = datetime.strptime(end_time, '%H:%M').time()

            

            if start_time_obj >= end_time_obj:

                messages.error(request, 'Start time must be before end time.')

                return redirect('doctor_schedule')

            

            # Check for overlapping schedules

            existing_schedules = DoctorSchedule.objects.filter(

                doctor=doctor,

                day_of_week=int(day_of_week),

                is_available=True

            )

            

            # Check if new schedule overlaps with existing

            for schedule in existing_schedules:

                if (start_time_obj < schedule.end_time and 

                    end_time_obj > schedule.start_time):

                    messages.error(

                        request, 

                        f'This time slot overlaps with an existing schedule: '

                        f'{schedule.start_time.strftime("%H:%M")} - {schedule.end_time.strftime("%H:%M")}'

                    )

                    return redirect('doctor_schedule')

            

            # Create schedule

            schedule = DoctorSchedule.objects.create(

                doctor=doctor,

                day_of_week=int(day_of_week),

                start_time=start_time_obj,

                end_time=end_time_obj,

                slot_duration=int(slot_duration),

                is_available=True

            )

            

            day_name = dict(DoctorSchedule.DAY_CHOICES)[int(day_of_week)]

            messages.success(

                request, 

                f'Schedule added: {day_name} ({start_time} - {end_time})'

            )

        except Exception as e:

            messages.error(request, f'Error adding schedule: {str(e)}')

        

        return redirect('doctor_schedule')

    

    return redirect('doctor_schedule')





@login_required

def doctor_delete_schedule(request, schedule_id):

    """Delete schedule slot"""

    if request.user.role != 'doctor':

        messages.error(request, 'Only doctors can manage schedules.')

        return redirect('home')

    

    try:

        doctor = Doctor.objects.get(user=request.user)

        schedule = DoctorSchedule.objects.get(id=schedule_id, doctor=doctor)

        

        day_name = dict(DoctorSchedule.DAY_CHOICES)[schedule.day_of_week]

        time_str = f"{schedule.start_time.strftime('%H:%M')} - {schedule.end_time.strftime('%H:%M')}"

        

        schedule.delete()

        messages.success(request, f'Schedule removed: {day_name} ({time_str})')

    except (Doctor.DoesNotExist, DoctorSchedule.DoesNotExist):

        messages.error(request, 'Schedule not found or you do not have permission to delete it.')

    

    return redirect('doctor_schedule')





@login_required

def get_available_slots_api(request, doctor_id):

    """API endpoint to get available time slots for a doctor on a specific date"""

    from datetime import datetime, timedelta

    

    try:

        doctor = Doctor.objects.get(id=doctor_id)

        date_str = request.GET.get('date')

        

        if not date_str:

            return JsonResponse({'error': 'Date parameter is required'}, status=400)

        

        selected_date = datetime.strptime(date_str, '%Y-%m-%d').date()

        day_of_week = selected_date.weekday()

        

        # Get doctor's schedules for this day

        schedules = DoctorSchedule.objects.filter(

            doctor=doctor,

            day_of_week=day_of_week,

            is_available=True

        )

        

        if not schedules.exists():

            return JsonResponse({

                'available': False,

                'message': 'Doctor is not available on this day',

                'slots': []

            })

        

        # Get already booked slots for this date

        booked_slots = BookedSlot.objects.filter(

            doctor=doctor,

            appointment_date=selected_date,

            is_active=True

        ).values_list('appointment_time', flat=True)

        

        # Generate available slots

        all_slots = []

        for schedule in schedules:

            slots = schedule.get_time_slots()

            for slot_time_str in slots:

                slot_time = datetime.strptime(slot_time_str, '%H:%M').time()

                is_booked = slot_time in booked_slots

                

                # For today, hide past times

                is_past = False

                if selected_date == datetime.now().date():

                    current_time = datetime.now().time()

                    if slot_time <= current_time:

                        is_past = True

                

                # Convert to 12-hour format for display

                hour = slot_time.hour

                minute = slot_time.minute

                if hour < 12:

                    period = "AM"

                    display_hour = hour if hour != 0 else 12

                else:

                    period = "PM"

                    display_hour = hour - 12 if hour != 12 else 12

                

                time_str = f"{display_hour}:{minute:02d} {period}"

                

                all_slots.append({

                    'time': time_str,

                    'time_24h': slot_time_str,

                    'available': not is_booked and not is_past

                })

        

        return JsonResponse({

            'available': True,

            'date': date_str,

            'slots': all_slots

        })

        

    except Doctor.DoesNotExist:

        return JsonResponse({'error': 'Doctor not found'}, status=404)

    except Exception as e:

        return JsonResponse({'error': str(e)}, status=500)

