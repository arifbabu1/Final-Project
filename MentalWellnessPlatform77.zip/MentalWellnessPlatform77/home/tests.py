from types import SimpleNamespace

from django.test import SimpleTestCase, TestCase
from django.urls import reverse

from .models import AssessmentQuestion, PatientAssessment, User
from .recommendation_engine import build_assessment_profile, recommend_doctors


class RecommendationEngineTests(SimpleTestCase):
    def test_core_scores_and_dynamic_triggers(self):
        user = SimpleNamespace(age=16, gender='female')
        core_answers = [4, 4, 3, 3, 1, 1, 4]

        profile = build_assessment_profile(core_answers, user)

        self.assertEqual(profile['primary_condition'], 'Depression')
        self.assertEqual(profile['severity_level'], 'High')
        self.assertEqual(profile['emotional_risk_level'], 'High')
        self.assertEqual(profile['category_scores']['Depression']['normalized'], 1.0)
        self.assertEqual(profile['category_scores']['Self-esteem']['normalized'], 1.0)
        self.assertIn('addiction', [module['key'] for module in profile['triggered_modules']])
        self.assertIn('child', [module['key'] for module in profile['triggered_modules']])

    def test_doctor_recommendations_use_weighted_100_point_rules(self):
        user = SimpleNamespace(age=65, gender='male')
        core_answers = [2, 2, 4, 4, 4, 1, 1]
        dynamic_responses = {
            'neurological': [4, 4, 4],
            'geriatric': [4, 3, 3],
        }
        profile = build_assessment_profile(core_answers, user, dynamic_responses)
        neuro_doctor = SimpleNamespace(
            specialty='Neuropsychiatrist',
            primary_focus='Neurological Disorders',
            years_of_experience=12,
            availability_score=5,
        )
        counselor = SimpleNamespace(
            specialty='Counselor',
            primary_focus='Talk Therapy',
            years_of_experience=1,
            availability_score=2,
        )

        recommendations = recommend_doctors([counselor, neuro_doctor], profile)

        self.assertEqual(recommendations[0]['doctor'], neuro_doctor)
        self.assertEqual(recommendations[0]['match_percentage'], 100)
        self.assertEqual(recommendations[0]['score_breakdown']['experience'], 20)
        self.assertEqual(recommendations[0]['score_breakdown']['availability'], 10)

    def test_doctor_recommendations_match_any_multi_value_field(self):
        user = SimpleNamespace(age=35, gender='female')
        profile = build_assessment_profile([4, 4, 1, 1, 1, 1, 3], user)
        multi_match_doctor = SimpleNamespace(
            specialization_values=['Counselor', 'Clinical Psychologist'],
            primary_focus_values=['Anxiety', 'Depression'],
            specialty='Clinical Psychologist',
            primary_focus='Anxiety, Depression',
            years_of_experience=6,
            availability_score=5,
        )
        no_match_doctor = SimpleNamespace(
            specialization_values=['Neuropsychologist'],
            primary_focus_values=['Schizophrenia'],
            specialty='Neuropsychologist',
            primary_focus='Schizophrenia',
            years_of_experience=20,
            availability_score=5,
        )

        recommendations = recommend_doctors([no_match_doctor, multi_match_doctor], profile)

        self.assertEqual(recommendations[0]['doctor'], multi_match_doctor)
        self.assertEqual(len(recommendations), 1)
        self.assertGreater(recommendations[0]['score_breakdown']['multi_match_bonus'], 0)


class AssessmentViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='patient',
            password='pass1234',
            role='patient',
            age=17,
            gender='female',
        )
        questions = [
            ('Over the past two weeks, how often have you felt down, depressed, or hopeless?', 'Depression', 3),
            ('Over the past two weeks, how often have you had little interest or pleasure in doing things?', 'Depression', 3),
            ('Over the past two weeks, how often have you felt nervous, anxious, or on edge?', 'Anxiety', 2),
            ('Over the past two weeks, how often have you been unable to stop or control worrying?', 'Anxiety', 2),
            ('Over the past two weeks, how often have you had trouble falling or staying asleep, or sleeping too much?', 'Sleep', 2),
            ('Over the past two weeks, how often have you felt tired or had little energy?', 'Energy', 1),
            ('Over the past two weeks, how often have you felt that you are a failure or have let yourself or your family down?', 'Self-esteem', 3),
        ]
        for index, (text, category, weight) in enumerate(questions, start=1):
            AssessmentQuestion.objects.create(
                question_text=text,
                category=category,
                weight_value=weight,
                track_number=index,
            )
        self.client.login(username='patient', password='pass1234')

    def test_assessment_page_renders_dynamic_modules(self):
        response = self.client.get(reverse('assessment'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'data-module="addiction"')
        self.assertContains(response, 'data-module="child"')

    def test_assessment_post_stores_rule_profile(self):
        data = {}
        for question in AssessmentQuestion.objects.order_by('track_number'):
            data[f'question_{question.id}'] = '4'
        for module in ('addiction', 'family', 'neurological', 'child'):
            for index in range(3):
                data[f'dynamic_{module}_{index}'] = '4'

        response = self.client.post(reverse('assessment'), data, follow=True)
        assessment = PatientAssessment.objects.get(patient=self.user)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(assessment.result_summary['primary_condition'], 'Depression')
        self.assertEqual(assessment.result_summary['severity_level'], 'High')
        self.assertEqual(assessment.result_summary['emotional_risk_level'], 'High')
        self.assertIn('addiction', assessment.dynamic_responses)
        self.assertContains(response, 'Recommendation Engine Summary')
