from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from home.models import User, Appointment, PatientAssessment

@staff_member_required
def admin_dashboard(request):
    """
    Custom admin dashboard with statistics and enhanced UI
    """
    # Get statistics
    total_users = User.objects.count()
    total_appointments = Appointment.objects.count()
    total_assessments = PatientAssessment.objects.count()
    
    context = {
        'total_users': total_users,
        'total_appointments': total_appointments,
        'total_assessments': total_assessments,
        'title': 'Admin Dashboard',
    }
    
    return render(request, 'admin/admin_dashboard.html', context)

@staff_member_required
def users_detail(request):
    """
    Users management detail page
    """
    users = User.objects.all().order_by('-date_joined')
    total_users = users.count()
    total_patients = users.filter(role='patient').count()
    total_doctors = users.filter(role='doctor').count()
    total_admins = users.filter(role='admin').count()
    
    context = {
        'users': users,
        'total_users': total_users,
        'total_patients': total_patients,
        'total_doctors': total_doctors,
        'total_admins': total_admins,
        'title': 'Users Management',
    }
    
    return render(request, 'admin/users_detail.html', context)

@staff_member_required
def appointments_detail(request):
    """
    Appointments management detail page
    """
    appointments = Appointment.objects.all().order_by('-appointment_date')
    
    context = {
        'appointments': appointments,
        'total_appointments': appointments.count(),
        'title': 'Appointments Management',
    }
    
    return render(request, 'admin/appointments_detail.html', context)

@staff_member_required
def assessments_detail(request):
    """
    Assessments management detail page
    """
    assessments = PatientAssessment.objects.all().order_by('-created_at')
    
    context = {
        'assessments': assessments,
        'total_assessments': assessments.count(),
        'title': 'Assessments Management',
    }
    
    return render(request, 'admin/assessments_detail.html', context)

@staff_member_required
def admin_redirect(request):
    """
    Redirect to admin dashboard
    """
    return render(request, 'admin/admin_dashboard.html')
