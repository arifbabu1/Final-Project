# wellness_platform/urls.py
from django.contrib import admin
from django.urls import path, include
from home.admin_views import admin_dashboard, admin_redirect, users_detail, appointments_detail, assessments_detail

urlpatterns = [
    path('admin/dashboard/', admin_dashboard, name='admin_dashboard'),
    path('admin/users/', users_detail, name='users_detail'),
    path('admin/appointments/', appointments_detail, name='appointments_detail'),
    path('admin/assessments/', assessments_detail, name='assessments_detail'),
    path('admin/', admin.site.urls),
    path('', include('home.urls')),
]
