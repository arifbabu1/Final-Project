from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from django.contrib.auth import password_validation
import re
from .models import (
    User, Doctor, AssessmentQuestion, PatientAssessment, 
    AssessmentAnswer, Appointment, Consultation, Payment
)


class DoctorInline(admin.StackedInline):
    """Inline admin for Doctor model"""
    model = Doctor
    can_delete = False
    verbose_name_plural = 'Doctor Profile'
    fields = (
        'specialty', 'primary_focus', 'qualification', 'years_of_experience',
        'consultation_fee', 'clinic_name', 'clinic_address',
        'license_number', 'bio', 'is_available'
    )
    
    def get_fields(self, request, obj=None):
        if obj and hasattr(obj, 'doctor_profile'):
            return self.fields
        return ()


class DoctorUserCreationForm(UserCreationForm):
    """Custom form for creating a doctor user with basic info"""
    
    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('email', 'phone', 'first_name', 'last_name')
        widgets = {
            'username': forms.TextInput(attrs={'placeholder': 'Choose a unique username'}),
            'first_name': forms.TextInput(attrs={'placeholder': 'First name'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Last name'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Email address'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Phone number'}),
        }
    
    # Add doctor profile fields as form fields
    specialty = forms.ChoiceField(
        choices=Doctor.SPECIALTY_CHOICES,
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    qualification = forms.CharField(
        required=True,
        widget=forms.Textarea(attrs={'rows': 3, 'placeholder': 'e.g., MBBS, MD (Psychiatry), FCPS'})
    )
    years_of_experience = forms.IntegerField(
        min_value=0,
        max_value=50,
        required=True,
        widget=forms.NumberInput(attrs={'placeholder': 'Years of experience'})
    )
    consultation_fee = forms.DecimalField(
        max_digits=10, 
        decimal_places=2,
        required=False,
        widget=forms.NumberInput(attrs={'placeholder': 'Consultation fee in Taka'})
    )
    clinic_name = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Clinic or hospital name (optional)'})
    )
    clinic_address = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'rows': 3, 'placeholder': 'Clinic address (optional)'})
    )
    license_number = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Medical license number (optional)'})
    )
    professional_summary = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'rows': 4, 'placeholder': 'Brief professional summary and focus areas (optional)'})
    )
    focus_areas = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'rows': 2, 'placeholder': 'e.g., Depression, Anxiety, Bipolar Disorder (optional)'})
    )
    primary_focus = forms.ChoiceField(
        choices=Doctor.FOCUS_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    languages = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'e.g., Bengali, English, Hindi'})
    )
    is_available = forms.BooleanField(
        initial=True,
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Add placeholders for password fields
        self.fields['password1'].widget = forms.PasswordInput(attrs={'placeholder': 'Enter password'})
        self.fields['password2'].widget = forms.PasswordInput(attrs={'placeholder': 'Confirm password'})
        
        # Set role to doctor and hide it
        self.fields['role'].initial = 'doctor'
        self.fields['role'].widget = forms.HiddenInput()
        
        # Reorder fields to ensure proper order
        field_order = [
            'username', 'first_name', 'last_name', 'email', 'phone',
            'password1', 'password2', 'role',
            'specialty', 'primary_focus', 'qualification', 'years_of_experience',
            'consultation_fee', 'clinic_name', 'clinic_address',
            'license_number', 'professional_summary', 'focus_areas',
            'languages', 'is_available'
        ]
        self.fields = {field: self.fields[field] for field in field_order if field in self.fields}
    
    def clean_password1(self):
        password = self.cleaned_data.get('password1')
        if password:
            # Check for at least 1 numeric number
            if not re.search(r'\d', password):
                raise ValidationError("Password must contain at least 1 numeric number.")
            
            # Check for at least 1 special character (@, +, -, #, $, %)
            if not re.search(r'[@+\-#$%]', password):
                raise ValidationError("Password must contain at least 1 special character (@, +, -, #, $, %).")
        return password
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = 'doctor'
        user.is_verified = True  # Auto-verify doctors added by admin
        
        # Extract doctor data before saving
        doctor_data = {
            'specialty': self.cleaned_data.get('specialty'),
            'primary_focus': self.cleaned_data.get('primary_focus', 'Stress'),
            'qualification': self.cleaned_data.get('qualification'),
            'years_of_experience': self.cleaned_data.get('years_of_experience'),
            'consultation_fee': self.cleaned_data.get('consultation_fee'),
            'clinic_name': self.cleaned_data.get('clinic_name'),
            'clinic_address': self.cleaned_data.get('clinic_address'),
            'license_number': self.cleaned_data.get('license_number'),
            'professional_summary': self.cleaned_data.get('professional_summary'),
            'is_available': self.cleaned_data.get('is_available', True),
            'availability_schedule': {
                'focus_areas': self.cleaned_data.get('focus_areas', ''),
                'languages': self.cleaned_data.get('languages', '')
            }
        }
        
        if commit:
            user.save()
            # Create doctor profile
            Doctor.objects.create(user=user, **doctor_data)
        return user


class DoctorUserAdmin(BaseUserAdmin):
    """Custom admin for creating doctor users"""
    
    add_form = DoctorUserCreationForm
    inlines = [DoctorInline]
    
    add_fieldsets = (
        ('Create Doctor Account', {
            'classes': ('wide',),
            'fields': (
                'username', 'first_name', 'last_name', 'email', 'phone',
                'password1', 'password2', 'role',
                'specialty', 'primary_focus', 'qualification', 'years_of_experience',
                'consultation_fee', 'clinic_name', 'clinic_address',
                'license_number', 'professional_summary', 'focus_areas',
                'languages', 'is_available'
            ),
        }),
    )
    
    def get_form(self, request, obj=None, **kwargs):
        if not obj:
            kwargs['form'] = DoctorUserCreationForm
        return super().get_form(request, obj, **kwargs)


# Register User admin with doctor creation capabilities
@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'phone', 'role', 'is_verified', 'date_joined')
    list_filter = ('role', 'is_verified', 'date_joined')
    search_fields = ('username', 'email', 'phone')
    ordering = ('-date_joined',)
    
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email', 'phone')}),
        ('Permissions', {'fields': ('role', 'is_verified', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
    
    add_fieldsets = (
        ('Create New User', {
            'classes': ('wide',),
            'fields': ('username', 'first_name', 'last_name', 'email', 'phone', 'password1', 'password2', 'role'),
        }),
    )
    
    def get_form(self, request, obj=None, **kwargs):
        # Use the doctor creation form when role is doctor
        if not obj and request.GET.get('role') == 'doctor':
            kwargs['form'] = DoctorUserCreationForm
        return super().get_form(request, obj, **kwargs)
    
    def get_fieldsets(self, request, obj=None):
        if not obj and request.GET.get('role') == 'doctor':
            return (
                ('Create Doctor Account', {
                    'fields': (
                        'username', 'first_name', 'last_name', 'email', 'phone',
                        'password1', 'password2', 'role',
                        'specialty', 'primary_focus', 'qualification', 'years_of_experience',
                        'consultation_fee', 'clinic_name', 'clinic_address',
                        'license_number', 'professional_summary', 'focus_areas',
                        'languages', 'is_available'
                    ),
                }),
            )
        # For regular user creation, show role selection
        if not obj:
            return (
                ('Create New User', {
                    'classes': ('wide',),
                    'fields': ('username', 'first_name', 'last_name', 'email', 'phone', 'password1', 'password2', 'role'),
                }),
            )
        return super().get_fieldsets(request, obj)


@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('user', 'specialty', 'primary_focus', 'years_of_experience', 'consultation_fee', 'clinic_name', 'is_available', 'created_at')
    list_filter = ('specialty', 'primary_focus', 'is_available', 'created_at')
    search_fields = ('user__username', 'user__email', 'user__first_name', 'user__last_name', 'specialty', 'clinic_name')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('user', 'name', 'specialty', 'primary_focus', 'qualification', 'years_of_experience', 'license_number')
        }),
        ('Professional Details', {
            'fields': ('consultation_fee', 'clinic_name', 'clinic_address', 'bio', 'is_available', 'available_online', 'emergency_support')
        }),
        ('Additional Information', {
            'fields': ('availability_schedule', 'profile_image'),
            'classes': ('collapse',)
        }),
    )
    
    readonly_fields = ('created_at',)
    
    def get_readonly_fields(self, request, obj=None):
        if obj:  # Editing existing object
            return self.readonly_fields + ('user',)
        return self.readonly_fields


@admin.register(AssessmentQuestion)
class AssessmentQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text', 'category', 'weight_value', 'created_at')
    list_filter = ('category', 'created_at')
    search_fields = ('question_text', 'category')
    ordering = ('category', 'weight_value')
    
    fieldsets = (
        ('Question Details', {
            'fields': ('question_text', 'category', 'weight_value')
        }),
    )


class AssessmentAnswerInline(admin.TabularInline):
    model = AssessmentAnswer
    extra = 0
    readonly_fields = ('created_at',)


@admin.register(PatientAssessment)
class PatientAssessmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'total_score', 'stress_level', 'created_at')
    list_filter = ('stress_level', 'created_at')
    search_fields = ('patient__username', 'patient__email')
    ordering = ('-created_at',)
    inlines = [AssessmentAnswerInline]
    
    fieldsets = (
        ('Assessment Details', {
            'fields': ('patient', 'total_score', 'stress_level', 'recommendations')
        }),
    )
    
    readonly_fields = ('created_at',)


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor', 'appointment_date', 'status', 'consultation_fee', 'created_at')
    list_filter = ('status', 'appointment_date', 'created_at')
    search_fields = ('patient__username', 'doctor__user__username')
    ordering = ('-appointment_date',)
    
    fieldsets = (
        ('Appointment Details', {
            'fields': ('patient', 'doctor', 'appointment_date', 'status', 'notes')
        }),
        ('Financial Details', {
            'fields': ('consultation_fee',)
        }),
    )
    
    readonly_fields = ('created_at', 'updated_at')


@admin.register(Consultation)
class ConsultationAdmin(admin.ModelAdmin):
    list_display = ('appointment', 'room_name', 'start_time', 'end_time', 'created_at')
    list_filter = ('start_time', 'created_at')
    search_fields = ('appointment__patient__username', 'appointment__doctor__user__username', 'room_name')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Consultation Details', {
            'fields': ('appointment', 'room_name', 'start_time', 'end_time')
        }),
        ('Additional Information', {
            'fields': ('recording_url', 'notes')
        }),
    )
    
    readonly_fields = ('created_at',)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('appointment', 'amount', 'admin_commission', 'doctor_earning', 'status', 'created_at')
    list_filter = ('status', 'payment_method', 'created_at')
    search_fields = ('appointment__patient__username', 'transaction_id')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Payment Details', {
            'fields': ('appointment', 'amount', 'status', 'transaction_id', 'payment_method')
        }),
        ('Financial Breakdown', {
            'fields': ('admin_commission', 'doctor_earning')
        }),
    )
    
    readonly_fields = ('created_at', 'updated_at')
    
    actions = ['calculate_commissions']
    
    def calculate_commissions(self, request, queryset):
        for payment in queryset:
            payment.calculate_commission()
        self.message_user(request, f"Commissions calculated for {queryset.count()} payments.")
    calculate_commissions.short_description = "Calculate commissions for selected payments"
