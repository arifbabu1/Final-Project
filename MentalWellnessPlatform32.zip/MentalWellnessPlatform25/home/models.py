from django.db import models
from django.contrib.auth.models import AbstractUser
import json


class User(AbstractUser):
    ROLE_CHOICES = [
        ('patient', 'Patient'),
        ('doctor', 'Doctor'),
        ('admin', 'Admin'),
    ]
    
    phone = models.CharField(max_length=20, unique=True)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='patient')
    is_verified = models.BooleanField(default=False)
    otp_code = models.CharField(max_length=6, null=True, blank=True)
    otp_expires = models.DateTimeField(null=True, blank=True)
    
    # OTP functionality (commented for future implementation)
    # def generate_otp(self):
    #     import random
    #     from datetime import datetime, timedelta
    #     self.otp_code = f"{random.randint(100000, 999999)}"
    #     self.otp_expires = datetime.now() + timedelta(minutes=10)
    #     self.save()
    
    def __str__(self):
        return f"{self.username} ({self.role})"


class Doctor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='doctor_profile')
    specialty = models.CharField(max_length=255)
    qualification = models.TextField()
    experience_years = models.PositiveIntegerField()
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    clinic_name = models.CharField(max_length=255, blank=True, null=True)
    clinic_address = models.TextField(blank=True, null=True)
    license_number = models.CharField(max_length=100, blank=True, null=True)
    professional_summary = models.TextField(blank=True, null=True)
    is_available = models.BooleanField(default=True)
    availability_schedule = models.JSONField(default=dict, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Dr. {self.user.get_full_name()} - {self.specialty}"


class AssessmentQuestion(models.Model):
    question_text = models.TextField()
    weight_value = models.IntegerField(default=1)
    category = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.category}: {self.question_text[:50]}..."


class PatientAssessment(models.Model):
    STRESS_LEVEL_CHOICES = [
        ('low', 'Low'),
        ('moderate', 'Moderate'),
        ('high', 'High'),
        ('severe', 'Severe'),
    ]
    
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assessments')
    total_score = models.IntegerField()
    stress_level = models.CharField(max_length=10, choices=STRESS_LEVEL_CHOICES)
    recommendations = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.patient.username} - {self.stress_level} stress"


class AssessmentAnswer(models.Model):
    assessment = models.ForeignKey(PatientAssessment, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(AssessmentQuestion, on_delete=models.CASCADE)
    answer_value = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['assessment', 'question']


class Appointment(models.Model):
    STATUS_CHOICES = [
        ('pending_payment', 'Pending Payment'),
        ('scheduled', 'Scheduled'),
        ('confirmed', 'Confirmed'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    CONSULTATION_TYPE_CHOICES = [
        ('video', 'Video Consultation'),
        ('phone', 'Phone Consultation'),
        ('in_person', 'In Person'),
    ]
    
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='patient_appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='doctor_appointments')
    appointment_date = models.DateTimeField()
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='scheduled')
    consultation_type = models.CharField(max_length=15, choices=CONSULTATION_TYPE_CHOICES, default='video')
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2)
    notes = models.TextField(null=True, blank=True)
    meeting_id = models.CharField(max_length=20, null=True, blank=True)
    meeting_link = models.URLField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.patient.username} - Dr. {self.doctor.user.get_full_name()} - {self.appointment_date}"


class Consultation(models.Model):
    appointment = models.OneToOneField(Appointment, on_delete=models.CASCADE, related_name='consultation')
    room_name = models.CharField(max_length=255, unique=True)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    recording_url = models.URLField(null=True, blank=True)
    notes = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Consultation for {self.appointment}"


class Payment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]
    
    appointment = models.OneToOneField(Appointment, on_delete=models.CASCADE, related_name='payment')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    admin_commission = models.DecimalField(max_digits=10, decimal_places=2)
    doctor_earning = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='pending')
    transaction_id = models.CharField(max_length=255, null=True, blank=True)
    payment_method = models.CharField(max_length=50, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def calculate_commission(self, commission_rate=0.20):
        from decimal import Decimal
        commission_rate = Decimal(str(commission_rate))
        self.admin_commission = self.amount * commission_rate
        self.doctor_earning = self.amount - self.admin_commission
        self.save()
    
    def __str__(self):
        return f"Payment for {self.appointment} - {self.status}"


# Payment integration (commented for future implementation)
# class SSLCommerzPayment:
#     def __init__(self):
#         self.store_id = "your_store_id"
#         self.store_password = "your_store_password"
#         self.base_url = "https://sandbox.sslcommerz.com"
#     
#     def create_payment(self, payment):
#         # SSLCommerz integration code here
#         pass
#     
#     def verify_payment(self, transaction_id):
#         # Payment verification code here
#         pass


# Health Task and Prescription System
class HealthTaskTemplate(models.Model):
    """Predefined health tasks for doctors to use"""
    CATEGORY_CHOICES = [
        ('physical', 'Physical Activity'),
        ('diet', 'Nutrition & Diet'),
        ('medical', 'Medical Monitoring'),
        ('mental', 'Mental Wellness'),
        ('lifestyle', 'Lifestyle Habits'),
    ]
    
    title = models.CharField(max_length=200)
    description = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    icon = models.CharField(max_length=50, default='fas fa-tasks')  # Font Awesome icon
    default_duration_days = models.IntegerField(default=7)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.title} ({self.category})"


class Prescription(models.Model):
    """Medical prescription from consultation"""
    consultation = models.OneToOneField(Consultation, on_delete=models.CASCADE, related_name='prescription')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    patient = models.ForeignKey(User, on_delete=models.CASCADE)
    prescription_text = models.TextField()
    medications = models.JSONField(default=list)  # [{"name": "Medicine", "dosage": "500mg", "frequency": "twice daily"}]
    instructions = models.TextField()
    pdf_file = models.FileField(upload_to='prescriptions/', null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Prescription for {self.patient.username} - {self.created_at.date()}"


class DailyTask(models.Model):
    """Tasks assigned to patients"""
    SOURCE_CHOICES = [
        ('template', 'From Template'),
        ('custom', 'Custom Created'),
    ]
    
    FREQUENCY_CHOICES = [
        ('once', 'Once Only'),
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('custom', 'Custom Days'),
    ]
    
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assigned_tasks')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    consultation = models.ForeignKey(Consultation, on_delete=models.CASCADE)
    prescription = models.ForeignKey(Prescription, on_delete=models.CASCADE, null=True, blank=True, related_name='tasks')
    
    # Task details
    title = models.CharField(max_length=200)
    description = models.TextField()
    category = models.CharField(max_length=20)
    icon = models.CharField(max_length=50, default='fas fa-tasks')
    source = models.CharField(max_length=10, choices=SOURCE_CHOICES)
    
    # Duration and frequency
    start_date = models.DateField()
    end_date = models.DateField()
    frequency = models.CharField(max_length=10, choices=FREQUENCY_CHOICES, default='daily')
    recurring_days = models.JSONField(default=list)  # [1,2,3,4,5] for Mon-Fri
    
    # Completion tracking
    is_completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    completion_notes = models.TextField(null=True, blank=True)
    
    # Reminder tracking
    reminder_times = models.JSONField(default=list)  # ["09:00", "14:00", "20:00"]
    reminders_sent = models.JSONField(default=dict)  # Track sent reminders
    
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.title} - {self.patient.username}"
    
    @property
    def is_today(self):
        from datetime import date
        today = date.today()
        if self.frequency == 'daily':
            return self.start_date <= today <= self.end_date
        elif self.frequency == 'weekly':
            return today.weekday() in self.recurring_days and self.start_date <= today <= self.end_date
        elif self.frequency == 'custom':
            return today.weekday() in self.recurring_days and self.start_date <= today <= self.end_date
        return False


class TaskCompletion(models.Model):
    """Track daily completion of tasks"""
    daily_task = models.ForeignKey(DailyTask, on_delete=models.CASCADE, related_name='completions')
    completion_date = models.DateField()
    is_completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    patient_notes = models.TextField(null=True, blank=True)
    completion_time = models.TimeField(null=True, blank=True)
    
    class Meta:
        unique_together = ['daily_task', 'completion_date']
    
    def __str__(self):
        return f"{self.daily_task.title} - {self.completion_date} ({'Completed' if self.is_completed else 'Incomplete'})"


class Notification(models.Model):
    """System notifications for users"""
    NOTIFICATION_TYPES = [
        ('task_reminder', 'Task Reminder'),
        ('task_incomplete', 'Incomplete Task'),
        ('prescription_update', 'Prescription Update'),
        ('appointment_reminder', 'Appointment Reminder'),
        ('system', 'System Notification'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    is_read = models.BooleanField(default=False)
    is_actionable = models.BooleanField(default=False)
    action_url = models.URLField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.title} - {self.user.username}"
