# home/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Main pages
    path('', views.home, name='home'),
    
    # Authentication
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('accounts/login/', views.login_view, name='login'),  # Add for Django default redirect
    path('logout/', views.logout_view, name='logout'),
    
    # Doctor profile completion
    path('doctor/complete-profile/<int:user_id>/', views.complete_doctor_profile, name='complete_doctor_profile'),
    
    # Dashboards
    path('patient/dashboard/', views.patient_dashboard, name='patient_dashboard'),
    path('doctor/dashboard/', views.doctor_dashboard, name='doctor_dashboard'),
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    
    # Assessment
    path('patient/assessment/', views.assessment, name='assessment'),
    path('patient/assessment/<int:assessment_id>/results/', views.assessment_results, name='assessment_results'),
    
    # Doctors and Appointments
    path('patient/doctors/', views.doctors_list, name='doctors_list'),
    path('patient/book-appointment/<int:doctor_id>/', views.book_appointment, name='book_appointment'),
    path('patient/appointments/', views.patient_appointments, name='patient_appointments'),
    
    # Consultation
    path('consultation/<int:appointment_id>/', views.consultation_room, name='consultation_room'),
    
    # API endpoints (commented for future implementation)
    # path('api/send-otp/', views.send_otp, name='send_otp'),
    # path('api/verify-otp/', views.verify_otp, name='verify_otp'),
    
    # Payment (commented for future implementation)
    # path('payment/process/<int:appointment_id>/', views.process_payment, name='process_payment'),
    # path('payment/success/', views.payment_success, name='payment_success'),
    # path('payment/fail/', views.payment_fail, name='payment_fail'),
]
