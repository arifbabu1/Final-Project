from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from datetime import datetime, timedelta
import json
import random
import string

from .models import (
    User, Doctor, AssessmentQuestion, PatientAssessment, 
    AssessmentAnswer, Appointment, Consultation, Payment
)


def home(request):
    """Landing page"""
    return render(request, 'home/homepage.html')


def register(request):
    """User registration page"""
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        role = request.POST.get('role', 'patient')
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return render(request, 'auth/register.html')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists')
            return render(request, 'auth/register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
            return render(request, 'auth/register.html')
        
        if User.objects.filter(phone=phone).exists():
            messages.error(request, 'Phone number already exists')
            return render(request, 'auth/register.html')
        
        user = User.objects.create_user(
            username=username,
            email=email,
            phone=phone,
            password=password,
            role=role
        )
        
        # If doctor, create doctor profile
        if role == 'doctor':
            return redirect('complete_doctor_profile', user_id=user.id)
        
        messages.success(request, 'Registration successful! Please login.')
        return redirect('login')
    
    return render(request, 'auth/register.html')


def login_view(request):
    """User login page"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
            # Redirect based on role
            if user.role == 'admin':
                return redirect('admin_dashboard')
            elif user.role == 'doctor':
                return redirect('doctor_dashboard')
            else:
                return redirect('patient_dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    
    return render(request, 'auth/login.html')


def logout_view(request):
    """User logout"""
    logout(request)
    return redirect('home')


@login_required
def complete_doctor_profile(request, user_id):
    """Complete doctor profile after registration"""
    if request.user.id != user_id or request.user.role != 'doctor':
        return redirect('home')
    
    if request.method == 'POST':
        specialty = request.POST.get('specialty')
        qualification = request.POST.get('qualification')
        experience_years = request.POST.get('experience_years')
        consultation_fee = request.POST.get('consultation_fee')
        
        Doctor.objects.create(
            user=request.user,
            specialty=specialty,
            qualification=qualification,
            experience_years=experience_years,
            consultation_fee=consultation_fee
        )
        
        messages.success(request, 'Doctor profile completed successfully!')
        return redirect('doctor_dashboard')
    
    return render(request, 'doctor/complete_profile.html')


@login_required
def patient_dashboard(request):
    """Patient dashboard"""
    if request.user.role != 'patient':
        return redirect('home')
    
    recent_assessments = PatientAssessment.objects.filter(
        patient=request.user
    ).order_by('-created_at')[:5]
    
    upcoming_appointments = Appointment.objects.filter(
        patient=request.user,
        appointment_date__gte=timezone.now(),
        status__in=['scheduled', 'confirmed']
    ).order_by('appointment_date')[:5]
    
    context = {
        'recent_assessments': recent_assessments,
        'upcoming_appointments': upcoming_appointments,
    }
    return render(request, 'patient/dashboard.html', context)


@login_required
def doctor_dashboard(request):
    """Doctor dashboard"""
    if request.user.role != 'doctor':
        return redirect('home')
    
    try:
        doctor = request.user.doctor_profile
    except Doctor.DoesNotExist:
        return redirect('complete_doctor_profile', user_id=request.user.id)
    
    today_appointments = Appointment.objects.filter(
        doctor=doctor,
        appointment_date__date=timezone.now().date(),
        status__in=['scheduled', 'confirmed']
    ).order_by('appointment_date')
    
    upcoming_appointments = Appointment.objects.filter(
        doctor=doctor,
        appointment_date__gt=timezone.now(),
        status__in=['scheduled', 'confirmed']
    ).order_by('appointment_date')[:10]
    
    context = {
        'doctor': doctor,
        'today_appointments': today_appointments,
        'upcoming_appointments': upcoming_appointments,
    }
    return render(request, 'doctor/dashboard.html', context)


@login_required
def admin_dashboard(request):
    """Admin dashboard"""
    if request.user.role != 'admin':
        return redirect('home')
    
    total_users = User.objects.count()
    total_patients = User.objects.filter(role='patient').count()
    total_doctors = User.objects.filter(role='doctor').count()
    total_appointments = Appointment.objects.count()
    
    recent_appointments = Appointment.objects.all().order_by('-created_at')[:10]
    
    context = {
        'total_users': total_users,
        'total_patients': total_patients,
        'total_doctors': total_doctors,
        'total_appointments': total_appointments,
        'recent_appointments': recent_appointments,
    }
    return render(request, 'admin/dashboard.html', context)


@login_required
def assessment(request):
    """Mental health assessment"""
    if request.user.role != 'patient':
        return redirect('home')
    
    questions = AssessmentQuestion.objects.all()
    
    if request.method == 'POST':
        total_score = 0
        answers = []
        
        for question in questions:
            answer_value = int(request.POST.get(f'question_{question.id}', 0))
            total_score += answer_value * question.weight_value
            answers.append({
                'question_id': question.id,
                'answer_value': answer_value
            })
        
        # Determine stress level
        if total_score <= 10:
            stress_level = 'low'
        elif total_score <= 20:
            stress_level = 'moderate'
        elif total_score <= 30:
            stress_level = 'high'
        else:
            stress_level = 'severe'
        
        # Create assessment record
        assessment = PatientAssessment.objects.create(
            patient=request.user,
            total_score=total_score,
            stress_level=stress_level,
            recommendations=f"Based on your {stress_level} stress level, consider consulting with a mental health professional."
        )
        
        # Save answers
        for answer_data in answers:
            AssessmentAnswer.objects.create(
                assessment=assessment,
                question_id=answer_data['question_id'],
                answer_value=answer_data['answer_value']
            )
        
        return redirect('assessment_results', assessment_id=assessment.id)
    
    context = {'questions': questions}
    return render(request, 'patient/assessment.html', context)


@login_required
def assessment_results(request, assessment_id):
    """Assessment results page"""
    if request.user.role != 'patient':
        return redirect('home')
    
    assessment = get_object_or_404(PatientAssessment, id=assessment_id, patient=request.user)
    answers = assessment.answers.select_related('question').all()
    
    context = {
        'assessment': assessment,
        'answers': answers,
    }
    return render(request, 'patient/assessment_results.html', context)


@login_required
def doctors_list(request):
    """List of available doctors"""
    if request.user.role != 'patient':
        return redirect('home')
    
    doctors = Doctor.objects.filter(is_available=True).select_related('user')
    
    context = {'doctors': doctors}
    return render(request, 'patient/doctors.html', context)


@login_required
def book_appointment(request, doctor_id):
    """Book appointment with a doctor"""
    if request.user.role != 'patient':
        return redirect('home')
    
    doctor = get_object_or_404(Doctor, id=doctor_id, is_available=True)
    
    if request.method == 'POST':
        appointment_date = request.POST.get('appointment_date')
        notes = request.POST.get('notes', '')
        
        # Parse appointment date
        try:
            appointment_datetime = datetime.strptime(appointment_date, '%Y-%m-%dT%H:%M')
        except ValueError:
            messages.error(request, 'Invalid appointment date format')
            context = {'doctor': doctor}
            return render(request, 'patient/book_appointment.html', context)
        
        # Create appointment
        appointment = Appointment.objects.create(
            patient=request.user,
            doctor=doctor,
            appointment_date=appointment_datetime,
            consultation_fee=doctor.consultation_fee,
            notes=notes
        )
        
        # Create payment record
        Payment.objects.create(
            appointment=appointment,
            amount=doctor.consultation_fee,
            admin_commission=0,  # Will be calculated when payment is processed
            doctor_earning=0,    # Will be calculated when payment is processed
        )
        
        messages.success(request, 'Appointment booked successfully!')
        return redirect('patient_appointments')
    
    context = {'doctor': doctor}
    return render(request, 'patient/book_appointment.html', context)


@login_required
def patient_appointments(request):
    """Patient appointments list"""
    if request.user.role != 'patient':
        return redirect('home')
    
    appointments = Appointment.objects.filter(
        patient=request.user
    ).select_related('doctor__user').order_by('-appointment_date')
    
    context = {'appointments': appointments}
    return render(request, 'patient/appointments.html', context)


@login_required
def consultation_room(request, appointment_id):
    """Video consultation room"""
    appointment = get_object_or_404(Appointment, id=appointment_id)
    
    # Check permissions
    if request.user.role == 'patient' and appointment.patient != request.user:
        return redirect('home')
    elif request.user.role == 'doctor' and appointment.doctor.user != request.user:
        return redirect('home')
    
    # Get or create consultation
    consultation, created = Consultation.objects.get_or_create(
        appointment=appointment,
        defaults={'room_name': f"room_{appointment.id}_{random.randint(1000, 9999)}"}
    )
    
    # Update appointment status
    if appointment.status == 'scheduled':
        appointment.status = 'in_progress'
        appointment.save()
    
    context = {
        'appointment': appointment,
        'consultation': consultation,
        'room_name': consultation.room_name,
    }
    
    if request.user.role == 'patient':
        return render(request, 'patient/consultation_room.html', context)
    else:
        return render(request, 'doctor/consultation_room.html', context)


# OTP functionality (commented for future implementation)
# def send_otp(request):
#     """Send OTP for verification"""
#     if request.method == 'POST':
#         phone = request.POST.get('phone')
#         
#         try:
#             user = User.objects.get(phone=phone)
#             user.generate_otp()
#             
#             # Send SMS logic here
#             # sms_service.send(phone, f"Your OTP is: {user.otp_code}")
#             
#             return JsonResponse({'success': True, 'message': 'OTP sent successfully'})
#         except User.DoesNotExist:
#             return JsonResponse({'success': False, 'message': 'Phone number not found'})
#     
#     return JsonResponse({'success': False, 'message': 'Invalid request'})


# def verify_otp(request):
#     """Verify OTP code"""
#     if request.method == 'POST':
#         phone = request.POST.get('phone')
#         otp_code = request.POST.get('otp_code')
#         
#         try:
#             user = User.objects.get(phone=phone, otp_code=otp_code)
#             
#             if user.otp_expires and user.otp_expires > timezone.now():
#                 user.is_verified = True
#                 user.otp_code = None
#                 user.otp_expires = None
#                 user.save()
#                 return JsonResponse({'success': True, 'message': 'OTP verified successfully'})
#             else:
#                 return JsonResponse({'success': False, 'message': 'OTP expired'})
#         except User.DoesNotExist:
#             return JsonResponse({'success': False, 'message': 'Invalid OTP'})
#     
#     return JsonResponse({'success': False, 'message': 'Invalid request'})


# Payment integration (commented for future implementation)
# def process_payment(request, appointment_id):
#     """Process payment for appointment"""
#     appointment = get_object_or_404(Appointment, id=appointment_id)
#     payment = appointment.payment
#     
#     if request.method == 'POST':
#         # SSLCommerz integration
#         sslcommerz = SSLCommerzPayment()
#         response = sslcommerz.create_payment(payment)
#         
#         if response['success']:
#             return redirect(response['gateway_url'])
#         else:
#             messages.error(request, 'Payment processing failed')
#             return redirect('patient_appointments')
#     
#     context = {'appointment': appointment, 'payment': payment}
#     return render(request, 'payment/process.html', context)


# def payment_success(request):
#     """Payment success callback"""
#     transaction_id = request.GET.get('transaction_id')
#     
#     # Verify payment with SSLCommerz
#     sslcommerz = SSLCommerzPayment()
#     result = sslcommerz.verify_payment(transaction_id)
#     
#     if result['success']:
#         # Update payment status
#         payment = Payment.objects.get(transaction_id=transaction_id)
#         payment.status = 'completed'
#         payment.transaction_id = transaction_id
#         payment.calculate_commission()
#         payment.save()
#         
#         messages.success(request, 'Payment successful!')
#     else:
#         messages.error(request, 'Payment verification failed')
#     
#     return redirect('patient_appointments')


# def payment_fail(request):
#     """Payment failure callback"""
#     transaction_id = request.GET.get('transaction_id')
#     
#     if transaction_id:
#         payment = Payment.objects.get(transaction_id=transaction_id)
#         payment.status = 'failed'
#         payment.save()
#     
#     messages.error(request, 'Payment failed. Please try again.')
#     return redirect('patient_appointments')
