# Mental Wellness Platform

A comprehensive Django-based mental health consultation platform that provides secure, professional mental health support through video consultations with certified professionals.

## 🌟 Features

### Core Features
- **Smart Assessment System**: Mental health quiz with weighted scoring and recommendations
- **Role-Based Access Control**: Patient, Doctor, and Admin dashboards with specific permissions
- **Secure Video Consultations**: Video calls with privacy controls
- **Payment Integration**: Payment gateway with automatic fee splitting (20% admin commission)
- **Multi-Layer Security**: User authentication and data protection
- **Responsive Design**: Modern UI with gradient color scheme

### Technical Architecture
- **Backend**: Django (Python)
- **Database**: SQLite with Django ORM
- **Frontend**: HTML/CSS/JavaScript
- **Styling**: Custom CSS with gradient theme (#08a1f7 and #09e0fe)

## 🚀 Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup Instructions

1. **Navigate to Project Directory**
   ```bash
   cd "MentalWellnessPlatform"
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv venv
   
   # Windows
   venv\Scripts\activate
   
   # macOS/Linux
   source venv/bin/activate
   ```

3. **Install Dependencies**
   ```bash
   pip install django
   ```

4. **Database Setup**
   ```bash
   # Create database tables
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create Superuser**
   ```bash
   python manage.py createsuperuser
   ```
   Follow the prompts to create an admin account.

6. **Populate Assessment Questions**
   ```bash
   python manage.py populate_assessment
   ```

7. **Run Development Server**
   ```bash
   python manage.py runserver
   ```

8. **Access the Application**
   - Open your browser and navigate to: `http://127.0.0.1:8000`
   - Admin panel: `http://127.0.0.1:8000/admin`

## 📁 Project Structure

```
MentalWellnessPlatform/
├── manage.py                    # Django management script
├── wellness_platform/           # Main project configuration
│   ├── __init__.py
│   ├── settings.py             # Django settings
│   ├── urls.py                # Main URL configuration
│   ├── wsgi.py                # WSGI configuration
│   └── asgi.py                # ASGI configuration
├── home/                       # Main application
│   ├── __init__.py
│   ├── admin.py                # Django admin configuration
│   ├── apps.py                # App configuration
│   ├── models.py              # Database models
│   ├── views.py               # View functions
│   ├── urls.py                # App URL configuration
│   ├── management/            # Django management commands
│   │   └── commands/
│   │       └── populate_assessment.py
│   ├── templates/             # HTML templates
│   │   ├── auth/             # Authentication templates
│   │   ├── patient/          # Patient templates
│   │   ├── doctor/           # Doctor templates
│   │   ├── admin/            # Admin templates
│   │   └── home/             # Home templates
│   └── static/               # Static files
│       └── css/
│           └── styles.css     # Main stylesheet
└── db.sqlite3                # SQLite database file
```

## 🔐 Security Features

### Authentication & Authorization
- **Role-Based Access**: Separate dashboards for patients, doctors, and admin
- **Session Management**: Secure session handling
- **Password Security**: Django's built-in password hashing

### Data Protection
- **SQL Injection Protection**: Django ORM prevents SQL injection
- **XSS Protection**: Django's template system prevents XSS attacks
- **CSRF Protection**: Built-in CSRF protection

## 💰 Payment System

### Payment Integration (Commented for Future)
- Payment gateway integration code is included but commented out
- Automatic fee splitting calculation
- Transaction tracking and status monitoring

## 🎥 Video Consultation

### Video Features
- Secure consultation rooms
- Unique room names for privacy
- Session management and tracking

## 🎨 UI/UX Design

### Color Scheme
- **Primary Color**: #08a1f7
- **Secondary Color**: #09e0fe
- **Gradient**: Linear gradient combining both colors
- **Design**: Modern, responsive, and accessible

## 📊 Assessment System

### Smart Scoring Algorithm
- **Weighted Questions**: Different weights for different categories
- **Dynamic Recommendations**: Based on assessment results
- **Stress Level Classification**: Low, Moderate, High, Severe categories

## 🔧 Admin Features

### Django Admin Integration
- **User Management**: Manage patients, doctors, and admin users
- **Assessment Management**: View and manage assessment questions and results
- **Appointment Management**: Track all appointments and consultations
- **Payment Tracking**: Monitor payment status and commissions

## 🚀 Future Enhancements

### Planned Features
- [ ] OTP verification system (code included but commented)
- [ ] Payment gateway integration
- [ ] Advanced analytics dashboard
- [ ] Mobile app development
- [ ] Multi-language support
- [ ] Advanced reporting system

## 📞 Support

### Emergency Contacts
- **Emergency Hotline**: +8801711988000
- **Email**: support@mentalwellness.com

## 🤝 Contributing

We welcome contributions to Mental Wellness Platform!

### Development Guidelines
- Follow Django best practices
- Write clean, maintainable code
- Update documentation

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- Django Framework for the robust backend
- Modern CSS techniques for responsive design
- Mental health professionals for domain expertise

---

**Made with ❤️ for mental wellness**

Mental Wellness Platform © 2026 All rights reserved. 






# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows)
venv\Scripts\activate

# Install Django
pip install django

# Set up database
python manage.py makemigrations
python manage.py migrate

# Create admin user (optional)
python manage.py createsuperuser

# Populate assessment questions
python manage.py populate_assessment

# Run the server
python manage.py runserver
