#!/usr/bin/env python3
"""
PythonAnywhere Deployment Script for Mental Wellness Platform
Run this after uploading your project to PythonAnywhere
"""

import os
import subprocess
import sys

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"\n{'='*50}")
    print(f"Step: {description}")
    print(f"Command: {command}")
    print(f"{'='*50}")
    
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print("SUCCESS!")
        print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print("ERROR!")
        print(f"Return code: {e.returncode}")
        print(f"Error output: {e.stderr}")
        return False

def main():
    print("Mental Wellness Platform - PythonAnywhere Deployment")
    print("=" * 60)
    
    # Check if we're on PythonAnywhere
    if 'PYTHONANYWHERE_SITE' not in os.environ:
        print("Warning: This script is designed for PythonAnywhere")
        print("Make sure you're running this on PythonAnywhere")
        response = input("Continue anyway? (y/n): ")
        if response.lower() != 'y':
            sys.exit(1)
    
    # Get project name
    project_name = input("Enter your project name (e.g., mentalwellness): ")
    
    # Step 1: Create virtual environment
    if not run_command(f"python3 -m venv ~/{project_name}/venv", "Creating virtual environment"):
        print("Failed to create virtual environment")
        return
    
    # Step 2: Activate virtual environment
    if not run_command(f"source ~/{project_name}/venv/bin/activate", "Activating virtual environment"):
        print("Failed to activate virtual environment")
        return
    
    # Step 3: Install requirements
    if not run_command(f"cd ~/{project_name} && pip install -r requirements.txt", "Installing requirements"):
        print("Failed to install requirements")
        return
    
    # Step 4: Collect static files
    if not run_command(f"cd ~/{project_name} && python manage.py collectstatic --noinput", "Collecting static files"):
        print("Failed to collect static files")
        return
    
    # Step 5: Run migrations
    if not run_command(f"cd ~/{project_name} && python manage.py migrate", "Running migrations"):
        print("Failed to run migrations")
        return
    
    # Step 6: Create superuser (optional)
    create_superuser = input("Create superuser? (y/n): ")
    if create_superuser.lower() == 'y':
        print("Creating superuser...")
        os.system(f"cd ~/{project_name} && python manage.py createsuperuser")
    
    # Step 7: Setup instructions
    print("\n" + "="*60)
    print("DEPLOYMENT COMPLETE!")
    print("="*60)
    print("\nNext steps:")
    print("1. Go to PythonAnywhere Web tab")
    print("2. Add new web app")
    print("3. Select 'Manual configuration'")
    print("4. Set Python path to: /usr/bin/python3.9")
    print("5. Set working directory to: /home/yourusername/" + project_name)
    print("6. Set virtualenv to: /home/yourusername/" + project_name + "/venv")
    print("7. Set WSGI file to: /home/yourusername/" + project_name + "/yourproject/wsgi.py")
    print("8. Add static files mapping: /static/ -> /home/yourusername/" + project_name + "/staticfiles/")
    print("9. Click 'Reload' and your site should be live!")
    
    print(f"\nYour site will be available at:")
    print(f"https://yourusername.pythonanywhere.com")

if __name__ == "__main__":
    main()
