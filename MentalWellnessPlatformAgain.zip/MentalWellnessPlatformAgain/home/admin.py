from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User, Doctor, AssessmentQuestion, PatientAssessment, 
    AssessmentAnswer, Appointment, Consultation, Payment
)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'phone', 'role', 'is_verified', 'date_joined')
    list_filter = ('role', 'is_verified', 'date_joined')
    search_fields = ('username', 'email', 'phone')
    ordering = ('-date_joined',)
    
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email', 'phone')}),
        ('Permissions', {'fields': ('role', 'is_verified', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'phone', 'password1', 'password2', 'role'),
        }),
    )


@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('user', 'specialty', 'experience_years', 'consultation_fee', 'is_available', 'created_at')
    list_filter = ('specialty', 'is_available', 'created_at')
    search_fields = ('user__username', 'user__email', 'specialty')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('user', 'specialty', 'qualification', 'experience_years')
        }),
        ('Professional Details', {
            'fields': ('consultation_fee', 'is_available', 'availability_schedule')
        }),
    )


@admin.register(AssessmentQuestion)
class AssessmentQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text', 'category', 'weight_value', 'created_at')
    list_filter = ('category', 'created_at')
    search_fields = ('question_text', 'category')
    ordering = ('category', 'weight_value')
    
    fieldsets = (
        ('Question Details', {
            'fields': ('question_text', 'category', 'weight_value')
        }),
    )


class AssessmentAnswerInline(admin.TabularInline):
    model = AssessmentAnswer
    extra = 0
    readonly_fields = ('created_at',)


@admin.register(PatientAssessment)
class PatientAssessmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'total_score', 'stress_level', 'created_at')
    list_filter = ('stress_level', 'created_at')
    search_fields = ('patient__username', 'patient__email')
    ordering = ('-created_at',)
    inlines = [AssessmentAnswerInline]
    
    fieldsets = (
        ('Assessment Details', {
            'fields': ('patient', 'total_score', 'stress_level', 'recommendations')
        }),
    )
    
    readonly_fields = ('created_at',)


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor', 'appointment_date', 'status', 'consultation_fee', 'created_at')
    list_filter = ('status', 'appointment_date', 'created_at')
    search_fields = ('patient__username', 'doctor__user__username')
    ordering = ('-appointment_date',)
    
    fieldsets = (
        ('Appointment Details', {
            'fields': ('patient', 'doctor', 'appointment_date', 'status', 'notes')
        }),
        ('Financial Details', {
            'fields': ('consultation_fee',)
        }),
    )
    
    readonly_fields = ('created_at', 'updated_at')


@admin.register(Consultation)
class ConsultationAdmin(admin.ModelAdmin):
    list_display = ('appointment', 'room_name', 'start_time', 'end_time', 'created_at')
    list_filter = ('start_time', 'created_at')
    search_fields = ('appointment__patient__username', 'appointment__doctor__user__username', 'room_name')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Consultation Details', {
            'fields': ('appointment', 'room_name', 'start_time', 'end_time')
        }),
        ('Additional Information', {
            'fields': ('recording_url', 'notes')
        }),
    )
    
    readonly_fields = ('created_at',)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('appointment', 'amount', 'admin_commission', 'doctor_earning', 'status', 'created_at')
    list_filter = ('status', 'payment_method', 'created_at')
    search_fields = ('appointment__patient__username', 'transaction_id')
    ordering = ('-created_at',)
    
    fieldsets = (
        ('Payment Details', {
            'fields': ('appointment', 'amount', 'status', 'transaction_id', 'payment_method')
        }),
        ('Financial Breakdown', {
            'fields': ('admin_commission', 'doctor_earning')
        }),
    )
    
    readonly_fields = ('created_at', 'updated_at')
    
    actions = ['calculate_commissions']
    
    def calculate_commissions(self, request, queryset):
        for payment in queryset:
            payment.calculate_commission()
        self.message_user(request, f"Commissions calculated for {queryset.count()} payments.")
    calculate_commissions.short_description = "Calculate commissions for selected payments"
