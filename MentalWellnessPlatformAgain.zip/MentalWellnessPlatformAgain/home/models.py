from django.db import models
from django.contrib.auth.models import AbstractUser
import json


class User(AbstractUser):
    ROLE_CHOICES = [
        ('patient', 'Patient'),
        ('doctor', 'Doctor'),
        ('admin', 'Admin'),
    ]
    
    phone = models.CharField(max_length=20, unique=True)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='patient')
    is_verified = models.BooleanField(default=False)
    otp_code = models.CharField(max_length=6, null=True, blank=True)
    otp_expires = models.DateTimeField(null=True, blank=True)
    
    # OTP functionality (commented for future implementation)
    # def generate_otp(self):
    #     import random
    #     from datetime import datetime, timedelta
    #     self.otp_code = f"{random.randint(100000, 999999)}"
    #     self.otp_expires = datetime.now() + timedelta(minutes=10)
    #     self.save()
    
    def __str__(self):
        return f"{self.username} ({self.role})"


class Doctor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='doctor_profile')
    specialty = models.CharField(max_length=255)
    qualification = models.TextField()
    experience_years = models.PositiveIntegerField()
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    is_available = models.BooleanField(default=True)
    availability_schedule = models.JSONField(default=dict, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Dr. {self.user.get_full_name()} - {self.specialty}"


class AssessmentQuestion(models.Model):
    question_text = models.TextField()
    weight_value = models.IntegerField(default=1)
    category = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.category}: {self.question_text[:50]}..."


class PatientAssessment(models.Model):
    STRESS_LEVEL_CHOICES = [
        ('low', 'Low'),
        ('moderate', 'Moderate'),
        ('high', 'High'),
        ('severe', 'Severe'),
    ]
    
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assessments')
    total_score = models.IntegerField()
    stress_level = models.CharField(max_length=10, choices=STRESS_LEVEL_CHOICES)
    recommendations = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.patient.username} - {self.stress_level} stress"


class AssessmentAnswer(models.Model):
    assessment = models.ForeignKey(PatientAssessment, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(AssessmentQuestion, on_delete=models.CASCADE)
    answer_value = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['assessment', 'question']


class Appointment(models.Model):
    STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),
        ('confirmed', 'Confirmed'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='patient_appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name='doctor_appointments')
    appointment_date = models.DateTimeField()
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='scheduled')
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2)
    notes = models.TextField(null=True, blank=True)
    meeting_id = models.CharField(max_length=20, null=True, blank=True)
    meeting_link = models.URLField(max_length=500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.patient.username} - Dr. {self.doctor.user.get_full_name()} - {self.appointment_date}"


class Consultation(models.Model):
    appointment = models.OneToOneField(Appointment, on_delete=models.CASCADE, related_name='consultation')
    room_name = models.CharField(max_length=255, unique=True)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    recording_url = models.URLField(null=True, blank=True)
    notes = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Consultation for {self.appointment}"


class Payment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
    ]
    
    appointment = models.OneToOneField(Appointment, on_delete=models.CASCADE, related_name='payment')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    admin_commission = models.DecimalField(max_digits=10, decimal_places=2)
    doctor_earning = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='pending')
    transaction_id = models.CharField(max_length=255, null=True, blank=True)
    payment_method = models.CharField(max_length=50, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def calculate_commission(self, commission_rate=0.20):
        from decimal import Decimal
        commission_rate = Decimal(str(commission_rate))
        self.admin_commission = self.amount * commission_rate
        self.doctor_earning = self.amount - self.admin_commission
        self.save()
    
    def __str__(self):
        return f"Payment for {self.appointment} - {self.status}"


# Payment integration (commented for future implementation)
# class SSLCommerzPayment:
#     def __init__(self):
#         self.store_id = "your_store_id"
#         self.store_password = "your_store_password"
#         self.base_url = "https://sandbox.sslcommerz.com"
#     
#     def create_payment(self, payment):
#         # SSLCommerz integration code here
#         pass
#     
#     def verify_payment(self, transaction_id):
#         # Payment verification code here
#         pass
