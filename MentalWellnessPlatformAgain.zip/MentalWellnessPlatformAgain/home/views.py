from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from datetime import datetime, timedelta
import json
import random
import string

from .models import (
    User, Doctor, AssessmentQuestion, PatientAssessment, 
    AssessmentAnswer, Appointment, Consultation, Payment
)


def home(request):
    """Landing page"""
    return render(request, 'home/homepage.html')


def register(request):
    """User registration page"""
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        role = request.POST.get('role', 'patient')
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return render(request, 'auth/register.html')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists')
            return render(request, 'auth/register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
            return render(request, 'auth/register.html')
        
        if User.objects.filter(phone=phone).exists():
            messages.error(request, 'Phone number already exists')
            return render(request, 'auth/register.html')
        
        user = User.objects.create_user(
            username=username,
            email=email,
            phone=phone,
            password=password,
            role=role
        )
        
        # If doctor, create doctor profile
        if role == 'doctor':
            return redirect('complete_doctor_profile', user_id=user.id)
        
        messages.success(request, 'Registration successful! Please login.')
        return redirect('login')
    
    return render(request, 'auth/register.html')


def login_view(request):
    """User login page"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
            # Redirect based on role
            if user.role == 'admin':
                return redirect('admin_dashboard')
            elif user.role == 'doctor':
                return redirect('doctor_dashboard')
            else:
                return redirect('patient_dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    
    return render(request, 'auth/login.html')


def logout_view(request):
    """User logout"""
    logout(request)
    return redirect('home')


@login_required
def complete_doctor_profile(request, user_id):
    """Complete doctor profile after registration"""
    if request.user.id != user_id or request.user.role != 'doctor':
        return redirect('home')
    
    if request.method == 'POST':
        specialty = request.POST.get('specialization')
        qualification = request.POST.get('qualification')
        experience_years = request.POST.get('experience')
        consultation_fee = request.POST.get('consultation_fee')
        
        # Handle empty consultation_fee by setting it to None or 0
        consultation_fee = consultation_fee.strip() if consultation_fee else None
        if consultation_fee == '':
            consultation_fee = None
        
        Doctor.objects.create(
            user=request.user,
            specialty=specialty,
            qualification=qualification,
            experience_years=experience_years,
            consultation_fee=consultation_fee
        )
        
        messages.success(request, 'Doctor profile completed successfully!')
        return redirect('doctor_dashboard')
    
    return render(request, 'doctor/complete_profile.html')


@login_required
def patient_dashboard(request):
    """Patient dashboard"""
    if request.user.role != 'patient':
        return redirect('home')
    
    recent_assessments = PatientAssessment.objects.filter(
        patient=request.user
    ).order_by('-created_at')[:5]
    
    upcoming_appointments = Appointment.objects.filter(
        patient=request.user,
        appointment_date__gte=timezone.now(),
        status__in=['scheduled', 'confirmed']
    ).order_by('appointment_date')[:5]
    
    context = {
        'recent_assessments': recent_assessments,
        'upcoming_appointments': upcoming_appointments,
    }
    return render(request, 'patient/dashboard.html', context)


@login_required
def doctor_dashboard(request):
    """Doctor dashboard"""
    if request.user.role != 'doctor':
        return redirect('home')
    
    try:
        doctor = request.user.doctor_profile
    except Doctor.DoesNotExist:
        return redirect('complete_doctor_profile', user_id=request.user.id)
    
    today_appointments = Appointment.objects.filter(
        doctor=doctor,
        appointment_date__date=timezone.now().date(),
        status__in=['scheduled', 'confirmed']
    ).order_by('appointment_date')
    
    upcoming_appointments = Appointment.objects.filter(
        doctor=doctor,
        appointment_date__gt=timezone.now(),
        status__in=['scheduled', 'confirmed']
    ).order_by('appointment_date')[:10]
    
    context = {
        'doctor': doctor,
        'today_appointments': today_appointments,
        'upcoming_appointments': upcoming_appointments,
    }
    return render(request, 'doctor/dashboard.html', context)


@login_required
def admin_dashboard(request):
    """Admin dashboard"""
    if request.user.role != 'admin':
        return redirect('home')
    
    total_users = User.objects.count()
    total_patients = User.objects.filter(role='patient').count()
    total_doctors = User.objects.filter(role='doctor').count()
    total_appointments = Appointment.objects.count()
    
    recent_appointments = Appointment.objects.all().order_by('-created_at')[:10]
    
    context = {
        'total_users': total_users,
        'total_patients': total_patients,
        'total_doctors': total_doctors,
        'total_appointments': total_appointments,
        'recent_appointments': recent_appointments,
    }
    return render(request, 'admin/dashboard.html', context)


@login_required
def assessment(request):
    """Mental health assessment"""
    if request.user.role != 'patient':
        return redirect('home')
    
    questions = AssessmentQuestion.objects.all()
    
    if request.method == 'POST':
        total_score = 0
        answers = []
        
        for question in questions:
            answer_value = int(request.POST.get(f'question_{question.id}', 0))
            total_score += answer_value * question.weight_value
            answers.append({
                'question_id': question.id,
                'answer_value': answer_value
            })
        
        # Determine stress level
        if total_score <= 10:
            stress_level = 'low'
        elif total_score <= 20:
            stress_level = 'moderate'
        elif total_score <= 30:
            stress_level = 'high'
        else:
            stress_level = 'severe'
        
        # Create assessment record
        assessment = PatientAssessment.objects.create(
            patient=request.user,
            total_score=total_score,
            stress_level=stress_level,
            recommendations=f"Based on your {stress_level} stress level, consider consulting with a mental health professional."
        )
        
        # Save answers
        for answer_data in answers:
            AssessmentAnswer.objects.create(
                assessment=assessment,
                question_id=answer_data['question_id'],
                answer_value=answer_data['answer_value']
            )
        
        return redirect('assessment_results', assessment_id=assessment.id)
    
    context = {'questions': questions}
    return render(request, 'patient/assessment.html', context)


@login_required
def assessment_results(request, assessment_id):
    """Assessment results page"""
    if request.user.role != 'patient':
        return redirect('home')
    
    assessment = get_object_or_404(PatientAssessment, id=assessment_id, patient=request.user)
    answers = assessment.answers.select_related('question').all()
    
    # Calculate category scores
    category_scores = {}
    for answer in answers:
        category = answer.question.category
        if category not in category_scores:
            category_scores[category] = 0
        category_scores[category] += answer.answer_value * answer.question.weight_value
    
    # Generate personalized recommendations based on scores and stress level
    recommendations = generate_personalized_recommendations(assessment.stress_level, category_scores)
    
    context = {
        'assessment': assessment,
        'answers': answers,
        'category_scores': category_scores,
        'recommendations': recommendations,
    }
    return render(request, 'patient/assessment_results.html', context)


def generate_personalized_recommendations(stress_level, category_scores):
    """Generate personalized recommendations based on assessment results"""
    recommendations = []
    
    # Base recommendations by stress level
    if stress_level == 'Low':
        recommendations.append({
            'icon': '✅',
            'title': 'Continue Your Wellness Journey',
            'description': 'Your mental health appears to be in good shape. Continue practicing self-care, maintaining healthy habits, and regular check-ins to sustain your wellbeing.',
            'priority': 'low',
            'actionable_steps': [
                'Maintain regular sleep schedule (7-9 hours)',
                'Continue physical activity (30 mins daily)',
                'Practice mindfulness or meditation 10-15 minutes daily',
                'Stay connected with supportive friends and family',
                'Engage in hobbies and activities you enjoy'
            ]
        })
    elif stress_level == 'Moderate':
        recommendations.append({
            'icon': '💡',
            'title': 'Consider Professional Support',
            'description': 'Your results suggest moderate stress levels. Speaking with a mental health professional can provide valuable tools and strategies for managing stress effectively.',
            'priority': 'medium',
            'actionable_steps': [
                'Schedule consultation with a mental health professional',
                'Practice stress management techniques (deep breathing, progressive muscle relaxation)',
                'Establish healthy boundaries in work and personal life',
                'Consider cognitive behavioral therapy techniques',
                'Join support groups or wellness communities'
            ]
        })
    elif stress_level == 'High':
        recommendations.append({
            'icon': '🎯',
            'title': 'Professional Help Recommended',
            'description': 'We strongly recommend connecting with a mental health professional for personalized support and guidance. Your symptoms may benefit from professional intervention.',
            'priority': 'high',
            'actionable_steps': [
                'Seek immediate consultation with a mental health professional',
                'Consider therapy or counseling sessions',
                'Practice daily stress reduction techniques',
                'Inform trusted family members or friends about your situation',
                'Create a structured daily routine for stability'
            ]
        })
    elif stress_level == 'Severe':
        recommendations.append({
            'icon': '🚨',
            'title': 'Immediate Support Available',
            'description': 'Your results suggest significant distress. Please don\'t hesitate to reach out for immediate professional support. Help is available and you don\'t have to face this alone.',
            'priority': 'urgent',
            'actionable_steps': [
                'Contact mental health professional immediately',
                'Call emergency hotline: +8801711988000',
                'Reach out to trusted family or friends',
                'Consider crisis intervention services',
                'Remove yourself from overwhelming situations if possible'
            ]
        })
    
    # Category-specific recommendations with detailed analysis
    for category, score in category_scores.items():
        if score >= 15:  # High score in category indicates concern
            if category == 'Depression':
                recommendations.append({
                    'icon': '🌧️',
                    'title': 'Focus on Mood Management',
                    'description': 'Your responses indicate symptoms of depression. Focus on activities that boost mood and consider professional support for comprehensive care.',
                    'priority': 'high',
                    'actionable_steps': [
                        'Engage in regular physical exercise (releases endorphins)',
                        'Get sunlight exposure daily (15-30 minutes)',
                        'Practice gratitude journaling (3 things daily)',
                        'Connect with supportive people regularly',
                        'Consider antidepressant medications with professional guidance',
                        'Establish a consistent daily routine',
                        'Limit alcohol and avoid recreational drugs',
                        'Practice self-compassion and positive self-talk'
                    ]
                })
            elif category == 'Anxiety':
                recommendations.append({
                    'icon': '🧘',
                    'title': 'Practice Anxiety Management',
                    'description': 'Your anxiety levels appear elevated. Learning relaxation techniques and coping strategies can significantly help manage anxiety symptoms.',
                    'priority': 'high',
                    'actionable_steps': [
                        'Practice 4-7-8 breathing technique (inhale 4, hold 7, exhale 8)',
                        'Try progressive muscle relaxation daily',
                        'Limit caffeine and stimulant intake',
                        'Practice mindfulness meditation (10-20 minutes daily)',
                        'Challenge anxious thoughts with cognitive restructuring',
                        'Create a worry time limit (15-20 minutes daily)',
                        'Use grounding techniques (5-4-3-2-1 method)',
                        'Consider anti-anxiety medications if prescribed'
                    ]
                })
            elif category == 'Sleep':
                recommendations.append({
                    'icon': '😴',
                    'title': 'Improve Sleep Hygiene',
                    'description': 'Quality sleep is crucial for mental health. Establishing proper sleep habits can significantly improve your overall wellbeing.',
                    'priority': 'medium',
                    'actionable_steps': [
                        'Maintain consistent sleep schedule (same bedtime/wake time)',
                        'Avoid screens 1 hour before bed (blue light affects melatonin)',
                        'Create relaxing bedtime routine (reading, gentle music)',
                        'Keep bedroom cool, dark, and quiet',
                        'Avoid caffeine after 2 PM',
                        'Exercise regularly but not within 3 hours of bedtime',
                        'Consider natural sleep aids (melatonin, valerian root)',
                        'Limit fluids 2 hours before bedtime'
                    ]
                })
            elif category == 'Energy':
                recommendations.append({
                    'icon': '⚡',
                    'title': 'Boost Energy Levels Naturally',
                    'description': 'Low energy can impact daily functioning. Focus on nutrition, exercise, and lifestyle changes to improve your energy levels.',
                    'priority': 'medium',
                    'actionable_steps': [
                        'Eat balanced meals with protein, complex carbs, healthy fats',
                        'Stay hydrated (8 glasses of water daily)',
                        'Take short walks every 2 hours',
                        'Practice good posture to improve energy flow',
                        'Consider vitamin B12 and D supplements',
                        'Limit processed foods and sugar',
                        'Take power naps (10-20 minutes) if needed',
                        'Practice stress management to conserve energy'
                    ]
                })
            elif category == 'Self-esteem':
                recommendations.append({
                    'icon': '💪',
                    'title': 'Build Self-Confidence',
                    'description': 'Working on self-esteem can improve overall mental health. Focus on self-acceptance and personal growth strategies.',
                    'priority': 'medium',
                    'actionable_steps': [
                        'Practice positive affirmations daily',
                        'Set and achieve small, realistic goals',
                        'Keep a success journal (document achievements)',
                        'Challenge negative self-talk with evidence',
                        'Learn new skills or hobbies to build competence',
                        'Surround yourself with supportive people',
                        'Practice self-care without guilt',
                        'Consider therapy to work on self-worth issues'
                    ]
                })
    
    # Add lifestyle recommendations based on overall pattern
    if len([s for s in category_scores.values() if s >= 15]) >= 3:
        recommendations.append({
            'icon': '🌟',
            'title': 'Comprehensive Lifestyle Reset',
            'description': 'Multiple areas show elevated concern. A holistic approach to lifestyle changes can create significant improvement across all areas.',
            'priority': 'high',
            'actionable_steps': [
                'Create a structured daily schedule',
                'Implement morning routine (exercise, meditation, healthy breakfast)',
                'Practice digital detox (limit screen time)',
                'Establish work-life boundaries',
                'Join group activities or classes',
                'Consider nutritional counseling',
                'Practice time management techniques',
                'Build a strong support network'
            ]
        })
    
    # Add positive reinforcement for areas doing well
    good_categories = [cat for cat, score in category_scores.items() if score < 10]
    if good_categories:
        recommendations.append({
            'icon': '🌈',
            'title': 'Build on Your Strengths',
            'description': f'You\'re showing good progress in: {", ".join(good_categories)}. Continue these positive practices while working on other areas.',
            'priority': 'low',
            'actionable_steps': [
                'Continue what\'s working well in these areas',
                'Share your successful strategies with others',
                'Use these strengths as motivation for other areas',
                'Teach or mentor others in your strong areas',
                'Document your successful techniques',
                'Celebrate your progress regularly'
            ]
        })
    
    return recommendations


@login_required
def doctors_list(request):
    """List of available doctors"""
    if request.user.role != 'patient':
        return redirect('home')
    
    doctors = Doctor.objects.filter(is_available=True).select_related('user')
    
    context = {'doctors': doctors}
    return render(request, 'patient/doctors.html', context)


@login_required
def book_appointment(request, doctor_id):
    """Book appointment with a doctor"""
    if request.user.role != 'patient':
        return redirect('home')
    
    try:
        doctor = Doctor.objects.get(id=doctor_id, is_available=True)
    except Doctor.DoesNotExist:
        messages.error(request, 'Doctor not found or not available. Please choose another doctor.')
        return redirect('doctors_list')
    
    # Generate available dates (next 7 days)
    from datetime import datetime, timedelta
    available_dates = []
    for i in range(7):
        date = datetime.now() + timedelta(days=i+1)
        available_dates.append({
            'date': date.strftime('%Y-%m-%d'),
            'day_name': date.strftime('%A'),
            'formatted_date': date.strftime('%b %d')
        })
    
    # Generate time slots (9 AM - 6 PM, hourly)
    time_slots = []
    for hour in range(9, 19):
        time_str = f"{hour:02d}:00"
        # Randomly mark some as unavailable for demo
        available = hour not in [12, 13, 17]  # Lunch break and some busy slots
        time_slots.append({
            'time': time_str,
            'available': available
        })
    
    if request.method == 'POST':
        appointment_date = request.POST.get('appointment_date')
        appointment_time = request.POST.get('appointment_time')
        consultation_type = request.POST.get('consultation_type', 'video')
        payment_method = request.POST.get('payment_method', 'card')
        notes = request.POST.get('notes', '')
        
        # Validate date and time
        if not appointment_date or not appointment_time:
            messages.error(request, 'Please select both date and time for your appointment.')
            context = {
                'doctor': doctor,
                'available_dates': available_dates,
                'time_slots': time_slots
            }
            return render(request, 'patient/book_appointment.html', context)
        
        # Combine date and time
        try:
            appointment_datetime = datetime.strptime(f"{appointment_date} {appointment_time}", '%Y-%m-%d %H:%M')
        except ValueError:
            messages.error(request, 'Invalid appointment date or time format')
            context = {
                'doctor': doctor,
                'available_dates': available_dates,
                'time_slots': time_slots
            }
            return render(request, 'patient/book_appointment.html', context)
        
        # Check if doctor has consultation fee
        if not doctor.consultation_fee:
            messages.error(request, 'This doctor does not have a consultation fee set. Please contact support.')
            context = {
                'doctor': doctor,
                'available_dates': available_dates,
                'time_slots': time_slots
            }
            return render(request, 'patient/book_appointment.html', context)
        
        # Create appointment
        appointment = Appointment.objects.create(
            patient=request.user,
            doctor=doctor,
            appointment_date=appointment_datetime,
            consultation_fee=doctor.consultation_fee,
            notes=notes,
            status='pending_payment'
        )
        
        # Create payment record
        payment = Payment.objects.create(
            appointment=appointment,
            amount=doctor.consultation_fee,
            admin_commission=0,  # Will be calculated when payment is processed
            doctor_earning=0,    # Will be calculated when payment is processed
            status='pending',
            payment_method=payment_method
        )
        
        messages.success(request, 'Appointment created! Please complete the payment to confirm your booking.')
        return redirect('process_payment', payment_id=payment.id)
    
    context = {
        'doctor': doctor,
        'available_dates': available_dates,
        'time_slots': time_slots
    }
    return render(request, 'patient/book_appointment.html', context)


@login_required
def process_payment(request, payment_id):
    """Process payment for appointment"""
    if request.user.role != 'patient':
        return redirect('home')
    
    try:
        payment = Payment.objects.get(id=payment_id, appointment__patient=request.user)
        appointment = payment.appointment
        doctor = appointment.doctor
    except Payment.DoesNotExist:
        messages.error(request, 'Payment not found.')
        return redirect('patient_appointments')
    
    if request.method == 'POST':
        if payment.payment_method == 'card':
            card_number = request.POST.get('card_number')
            card_name = request.POST.get('card_name')
            card_expiry = request.POST.get('card_expiry')
            card_cvv = request.POST.get('card_cvv')
            
            # Validate card details
            if not all([card_number, card_name, card_expiry, card_cvv]):
                messages.error(request, 'Please fill in all card details.')
            elif len(card_number.replace(' ', '')) < 13:
                messages.error(request, 'Please enter a valid card number.')
            elif len(card_cvv) < 3:
                messages.error(request, 'Please enter a valid CVV.')
            else:
                # ACTUAL PAYMENT PROCESSING CODE (COMMENTED FOR TESTING)
                """
                # Process card payment with payment gateway
                try:
                    # Call payment gateway API here
                    gateway_response = process_card_payment(
                        card_number=card_number,
                        card_name=card_name,
                        card_expiry=card_expiry,
                        card_cvv=card_cvv,
                        amount=payment.amount
                    )
                    
                    if gateway_response['status'] == 'success':
                        payment.status = 'completed'
                        payment.transaction_id = gateway_response['transaction_id']
                        payment.calculate_commission()
                        payment.save()
                    else:
                        payment.status = 'failed'
                        payment.save()
                        messages.error(request, f'Payment failed: {gateway_response["message"]}')
                        return render(request, 'patient/process_payment.html', context)
                        
                except Exception as e:
                    payment.status = 'failed'
                    payment.save()
                    messages.error(request, f'Payment processing error: {str(e)}')
                    return render(request, 'patient/process_payment.html', context)
                """
                
                # TESTING MODE: Simulate successful payment
                payment.status = 'completed'
                payment.transaction_id = f"CARD_TEST_{datetime.now().strftime('%Y%m%d%H%M%S')}"
                payment.calculate_commission()
                payment.save()
                
                # Generate meeting link and complete appointment
                meeting_link = generate_meeting_link(appointment)
                appointment.meeting_link = meeting_link
                appointment.status = 'confirmed'
                appointment.save()
                
                # Send notifications
                send_payment_notifications(appointment, doctor, meeting_link)
                
                messages.success(request, 'Payment successful! Your appointment is confirmed. Meeting link sent to your email.')
                return redirect('patient_appointments')
        
        elif payment.payment_method in ['bkash', 'nagad']:
            mobile_number = request.POST.get('mobile_number')
            
            # Validate mobile number
            if not mobile_number:
                messages.error(request, 'Please enter your mobile number.')
            elif len(mobile_number) < 11:
                messages.error(request, 'Please enter a valid mobile number (11 digits).')
            else:
                # ACTUAL MOBILE PAYMENT PROCESSING CODE (COMMENTED FOR TESTING)
                """
                # Process mobile payment with payment gateway
                try:
                    # Call mobile payment API here (bKash/Nagad)
                    gateway_response = process_mobile_payment(
                        payment_method=payment.payment_method,
                        mobile_number=mobile_number,
                        amount=payment.amount
                    )
                    
                    if gateway_response['status'] == 'success':
                        payment.status = 'completed'
                        payment.transaction_id = gateway_response['transaction_id']
                        payment.calculate_commission()
                        payment.save()
                    else:
                        payment.status = 'failed'
                        payment.save()
                        messages.error(request, f'Payment failed: {gateway_response["message"]}')
                        return render(request, 'patient/process_payment.html', context)
                        
                except Exception as e:
                    payment.status = 'failed'
                    payment.save()
                    messages.error(request, f'Payment processing error: {str(e)}')
                    return render(request, 'patient/process_payment.html', context)
                """
                
                # TESTING MODE: Simulate successful payment
                payment.status = 'completed'
                payment.transaction_id = f"{payment.payment_method.upper()}_TEST_{datetime.now().strftime('%Y%m%d%H%M%S')}"
                payment.calculate_commission()
                payment.save()
                
                # Generate meeting link and complete appointment
                meeting_link = generate_meeting_link(appointment)
                appointment.meeting_link = meeting_link
                appointment.status = 'confirmed'
                appointment.save()
                
                # Send notifications
                send_payment_notifications(appointment, doctor, meeting_link)
                
                messages.success(request, f'Payment successful via {payment.payment_method.title()}! Your appointment is confirmed. Meeting link sent to your email.')
                return redirect('patient_appointments')
    
    context = {
        'payment': payment,
        'appointment': appointment,
        'doctor': doctor
    }
    return render(request, 'patient/process_payment.html', context)


def generate_meeting_link(appointment):
    """Generate unique meeting link for consultation"""
    import secrets
    
    # Generate unique meeting ID
    meeting_id = secrets.token_urlsafe(8)
    meeting_link = f"http://127.0.0.1:8000/consultation/{appointment.id}/"
    
    # Save meeting details
    appointment.meeting_id = meeting_id
    appointment.meeting_link = meeting_link
    
    return meeting_link


def send_payment_notifications(appointment, doctor, meeting_link):
    """Send notifications to patient and doctor"""
    from django.core.mail import send_mail
    from django.conf import settings
    from django.template.loader import render_to_string
    
    patient = appointment.patient
    doctor_user = doctor.user
    
    # Email to Patient
    patient_subject = "Appointment Confirmed - Meeting Link Inside"
    patient_message = f"""
    Dear {patient.get_full_name() or patient.username},
    
    Your appointment has been confirmed!
    
    Appointment Details:
    - Doctor: Dr. {doctor_user.get_full_name()}
    - Date: {appointment.appointment_date.strftime('%B %d, %Y at %I:%M %p')}
    - Meeting Link: {meeting_link}
    
    Please join the meeting 5 minutes before your scheduled time.
    
    Best regards,
    Wellness Platform Team
    """
    
    # Email to Doctor
    doctor_subject = "New Appointment Scheduled - Meeting Link Inside"
    doctor_message = f"""
    Dear Dr. {doctor_user.get_full_name()},
    
    You have a new appointment scheduled!
    
    Appointment Details:
    - Patient: {patient.get_full_name() or patient.username}
    - Date: {appointment.appointment_date.strftime('%B %d, %Y at %I:%M %p')}
    - Meeting Link: {meeting_link}
    
    Please join the meeting 5 minutes before the scheduled time.
    
    Best regards,
    Wellness Platform Team
    """
    
    try:
        # Send emails (commented for testing - uncomment when email is configured)
        """
        send_mail(
            patient_subject,
            patient_message,
            settings.DEFAULT_FROM_EMAIL,
            [patient.email],
            fail_silently=False,
        )
        
        send_mail(
            doctor_subject,
            doctor_message,
            settings.DEFAULT_FROM_EMAIL,
            [doctor_user.email],
            fail_silently=False,
        )
        """
        
        # For testing: Print to console (remove in production)
        print(f"=== EMAIL TO PATIENT ===")
        print(f"To: {patient.email}")
        print(f"Subject: {patient_subject}")
        print(f"Message: {patient_message}")
        print(f"========================")
        
        print(f"=== EMAIL TO DOCTOR ===")
        print(f"To: {doctor_user.email}")
        print(f"Subject: {doctor_subject}")
        print(f"Message: {doctor_message}")
        print(f"======================")
        
    except Exception as e:
        # Log error but don't fail the payment process
        print(f"Email sending failed: {e}")
    
    # Create in-app notifications (you might want to create a Notification model)
    """
    # Patient notification
    Notification.objects.create(
        user=patient,
        title="Appointment Confirmed",
        message=f"Your appointment with Dr. {doctor_user.get_full_name()} is confirmed. Meeting link: {meeting_link}",
        appointment=appointment
    )
    
    # Doctor notification
    Notification.objects.create(
        user=doctor_user,
        title="New Appointment",
        message=f"New appointment with {patient.get_full_name() or patient.username}. Meeting link: {meeting_link}",
        appointment=appointment
    )
    """


@login_required
def patient_appointments(request):
    """Patient appointments list"""
    if request.user.role != 'patient':
        return redirect('home')
    
    appointments = Appointment.objects.filter(
        patient=request.user
    ).select_related('doctor__user').order_by('-appointment_date')
    
    context = {'appointments': appointments}
    return render(request, 'patient/appointments.html', context)


@login_required
def doctor_appointments(request):
    """Doctor appointments list"""
    if request.user.role != 'doctor':
        return redirect('home')
    
    try:
        doctor = request.user.doctor_profile
        appointments = Appointment.objects.filter(
            doctor=doctor
        ).select_related('patient').order_by('-appointment_date')
        
        context = {'appointments': appointments}
        return render(request, 'doctor/appointments.html', context)
    except Doctor.DoesNotExist:
        messages.error(request, 'Doctor profile not found.')
        return redirect('home')


@login_required
def consultation_room(request, appointment_id):
    """Video consultation room"""
    appointment = get_object_or_404(Appointment, id=appointment_id)
    
    # Check permissions
    if request.user.role == 'patient' and appointment.patient != request.user:
        return redirect('home')
    elif request.user.role == 'doctor' and appointment.doctor.user != request.user:
        return redirect('home')
    
    # Check if appointment is confirmed
    if appointment.status != 'confirmed':
        messages.error(request, 'Consultation room is only available for confirmed appointments.')
        return redirect('patient_appointments' if request.user.role == 'patient' else 'doctor_appointments')
    
    # Get or create consultation
    consultation, created = Consultation.objects.get_or_create(
        appointment=appointment,
        defaults={
            'room_name': appointment.meeting_id or f"room_{appointment.id}",
            'start_time': timezone.now() if created else None
        }
    )
    
    context = {
        'appointment': appointment,
        'consultation': consultation,
        'room_name': consultation.room_name
    }
    return render(request, 'consultation/room.html', context)


@login_required
def save_consultation_notes(request, appointment_id):
    """Save consultation notes (doctors only)"""
    if request.user.role != 'doctor':
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    
    appointment = get_object_or_404(Appointment, id=appointment_id)
    
    # Check if doctor owns this appointment
    if appointment.doctor.user != request.user:
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            notes = data.get('notes', '')
            
            # Get or create consultation
            consultation, created = Consultation.objects.get_or_create(
                appointment=appointment,
                defaults={'notes': notes}
            )
            
            if not created:
                consultation.notes = notes
                consultation.save()
            
            return JsonResponse({'success': True, 'message': 'Notes saved successfully'})
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)


@login_required
def complete_consultation(request, appointment_id):
    """Complete consultation"""
    appointment = get_object_or_404(Appointment, id=appointment_id)
    
    # Check permissions
    if request.user.role == 'patient' and appointment.patient != request.user:
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    elif request.user.role == 'doctor' and appointment.doctor.user != request.user:
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    
    if request.method == 'POST':
        try:
            # Update appointment status
            appointment.status = 'completed'
            appointment.save()
            
            # Update consultation end time
            consultation = Consultation.objects.get(appointment=appointment)
            consultation.end_time = timezone.now()
            consultation.save()
            
            return JsonResponse({'success': True, 'message': 'Consultation completed'})
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)


# OTP functionality (commented for future implementation)
# def send_otp(request):
#     """Send OTP for verification"""
#     if request.method == 'POST':
#         phone = request.POST.get('phone')
#         
#         try:
#             user = User.objects.get(phone=phone)
#             user.generate_otp()
#             
#             # Send SMS logic here
#             # sms_service.send(phone, f"Your OTP is: {user.otp_code}")
#             
#             return JsonResponse({'success': True, 'message': 'OTP sent successfully'})
#         except User.DoesNotExist:
#             return JsonResponse({'success': False, 'message': 'Phone number not found'})
#     
#     return JsonResponse({'success': False, 'message': 'Invalid request'})


# def verify_otp(request):
#     """Verify OTP code"""
#     if request.method == 'POST':
#         phone = request.POST.get('phone')
#         otp_code = request.POST.get('otp_code')
#         
#         try:
#             user = User.objects.get(phone=phone, otp_code=otp_code)
#             
#             if user.otp_expires and user.otp_expires > timezone.now():
#                 user.is_verified = True
#                 user.otp_code = None
#                 user.otp_expires = None
#                 user.save()
#                 return JsonResponse({'success': True, 'message': 'OTP verified successfully'})
#             else:
#                 return JsonResponse({'success': False, 'message': 'OTP expired'})
#         except User.DoesNotExist:
#             return JsonResponse({'success': False, 'message': 'Invalid OTP'})
#     
#     return JsonResponse({'success': False, 'message': 'Invalid request'})


# Payment integration (commented for future implementation)
# def process_payment(request, appointment_id):
#     """Process payment for appointment"""
#     appointment = get_object_or_404(Appointment, id=appointment_id)
#     payment = appointment.payment
#     
#     if request.method == 'POST':
#         # SSLCommerz integration
#         sslcommerz = SSLCommerzPayment()
#         response = sslcommerz.create_payment(payment)
#         
#         if response['success']:
#             return redirect(response['gateway_url'])
#         else:
#             messages.error(request, 'Payment processing failed')
#             return redirect('patient_appointments')
#     
#     context = {'appointment': appointment, 'payment': payment}
#     return render(request, 'payment/process.html', context)


# def payment_success(request):
#     """Payment success callback"""
#     transaction_id = request.GET.get('transaction_id')
#     
#     # Verify payment with SSLCommerz
#     sslcommerz = SSLCommerzPayment()
#     result = sslcommerz.verify_payment(transaction_id)
#     
#     if result['success']:
#         # Update payment status
#         payment = Payment.objects.get(transaction_id=transaction_id)
#         payment.status = 'completed'
#         payment.transaction_id = transaction_id
#         payment.save()
#         
#         # Update appointment status
#         payment.appointment.status = 'confirmed'
#         payment.appointment.save()
#         
#         return redirect('payment_success')
#     
#     return redirect('payment_fail')


# def payment_fail(request):
#     """Payment failure callback"""
#     return render(request, 'payment/fail.html')


# Admin Management Views
@login_required
def admin_users(request):
    """Admin users management page"""
    if request.user.role != 'admin':
        return redirect('home')
    
    # Get all users with statistics
    users = User.objects.all().order_by('-date_joined')
    total_users = users.count()
    total_patients = users.filter(role='patient').count()
    total_doctors = users.filter(role='doctor').count()
    total_admins = users.filter(role='admin').count()
    
    context = {
        'users': users,
        'total_users': total_users,
        'total_patients': total_patients,
        'total_doctors': total_doctors,
        'total_admins': total_admins,
    }
    return render(request, 'admin/users_detail.html', context)


@login_required
def admin_appointments(request):
    """Admin appointments management page"""
    if request.user.role != 'admin':
        return redirect('home')
    
    # Get all appointments with statistics
    appointments = Appointment.objects.all().order_by('-created_at')
    total_appointments = appointments.count()
    scheduled_appointments = appointments.filter(status='scheduled').count()
    completed_appointments = appointments.filter(status='completed').count()
    cancelled_appointments = appointments.filter(status='cancelled').count()
    
    context = {
        'appointments': appointments,
        'total_appointments': total_appointments,
        'scheduled_appointments': scheduled_appointments,
        'completed_appointments': completed_appointments,
        'cancelled_appointments': cancelled_appointments,
    }
    return render(request, 'admin/appointments_detail.html', context)


@login_required
def admin_assessments(request):
    """Admin assessments management page"""
    if request.user.role != 'admin':
        return redirect('home')
    
    # Get all assessment questions and results
    questions = AssessmentQuestion.objects.all().order_by('-created_at')
    assessments = PatientAssessment.objects.all().order_by('-created_at')
    total_questions = questions.count()
    total_assessments = assessments.count()
    completed_assessments = assessments.filter(completed=True).count()
    
    context = {
        'questions': questions,
        'assessments': assessments,
        'total_questions': total_questions,
        'total_assessments': total_assessments,
        'completed_assessments': completed_assessments,
    }
    return render(request, 'admin/assessments_detail.html', context)
#     messages.error(request, 'Payment failed. Please try again.')
#     return redirect('patient_appointments')
