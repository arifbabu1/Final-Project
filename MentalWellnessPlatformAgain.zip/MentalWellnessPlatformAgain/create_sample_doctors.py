#!/usr/bin/env python
import os
import sys
import django

# Setup Django
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'wellness_platform.settings')
django.setup()

from home.models import User, Doctor
from django.contrib.auth.hashers import make_password

# Create sample doctors if they don't exist
doctors_data = [
    {
        'username': 'dr_smith',
        'email': 'smith@wellness.com',
        'phone': '+8801711111111',
        'first_name': 'John',
        'last_name': 'Smith',
        'specialty': 'Psychologist',
        'qualification': 'PhD in Clinical Psychology',
        'experience_years': 10,
        'consultation_fee': 50.00
    },
    {
        'username': 'dr_jones',
        'email': 'jones@wellness.com',
        'phone': '+8801711111112',
        'first_name': 'Sarah',
        'last_name': 'Jones',
        'specialty': 'Psychiatrist',
        'qualification': 'MD in Psychiatry',
        'experience_years': 15,
        'consultation_fee': 75.00
    },
    {
        'username': 'dr_wilson',
        'email': 'wilson@wellness.com',
        'phone': '+8801711111113',
        'first_name': 'Michael',
        'last_name': 'Wilson',
        'specialty': 'Counselor',
        'qualification': 'MA in Counseling Psychology',
        'experience_years': 8,
        'consultation_fee': 40.00
    }
]

for doc_data in doctors_data:
    # Check if user already exists
    if User.objects.filter(username=doc_data['username']).exists():
        print(f'Doctor {doc_data["username"]} already exists')
        continue
    
    # Create user
    user = User.objects.create(
        username=doc_data['username'],
        email=doc_data['email'],
        phone=doc_data['phone'],
        first_name=doc_data['first_name'],
        last_name=doc_data['last_name'],
        role='doctor',
        password=make_password('password123')
    )
    
    # Create doctor profile
    Doctor.objects.create(
        user=user,
        specialty=doc_data['specialty'],
        qualification=doc_data['qualification'],
        experience_years=doc_data['experience_years'],
        consultation_fee=doc_data['consultation_fee'],
        is_available=True
    )
    
    print(f'Created doctor: Dr. {doc_data["first_name"]} {doc_data["last_name"]}')

print('Sample doctors created successfully!')
